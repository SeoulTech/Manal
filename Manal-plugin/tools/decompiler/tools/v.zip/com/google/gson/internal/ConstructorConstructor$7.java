package com.google.gson.internal;

import java.util.LinkedHashMap;

class ConstructorConstructor$7
  implements ObjectConstructor<T>
{
  ConstructorConstructor$7(ConstructorConstructor paramConstructorConstructor) {}
  
  public T construct()
  {
    return new LinkedHashMap();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ConstructorConstructor.7
 * JD-Core Version:    0.7.0.1
 */