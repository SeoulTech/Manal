package com.google.gson.internal;

import java.util.ArrayList;

class ConstructorConstructor$6
  implements ObjectConstructor<T>
{
  ConstructorConstructor$6(ConstructorConstructor paramConstructorConstructor) {}
  
  public T construct()
  {
    return new ArrayList();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ConstructorConstructor.6
 * JD-Core Version:    0.7.0.1
 */