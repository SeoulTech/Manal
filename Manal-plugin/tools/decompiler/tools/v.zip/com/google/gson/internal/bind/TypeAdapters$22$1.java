package com.google.gson.internal.bind;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

class TypeAdapters$22$1
  extends TypeAdapter<Timestamp>
{
  TypeAdapters$22$1(TypeAdapters.22 param22, TypeAdapter paramTypeAdapter) {}
  
  public Timestamp read(JsonReader paramJsonReader)
    throws IOException
  {
    Date localDate = (Date)this.val$dateTypeAdapter.read(paramJsonReader);
    if (localDate != null) {}
    for (Timestamp localTimestamp = new Timestamp(localDate.getTime());; localTimestamp = null) {
      return localTimestamp;
    }
  }
  
  public void write(JsonWriter paramJsonWriter, Timestamp paramTimestamp)
    throws IOException
  {
    this.val$dateTypeAdapter.write(paramJsonWriter, paramTimestamp);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.bind.TypeAdapters.22.1
 * JD-Core Version:    0.7.0.1
 */