package com.google.gson.internal;

import java.lang.reflect.Method;

class UnsafeAllocator$1
  extends UnsafeAllocator
{
  UnsafeAllocator$1(Method paramMethod, Object paramObject) {}
  
  public <T> T newInstance(Class<T> paramClass)
    throws Exception
  {
    Method localMethod = this.val$allocateInstance;
    Object localObject = this.val$unsafe;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramClass;
    return localMethod.invoke(localObject, arrayOfObject);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.UnsafeAllocator.1
 * JD-Core Version:    0.7.0.1
 */