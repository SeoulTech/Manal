package com.google.gson.internal.bind;

import java.io.IOException;
import java.io.Writer;

class JsonTreeWriter$1
  extends Writer
{
  public void close()
    throws IOException
  {
    throw new AssertionError();
  }
  
  public void flush()
    throws IOException
  {
    throw new AssertionError();
  }
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    throw new AssertionError();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.bind.JsonTreeWriter.1
 * JD-Core Version:    0.7.0.1
 */