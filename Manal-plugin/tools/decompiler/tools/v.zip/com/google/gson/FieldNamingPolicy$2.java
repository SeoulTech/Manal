package com.google.gson;

import java.lang.reflect.Field;

 enum FieldNamingPolicy$2
{
  FieldNamingPolicy$2()
  {
    super(str, i, null);
  }
  
  public String translateName(Field paramField)
  {
    return FieldNamingPolicy.access$100(paramField.getName());
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.FieldNamingPolicy.2
 * JD-Core Version:    0.7.0.1
 */