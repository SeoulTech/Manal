package com.google.gson.internal;

import java.util.LinkedHashSet;

class ConstructorConstructor$4
  implements ObjectConstructor<T>
{
  ConstructorConstructor$4(ConstructorConstructor paramConstructorConstructor) {}
  
  public T construct()
  {
    return new LinkedHashSet();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ConstructorConstructor.4
 * JD-Core Version:    0.7.0.1
 */