package com.google.gson.internal;

class StringMap$KeySet$1
  extends StringMap<V>.LinkedHashIterator<String>
{
  StringMap$KeySet$1(StringMap.KeySet paramKeySet)
  {
    super(paramKeySet.this$0, null);
  }
  
  public final String next()
  {
    return nextEntry().key;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.StringMap.KeySet.1
 * JD-Core Version:    0.7.0.1
 */