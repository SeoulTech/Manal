package com.google.gson.stream;

final class StringPool
{
  private final String[] pool = new String[512];
  
  public String get(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (int j = paramInt1; j < paramInt1 + paramInt2; j++) {
      i = i * 31 + paramArrayOfChar[j];
    }
    int k = i ^ i >>> 20 ^ i >>> 12;
    int m = (k ^ k >>> 7 ^ k >>> 4) & -1 + this.pool.length;
    String str1 = this.pool[m];
    String str2;
    if ((str1 == null) || (str1.length() != paramInt2))
    {
      str2 = new String(paramArrayOfChar, paramInt1, paramInt2);
      this.pool[m] = str2;
    }
    for (;;)
    {
      return str2;
      for (int n = 0;; n++)
      {
        if (n >= paramInt2) {
          break label174;
        }
        if (str1.charAt(n) != paramArrayOfChar[(paramInt1 + n)])
        {
          str2 = new String(paramArrayOfChar, paramInt1, paramInt2);
          this.pool[m] = str2;
          break;
        }
      }
      label174:
      str2 = str1;
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.stream.StringPool
 * JD-Core Version:    0.7.0.1
 */