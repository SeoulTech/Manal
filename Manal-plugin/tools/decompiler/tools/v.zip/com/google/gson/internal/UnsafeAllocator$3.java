package com.google.gson.internal;

import java.lang.reflect.Method;

class UnsafeAllocator$3
  extends UnsafeAllocator
{
  UnsafeAllocator$3(Method paramMethod, int paramInt) {}
  
  public <T> T newInstance(Class<T> paramClass)
    throws Exception
  {
    Method localMethod = this.val$newInstance;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramClass;
    arrayOfObject[1] = Integer.valueOf(this.val$constructorId);
    return localMethod.invoke(null, arrayOfObject);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.UnsafeAllocator.3
 * JD-Core Version:    0.7.0.1
 */