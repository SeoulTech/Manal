package com.google.gson.internal;

import java.util.Map.Entry;

class StringMap$EntrySet$1
  extends StringMap<V>.LinkedHashIterator<Map.Entry<String, V>>
{
  StringMap$EntrySet$1(StringMap.EntrySet paramEntrySet)
  {
    super(paramEntrySet.this$0, null);
  }
  
  public final Map.Entry<String, V> next()
  {
    return nextEntry();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.StringMap.EntrySet.1
 * JD-Core Version:    0.7.0.1
 */