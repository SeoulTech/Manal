package com.google.gson.internal;

import java.util.LinkedList;

class ConstructorConstructor$5
  implements ObjectConstructor<T>
{
  ConstructorConstructor$5(ConstructorConstructor paramConstructorConstructor) {}
  
  public T construct()
  {
    return new LinkedList();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ConstructorConstructor.5
 * JD-Core Version:    0.7.0.1
 */