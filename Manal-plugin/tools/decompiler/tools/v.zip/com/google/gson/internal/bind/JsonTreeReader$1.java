package com.google.gson.internal.bind;

import java.io.IOException;
import java.io.Reader;

class JsonTreeReader$1
  extends Reader
{
  public void close()
    throws IOException
  {
    throw new AssertionError();
  }
  
  public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    throw new AssertionError();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.bind.JsonTreeReader.1
 * JD-Core Version:    0.7.0.1
 */