package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ObjectConstructor
 * JD-Core Version:    0.7.0.1
 */