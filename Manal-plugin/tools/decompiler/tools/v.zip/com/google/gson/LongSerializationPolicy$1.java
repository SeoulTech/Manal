package com.google.gson;

 enum LongSerializationPolicy$1
{
  LongSerializationPolicy$1()
  {
    super(str, i, null);
  }
  
  public JsonElement serialize(Long paramLong)
  {
    return new JsonPrimitive(paramLong);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.LongSerializationPolicy.1
 * JD-Core Version:    0.7.0.1
 */