package com.google.gson.internal;

class StringMap$Values$1
  extends StringMap<V>.LinkedHashIterator<V>
{
  StringMap$Values$1(StringMap.Values paramValues)
  {
    super(paramValues.this$0, null);
  }
  
  public final V next()
  {
    return nextEntry().value;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.StringMap.Values.1
 * JD-Core Version:    0.7.0.1
 */