package com.google.gson.internal;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;

class Excluder$1
  extends TypeAdapter<T>
{
  private TypeAdapter<T> delegate;
  
  Excluder$1(Excluder paramExcluder, boolean paramBoolean1, boolean paramBoolean2, Gson paramGson, TypeToken paramTypeToken) {}
  
  private TypeAdapter<T> delegate()
  {
    TypeAdapter localTypeAdapter = this.delegate;
    if (localTypeAdapter != null) {}
    for (;;)
    {
      return localTypeAdapter;
      localTypeAdapter = this.val$gson.getDelegateAdapter(this.this$0, this.val$type);
      this.delegate = localTypeAdapter;
    }
  }
  
  public T read(JsonReader paramJsonReader)
    throws IOException
  {
    if (this.val$skipDeserialize) {
      paramJsonReader.skipValue();
    }
    for (Object localObject = null;; localObject = delegate().read(paramJsonReader)) {
      return localObject;
    }
  }
  
  public void write(JsonWriter paramJsonWriter, T paramT)
    throws IOException
  {
    if (this.val$skipSerialize) {
      paramJsonWriter.nullValue();
    }
    for (;;)
    {
      return;
      delegate().write(paramJsonWriter, paramT);
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.Excluder.1
 * JD-Core Version:    0.7.0.1
 */