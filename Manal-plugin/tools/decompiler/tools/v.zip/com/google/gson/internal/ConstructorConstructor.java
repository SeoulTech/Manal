package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;

public final class ConstructorConstructor
{
  private final Map<Type, InstanceCreator<?>> instanceCreators;
  
  public ConstructorConstructor()
  {
    this(Collections.emptyMap());
  }
  
  public ConstructorConstructor(Map<Type, InstanceCreator<?>> paramMap)
  {
    this.instanceCreators = paramMap;
  }
  
  private <T> ObjectConstructor<T> newDefaultConstructor(Class<? super T> paramClass)
  {
    try
    {
      Constructor localConstructor = paramClass.getDeclaredConstructor(new Class[0]);
      if (!localConstructor.isAccessible()) {
        localConstructor.setAccessible(true);
      }
      local2 = new ConstructorConstructor.2(this, localConstructor);
      return local2;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      for (;;)
      {
        ConstructorConstructor.2 local2 = null;
      }
    }
  }
  
  private <T> ObjectConstructor<T> newDefaultImplementationConstructor(Class<? super T> paramClass)
  {
    Object localObject;
    if (Collection.class.isAssignableFrom(paramClass)) {
      if (SortedSet.class.isAssignableFrom(paramClass)) {
        localObject = new ConstructorConstructor.3(this);
      }
    }
    for (;;)
    {
      return localObject;
      if (Set.class.isAssignableFrom(paramClass))
      {
        localObject = new ConstructorConstructor.4(this);
      }
      else if (Queue.class.isAssignableFrom(paramClass))
      {
        localObject = new ConstructorConstructor.5(this);
      }
      else
      {
        localObject = new ConstructorConstructor.6(this);
        continue;
        if (Map.class.isAssignableFrom(paramClass)) {
          localObject = new ConstructorConstructor.7(this);
        } else {
          localObject = null;
        }
      }
    }
  }
  
  private <T> ObjectConstructor<T> newUnsafeAllocator(Type paramType, Class<? super T> paramClass)
  {
    return new ConstructorConstructor.8(this, paramClass, paramType);
  }
  
  public <T> ObjectConstructor<T> get(TypeToken<T> paramTypeToken)
  {
    Type localType = paramTypeToken.getType();
    Class localClass = paramTypeToken.getRawType();
    InstanceCreator localInstanceCreator = (InstanceCreator)this.instanceCreators.get(localType);
    Object localObject;
    if (localInstanceCreator != null) {
      localObject = new ConstructorConstructor.1(this, localInstanceCreator, localType);
    }
    for (;;)
    {
      return localObject;
      localObject = newDefaultConstructor(localClass);
      if (localObject == null)
      {
        ObjectConstructor localObjectConstructor = newDefaultImplementationConstructor(localClass);
        if (localObjectConstructor != null) {
          localObject = localObjectConstructor;
        } else {
          localObject = newUnsafeAllocator(localType, localClass);
        }
      }
    }
  }
  
  public String toString()
  {
    return this.instanceCreators.toString();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ConstructorConstructor
 * JD-Core Version:    0.7.0.1
 */