package com.google.gson.internal;

import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;

public final class StringMap<V>
  extends AbstractMap<String, V>
{
  private static final Map.Entry[] EMPTY_TABLE = new LinkedEntry[2];
  private static final int MAXIMUM_CAPACITY = 1073741824;
  private static final int MINIMUM_CAPACITY = 4;
  private static final int seed = new Random().nextInt();
  private Set<Map.Entry<String, V>> entrySet;
  private LinkedEntry<V> header = new LinkedEntry();
  private Set<String> keySet;
  private int size;
  private LinkedEntry<V>[] table = (LinkedEntry[])EMPTY_TABLE;
  private int threshold = -1;
  private Collection<V> values;
  
  private void addNewEntry(String paramString, V paramV, int paramInt1, int paramInt2)
  {
    LinkedEntry localLinkedEntry1 = this.header;
    LinkedEntry localLinkedEntry2 = localLinkedEntry1.prv;
    LinkedEntry localLinkedEntry3 = new LinkedEntry(paramString, paramV, paramInt1, this.table[paramInt2], localLinkedEntry1, localLinkedEntry2);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    localLinkedEntry1.prv = localLinkedEntry3;
    localLinkedEntry2.nxt = localLinkedEntry3;
    arrayOfLinkedEntry[paramInt2] = localLinkedEntry3;
  }
  
  private LinkedEntry<V>[] doubleCapacity()
  {
    LinkedEntry[] arrayOfLinkedEntry1 = this.table;
    int i = arrayOfLinkedEntry1.length;
    LinkedEntry[] arrayOfLinkedEntry2;
    if (i == 1073741824) {
      arrayOfLinkedEntry2 = arrayOfLinkedEntry1;
    }
    do
    {
      return arrayOfLinkedEntry2;
      arrayOfLinkedEntry2 = makeTable(i * 2);
    } while (this.size == 0);
    int j = 0;
    label36:
    Object localObject1;
    if (j < i)
    {
      localObject1 = arrayOfLinkedEntry1[j];
      if (localObject1 != null) {
        break label59;
      }
    }
    for (;;)
    {
      j++;
      break label36;
      break;
      label59:
      int k = i & ((LinkedEntry)localObject1).hash;
      Object localObject2 = null;
      arrayOfLinkedEntry2[(j | k)] = localObject1;
      LinkedEntry localLinkedEntry = ((LinkedEntry)localObject1).next;
      if (localLinkedEntry != null)
      {
        int m = i & localLinkedEntry.hash;
        if (m != k)
        {
          if (localObject2 != null) {
            break label144;
          }
          arrayOfLinkedEntry2[(j | m)] = localLinkedEntry;
        }
        for (;;)
        {
          localObject2 = localObject1;
          k = m;
          localObject1 = localLinkedEntry;
          localLinkedEntry = localLinkedEntry.next;
          break;
          label144:
          localObject2.next = localLinkedEntry;
        }
      }
      if (localObject2 != null) {
        localObject2.next = null;
      }
    }
  }
  
  private LinkedEntry<V> getEntry(String paramString)
  {
    if (paramString == null) {}
    label77:
    for (Object localObject = null;; localObject = null)
    {
      return localObject;
      int i = hash(paramString);
      LinkedEntry[] arrayOfLinkedEntry = this.table;
      for (localObject = arrayOfLinkedEntry[(i & -1 + arrayOfLinkedEntry.length)];; localObject = ((LinkedEntry)localObject).next)
      {
        if (localObject == null) {
          break label77;
        }
        String str = ((LinkedEntry)localObject).key;
        if ((str == paramString) || ((((LinkedEntry)localObject).hash == i) && (paramString.equals(str)))) {
          break;
        }
      }
    }
  }
  
  private static int hash(String paramString)
  {
    int i = seed;
    for (int j = 0; j < paramString.length(); j++)
    {
      int m = i + paramString.charAt(j);
      int n = m + m << 10;
      i = n ^ n >>> 6;
    }
    int k = i ^ i >>> 20 ^ i >>> 12;
    return k ^ k >>> 7 ^ k >>> 4;
  }
  
  private LinkedEntry<V>[] makeTable(int paramInt)
  {
    LinkedEntry[] arrayOfLinkedEntry = (LinkedEntry[])new LinkedEntry[paramInt];
    this.table = arrayOfLinkedEntry;
    this.threshold = ((paramInt >> 1) + (paramInt >> 2));
    return arrayOfLinkedEntry;
  }
  
  private boolean removeMapping(Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if ((paramObject1 == null) || (!(paramObject1 instanceof String))) {
      bool = false;
    }
    for (;;)
    {
      return bool;
      int i = hash((String)paramObject1);
      LinkedEntry[] arrayOfLinkedEntry = this.table;
      int j = i & -1 + arrayOfLinkedEntry.length;
      LinkedEntry localLinkedEntry1 = arrayOfLinkedEntry[j];
      LinkedEntry localLinkedEntry2 = null;
      for (;;)
      {
        if (localLinkedEntry1 == null) {
          break label171;
        }
        if ((localLinkedEntry1.hash == i) && (paramObject1.equals(localLinkedEntry1.key)))
        {
          if (paramObject2 == null)
          {
            if (localLinkedEntry1.value == null) {}
          }
          else {
            while (!paramObject2.equals(localLinkedEntry1.value))
            {
              bool = false;
              break;
            }
          }
          if (localLinkedEntry2 == null) {
            arrayOfLinkedEntry[j] = localLinkedEntry1.next;
          }
          for (;;)
          {
            this.size = (-1 + this.size);
            unlink(localLinkedEntry1);
            bool = true;
            break;
            localLinkedEntry2.next = localLinkedEntry1.next;
          }
        }
        localLinkedEntry2 = localLinkedEntry1;
        localLinkedEntry1 = localLinkedEntry1.next;
      }
      label171:
      bool = false;
    }
  }
  
  private void unlink(LinkedEntry<V> paramLinkedEntry)
  {
    paramLinkedEntry.prv.nxt = paramLinkedEntry.nxt;
    paramLinkedEntry.nxt.prv = paramLinkedEntry.prv;
    paramLinkedEntry.prv = null;
    paramLinkedEntry.nxt = null;
  }
  
  public void clear()
  {
    if (this.size != 0)
    {
      Arrays.fill(this.table, null);
      this.size = 0;
    }
    LinkedEntry localLinkedEntry1 = this.header;
    LinkedEntry localLinkedEntry2;
    for (Object localObject = localLinkedEntry1.nxt; localObject != localLinkedEntry1; localObject = localLinkedEntry2)
    {
      localLinkedEntry2 = ((LinkedEntry)localObject).nxt;
      ((LinkedEntry)localObject).prv = null;
      ((LinkedEntry)localObject).nxt = null;
    }
    localLinkedEntry1.prv = localLinkedEntry1;
    localLinkedEntry1.nxt = localLinkedEntry1;
  }
  
  public boolean containsKey(Object paramObject)
  {
    if (((paramObject instanceof String)) && (getEntry((String)paramObject) != null)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public Set<Map.Entry<String, V>> entrySet()
  {
    Object localObject = this.entrySet;
    if (localObject != null) {}
    for (;;)
    {
      return localObject;
      localObject = new EntrySet(null);
      this.entrySet = ((Set)localObject);
    }
  }
  
  public V get(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof String))
    {
      LinkedEntry localLinkedEntry = getEntry((String)paramObject);
      if (localLinkedEntry != null) {
        localObject = localLinkedEntry.value;
      }
    }
    return localObject;
  }
  
  public Set<String> keySet()
  {
    Object localObject = this.keySet;
    if (localObject != null) {}
    for (;;)
    {
      return localObject;
      localObject = new KeySet(null);
      this.keySet = ((Set)localObject);
    }
  }
  
  public V put(String paramString, V paramV)
  {
    if (paramString == null) {
      throw new NullPointerException("key == null");
    }
    int i = hash(paramString);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    int j = i & -1 + arrayOfLinkedEntry.length;
    LinkedEntry localLinkedEntry = arrayOfLinkedEntry[j];
    Object localObject;
    if (localLinkedEntry != null) {
      if ((localLinkedEntry.hash == i) && (paramString.equals(localLinkedEntry.key)))
      {
        localObject = localLinkedEntry.value;
        localLinkedEntry.value = paramV;
      }
    }
    for (;;)
    {
      return localObject;
      localLinkedEntry = localLinkedEntry.next;
      break;
      int k = this.size;
      this.size = (k + 1);
      if (k > this.threshold) {
        j = i & -1 + doubleCapacity().length;
      }
      addNewEntry(paramString, paramV, i, j);
      localObject = null;
    }
  }
  
  public V remove(Object paramObject)
  {
    Object localObject;
    if ((paramObject == null) || (!(paramObject instanceof String))) {
      localObject = null;
    }
    for (;;)
    {
      return localObject;
      int i = hash((String)paramObject);
      LinkedEntry[] arrayOfLinkedEntry = this.table;
      int j = i & -1 + arrayOfLinkedEntry.length;
      LinkedEntry localLinkedEntry1 = arrayOfLinkedEntry[j];
      LinkedEntry localLinkedEntry2 = null;
      for (;;)
      {
        if (localLinkedEntry1 == null) {
          break label143;
        }
        if ((localLinkedEntry1.hash == i) && (paramObject.equals(localLinkedEntry1.key)))
        {
          if (localLinkedEntry2 == null) {
            arrayOfLinkedEntry[j] = localLinkedEntry1.next;
          }
          for (;;)
          {
            this.size = (-1 + this.size);
            unlink(localLinkedEntry1);
            localObject = localLinkedEntry1.value;
            break;
            localLinkedEntry2.next = localLinkedEntry1.next;
          }
        }
        localLinkedEntry2 = localLinkedEntry1;
        localLinkedEntry1 = localLinkedEntry1.next;
      }
      label143:
      localObject = null;
    }
  }
  
  public int size()
  {
    return this.size;
  }
  
  public Collection<V> values()
  {
    Object localObject = this.values;
    if (localObject != null) {}
    for (;;)
    {
      return localObject;
      localObject = new Values(null);
      this.values = ((Collection)localObject);
    }
  }
  
  private final class EntrySet
    extends AbstractSet<Map.Entry<String, V>>
  {
    private EntrySet() {}
    
    public void clear()
    {
      StringMap.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      boolean bool = false;
      if (!(paramObject instanceof Map.Entry)) {}
      for (;;)
      {
        return bool;
        Map.Entry localEntry = (Map.Entry)paramObject;
        Object localObject = StringMap.this.get(localEntry.getKey());
        if ((localObject != null) && (localObject.equals(localEntry.getValue()))) {
          bool = true;
        }
      }
    }
    
    public Iterator<Map.Entry<String, V>> iterator()
    {
      return new StringMap.EntrySet.1(this);
    }
    
    public boolean remove(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry)) {}
      Map.Entry localEntry;
      for (boolean bool = false;; bool = StringMap.this.removeMapping(localEntry.getKey(), localEntry.getValue()))
      {
        return bool;
        localEntry = (Map.Entry)paramObject;
      }
    }
    
    public int size()
    {
      return StringMap.this.size;
    }
  }
  
  private final class KeySet
    extends AbstractSet<String>
  {
    private KeySet() {}
    
    public void clear()
    {
      StringMap.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      return StringMap.this.containsKey(paramObject);
    }
    
    public Iterator<String> iterator()
    {
      return new StringMap.KeySet.1(this);
    }
    
    public boolean remove(Object paramObject)
    {
      int i = StringMap.this.size;
      StringMap.this.remove(paramObject);
      if (StringMap.this.size != i) {}
      for (boolean bool = true;; bool = false) {
        return bool;
      }
    }
    
    public int size()
    {
      return StringMap.this.size;
    }
  }
  
  static class LinkedEntry<V>
    implements Map.Entry<String, V>
  {
    final int hash;
    final String key;
    LinkedEntry<V> next;
    LinkedEntry<V> nxt;
    LinkedEntry<V> prv;
    V value;
    
    LinkedEntry()
    {
      this(null, null, 0, null, null, null);
      this.prv = this;
      this.nxt = this;
    }
    
    LinkedEntry(String paramString, V paramV, int paramInt, LinkedEntry<V> paramLinkedEntry1, LinkedEntry<V> paramLinkedEntry2, LinkedEntry<V> paramLinkedEntry3)
    {
      this.key = paramString;
      this.value = paramV;
      this.hash = paramInt;
      this.next = paramLinkedEntry1;
      this.nxt = paramLinkedEntry2;
      this.prv = paramLinkedEntry3;
    }
    
    public final boolean equals(Object paramObject)
    {
      boolean bool = false;
      if (!(paramObject instanceof Map.Entry)) {}
      Object localObject;
      do
      {
        Map.Entry localEntry;
        do
        {
          return bool;
          localEntry = (Map.Entry)paramObject;
          localObject = localEntry.getValue();
        } while (!this.key.equals(localEntry.getKey()));
        if (this.value != null) {
          break;
        }
      } while (localObject != null);
      for (;;)
      {
        bool = true;
        break;
        if (!this.value.equals(localObject)) {
          break;
        }
      }
    }
    
    public final String getKey()
    {
      return this.key;
    }
    
    public final V getValue()
    {
      return this.value;
    }
    
    public final int hashCode()
    {
      int i = 0;
      int j;
      if (this.key == null)
      {
        j = 0;
        if (this.value != null) {
          break label33;
        }
      }
      for (;;)
      {
        return j ^ i;
        j = this.key.hashCode();
        break;
        label33:
        i = this.value.hashCode();
      }
    }
    
    public final V setValue(V paramV)
    {
      Object localObject = this.value;
      this.value = paramV;
      return localObject;
    }
    
    public final String toString()
    {
      return this.key + "=" + this.value;
    }
  }
  
  private abstract class LinkedHashIterator<T>
    implements Iterator<T>
  {
    StringMap.LinkedEntry<V> lastReturned = null;
    StringMap.LinkedEntry<V> next = StringMap.this.header.nxt;
    
    private LinkedHashIterator() {}
    
    public final boolean hasNext()
    {
      if (this.next != StringMap.this.header) {}
      for (boolean bool = true;; bool = false) {
        return bool;
      }
    }
    
    final StringMap.LinkedEntry<V> nextEntry()
    {
      StringMap.LinkedEntry localLinkedEntry = this.next;
      if (localLinkedEntry == StringMap.this.header) {
        throw new NoSuchElementException();
      }
      this.next = localLinkedEntry.nxt;
      this.lastReturned = localLinkedEntry;
      return localLinkedEntry;
    }
    
    public final void remove()
    {
      if (this.lastReturned == null) {
        throw new IllegalStateException();
      }
      StringMap.this.remove(this.lastReturned.key);
      this.lastReturned = null;
    }
  }
  
  private final class Values
    extends AbstractCollection<V>
  {
    private Values() {}
    
    public void clear()
    {
      StringMap.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      return StringMap.this.containsValue(paramObject);
    }
    
    public Iterator<V> iterator()
    {
      return new StringMap.Values.1(this);
    }
    
    public int size()
    {
      return StringMap.this.size;
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.google.gson.internal.StringMap
 * JD-Core Version:    0.7.0.1
 */