package com.example.secerettalk;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.example.secerettalk.BuildConfig
 * JD-Core Version:    0.7.0.1
 */