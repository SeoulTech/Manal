package com.android.secrettalk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Polling3rdServer
  extends Thread
{
  String mAddr;
  String mResult;
  String phone_id;
  
  public void Setting(String paramString1, String paramString2)
  {
    this.mAddr = paramString1;
    this.phone_id = paramString2;
    this.mResult = "";
  }
  
  public String getResult()
  {
    return this.mResult;
  }
  
  public void run()
  {
    super.run();
    StringBuilder localStringBuilder = new StringBuilder();
    try
    {
      HttpURLConnection localHttpURLConnection = (HttpURLConnection)new URL(this.mAddr).openConnection();
      localHttpURLConnection.setDefaultUseCaches(false);
      localHttpURLConnection.setDoInput(true);
      localHttpURLConnection.setDoOutput(true);
      localHttpURLConnection.setRequestMethod("POST");
      localHttpURLConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append("phone_id").append("=").append(this.phone_id);
      PrintWriter localPrintWriter = new PrintWriter(new OutputStreamWriter(localHttpURLConnection.getOutputStream(), "euc-kr"));
      localPrintWriter.write(localStringBuffer.toString());
      localPrintWriter.flush();
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localHttpURLConnection.getInputStream()));
      for (;;)
      {
        String str = localBufferedReader.readLine();
        if (str == null)
        {
          localBufferedReader.close();
          this.mResult = localStringBuilder.toString();
          break;
        }
        localStringBuilder.append(str);
      }
      return;
    }
    catch (MalformedURLException localMalformedURLException)
    {
      localMalformedURLException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.Polling3rdServer
 * JD-Core Version:    0.7.0.1
 */