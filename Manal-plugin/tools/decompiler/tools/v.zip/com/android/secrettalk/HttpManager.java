package com.android.secrettalk;

import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URI;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

public class HttpManager
{
  public static String APP_TAG = "SecretTalk";
  
  public static String getHttpResponse(URI paramURI)
  {
    Log.d(APP_TAG, "Going to make a get request");
    System.out.println("[url ] " + paramURI.toString());
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      try
      {
        HttpGet localHttpGet = new HttpGet();
        localHttpGet.setURI(paramURI);
        HttpResponse localHttpResponse = new DefaultHttpClient().execute(localHttpGet);
        if (localHttpResponse.getStatusLine().getStatusCode() == 200)
        {
          Log.d("demo", "HTTP Get succeeded");
          BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localHttpResponse.getEntity().getContent()));
          str = localBufferedReader.readLine();
          if (str != null) {
            continue;
          }
        }
      }
      catch (Exception localException)
      {
        String str;
        Log.e("demo", localException.getMessage());
        continue;
      }
      Log.d("demo", "Done with HTTP getting");
      System.out.println("[response] " + localStringBuilder.toString());
      return localStringBuilder.toString();
      localStringBuilder.append(str);
    }
  }
  
  private static JSONObject getJsonObjectFromMap(Map paramMap)
    throws JSONException
  {
    Iterator localIterator1 = paramMap.entrySet().iterator();
    JSONObject localJSONObject1 = new JSONObject();
    if (!localIterator1.hasNext()) {
      return localJSONObject1;
    }
    Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
    String str = (String)localEntry1.getKey();
    Map localMap = (Map)localEntry1.getValue();
    JSONObject localJSONObject2 = new JSONObject();
    Iterator localIterator2 = localMap.entrySet().iterator();
    for (;;)
    {
      if (!localIterator2.hasNext())
      {
        localJSONObject1.put(str, localJSONObject2);
        break;
      }
      Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
      localJSONObject2.put((String)localEntry2.getKey(), (String)localEntry2.getValue());
    }
  }
  
  public static String postHttpResponse(URI paramURI, String paramString)
  {
    Log.d(APP_TAG, "Going to make a post request");
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      try
      {
        HttpPost localHttpPost = new HttpPost();
        localHttpPost.setURI(paramURI);
        System.out.println("[url ] " + paramURI.toASCIIString());
        System.out.println("[param ]" + paramString.toString());
        localHttpPost.setEntity(new StringEntity(paramString));
        localHttpPost.setHeader("Accept", "application/json");
        localHttpPost.setHeader("Content-type", "application/json");
        HttpResponse localHttpResponse = new DefaultHttpClient().execute(localHttpPost);
        if (localHttpResponse.getStatusLine().getStatusCode() != 200) {
          continue;
        }
        Log.d(APP_TAG, "HTTP POST succeeded");
        BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localHttpResponse.getEntity().getContent()));
        str = localBufferedReader.readLine();
        if (str != null) {
          continue;
        }
      }
      catch (Exception localException)
      {
        String str;
        Log.e(APP_TAG, localException.getMessage());
        continue;
        Log.e(APP_TAG, "HTTP POST status code is not 200");
        continue;
      }
      Log.d(APP_TAG, "Done with HTTP posting");
      System.out.println("[response ] " + localStringBuilder.toString());
      return localStringBuilder.toString();
      localStringBuilder.append(str);
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.HttpManager
 * JD-Core Version:    0.7.0.1
 */