package com.android.secrettalk;

import android.os.Handler;

class ReceiverRegisterService$2
  implements Runnable
{
  ReceiverRegisterService$2(ReceiverRegisterService paramReceiverRegisterService) {}
  
  public void run()
  {
    ReceiverRegisterService.access$1(this.this$0).sendEmptyMessage(2000);
    ReceiverRegisterService.access$1(this.this$0).sendEmptyMessage(1000);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ReceiverRegisterService.2
 * JD-Core Version:    0.7.0.1
 */