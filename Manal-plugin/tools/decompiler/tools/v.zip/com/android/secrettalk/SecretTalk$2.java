package com.android.secrettalk;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class SecretTalk$2
  implements DialogInterface.OnClickListener
{
  SecretTalk$2(SecretTalk paramSecretTalk) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    paramDialogInterface.cancel();
    this.this$0.finish();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.SecretTalk.2
 * JD-Core Version:    0.7.0.1
 */