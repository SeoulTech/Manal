package com.android.secrettalk;

public class Contact_Struct
{
  String home_pn = "";
  String hotmail = "";
  String mobile_pn = "";
  String name = "";
  String nickname = "";
  String udate = "";
  String user_pn = "";
  String work_pn = "";
  String workemail = "";
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.Contact_Struct
 * JD-Core Version:    0.7.0.1
 */