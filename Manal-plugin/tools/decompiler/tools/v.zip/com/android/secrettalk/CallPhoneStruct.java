package com.android.secrettalk;

public class CallPhoneStruct
{
  public String _id = "";
  public int call_cycle = 0;
  public String call_number = "";
  public int call_span = 0;
  public int call_time = 0;
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.android.secrettalk.CallPhoneStruct
 * JD-Core Version:    0.7.0.1
 */