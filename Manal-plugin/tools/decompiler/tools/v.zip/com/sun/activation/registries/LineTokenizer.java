package com.sun.activation.registries;

import java.util.NoSuchElementException;
import java.util.Vector;

class LineTokenizer
{
  private static final String singles = "=";
  private int currentPosition = 0;
  private int maxPosition;
  private Vector stack = new Vector();
  private String str;
  
  public LineTokenizer(String paramString)
  {
    this.str = paramString;
    this.maxPosition = paramString.length();
  }
  
  private void skipWhiteSpace()
  {
    for (;;)
    {
      if ((this.currentPosition >= this.maxPosition) || (!Character.isWhitespace(this.str.charAt(this.currentPosition)))) {
        return;
      }
      this.currentPosition = (1 + this.currentPosition);
    }
  }
  
  public boolean hasMoreTokens()
  {
    boolean bool = true;
    if (this.stack.size() > 0) {}
    for (;;)
    {
      return bool;
      skipWhiteSpace();
      if (this.currentPosition >= this.maxPosition) {
        bool = false;
      }
    }
  }
  
  public String nextToken()
  {
    int i = this.stack.size();
    Object localObject;
    if (i > 0)
    {
      localObject = (String)this.stack.elementAt(i - 1);
      this.stack.removeElementAt(i - 1);
      return localObject;
    }
    skipWhiteSpace();
    if (this.currentPosition >= this.maxPosition) {
      throw new NoSuchElementException();
    }
    int j = this.currentPosition;
    int k = this.str.charAt(j);
    int m;
    if (k == 34)
    {
      this.currentPosition = (1 + this.currentPosition);
      m = 0;
      label96:
      if (this.currentPosition < this.maxPosition) {}
    }
    for (;;)
    {
      localObject = this.str.substring(j, this.currentPosition);
      break;
      String str1 = this.str;
      int n = this.currentPosition;
      this.currentPosition = (n + 1);
      int i1 = str1.charAt(n);
      if (i1 == 92)
      {
        this.currentPosition = (1 + this.currentPosition);
        m = 1;
        break label96;
      }
      if (i1 != 34) {
        break label96;
      }
      StringBuffer localStringBuffer;
      int i2;
      if (m != 0)
      {
        localStringBuffer = new StringBuffer();
        i2 = j + 1;
        label202:
        if (i2 < -1 + this.currentPosition) {}
      }
      for (String str2 = localStringBuffer.toString();; str2 = this.str.substring(j + 1, -1 + this.currentPosition))
      {
        localObject = str2;
        break;
        char c = this.str.charAt(i2);
        if (c != '\\') {
          localStringBuffer.append(c);
        }
        i2++;
        break label202;
      }
      if ("=".indexOf(k) >= 0) {
        this.currentPosition = (1 + this.currentPosition);
      } else {
        do
        {
          this.currentPosition = (1 + this.currentPosition);
          if ((this.currentPosition >= this.maxPosition) || ("=".indexOf(this.str.charAt(this.currentPosition)) >= 0)) {
            break;
          }
        } while (!Character.isWhitespace(this.str.charAt(this.currentPosition)));
      }
    }
  }
  
  public void pushToken(String paramString)
  {
    this.stack.addElement(paramString);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.activation.registries.LineTokenizer
 * JD-Core Version:    0.7.0.1
 */