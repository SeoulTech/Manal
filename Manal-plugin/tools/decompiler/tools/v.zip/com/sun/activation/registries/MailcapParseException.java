package com.sun.activation.registries;

public class MailcapParseException
  extends Exception
{
  public MailcapParseException() {}
  
  public MailcapParseException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.activation.registries.MailcapParseException
 * JD-Core Version:    0.7.0.1
 */