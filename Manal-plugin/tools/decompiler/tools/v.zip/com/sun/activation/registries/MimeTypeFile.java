package com.sun.activation.registries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class MimeTypeFile
{
  private String fname = null;
  private Hashtable type_hash = new Hashtable();
  
  public MimeTypeFile() {}
  
  public MimeTypeFile(InputStream paramInputStream)
    throws IOException
  {
    parse(new BufferedReader(new InputStreamReader(paramInputStream, "iso-8859-1")));
  }
  
  /* Error */
  public MimeTypeFile(String paramString)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 12	java/lang/Object:<init>	()V
    //   4: aload_0
    //   5: aconst_null
    //   6: putfield 14	com/sun/activation/registries/MimeTypeFile:fname	Ljava/lang/String;
    //   9: aload_0
    //   10: new 16	java/util/Hashtable
    //   13: dup
    //   14: invokespecial 17	java/util/Hashtable:<init>	()V
    //   17: putfield 19	com/sun/activation/registries/MimeTypeFile:type_hash	Ljava/util/Hashtable;
    //   20: aload_0
    //   21: aload_1
    //   22: putfield 14	com/sun/activation/registries/MimeTypeFile:fname	Ljava/lang/String;
    //   25: new 41	java/io/FileReader
    //   28: dup
    //   29: new 43	java/io/File
    //   32: dup
    //   33: aload_0
    //   34: getfield 14	com/sun/activation/registries/MimeTypeFile:fname	Ljava/lang/String;
    //   37: invokespecial 45	java/io/File:<init>	(Ljava/lang/String;)V
    //   40: invokespecial 48	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   43: astore_2
    //   44: aload_0
    //   45: new 24	java/io/BufferedReader
    //   48: dup
    //   49: aload_2
    //   50: invokespecial 34	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   53: invokespecial 38	com/sun/activation/registries/MimeTypeFile:parse	(Ljava/io/BufferedReader;)V
    //   56: aload_2
    //   57: invokevirtual 51	java/io/FileReader:close	()V
    //   60: return
    //   61: astore_3
    //   62: aload_2
    //   63: invokevirtual 51	java/io/FileReader:close	()V
    //   66: aload_3
    //   67: athrow
    //   68: astore 4
    //   70: goto -4 -> 66
    //   73: astore 5
    //   75: goto -15 -> 60
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	78	0	this	MimeTypeFile
    //   0	78	1	paramString	String
    //   43	20	2	localFileReader	java.io.FileReader
    //   61	6	3	localObject	Object
    //   68	1	4	localIOException1	IOException
    //   73	1	5	localIOException2	IOException
    // Exception table:
    //   from	to	target	type
    //   44	56	61	finally
    //   62	66	68	java/io/IOException
    //   56	60	73	java/io/IOException
  }
  
  private void parse(BufferedReader paramBufferedReader)
    throws IOException
  {
    String str1 = null;
    for (;;)
    {
      String str2 = paramBufferedReader.readLine();
      if (str2 == null)
      {
        if (str1 != null) {
          parseEntry(str1);
        }
        return;
      }
      if (str1 == null) {}
      for (String str3 = str2;; str3 = str1 + str2)
      {
        int i = str3.length();
        if ((str3.length() <= 0) || (str3.charAt(i - 1) != '\\')) {
          break label94;
        }
        str1 = str3.substring(0, i - 1);
        break;
      }
      label94:
      parseEntry(str3);
      str1 = null;
    }
  }
  
  private void parseEntry(String paramString)
  {
    Object localObject = null;
    String str1 = paramString.trim();
    if (str1.length() == 0)
    {
      return;
      break label44;
    }
    for (;;)
    {
      label14:
      LineTokenizer localLineTokenizer;
      if (str1.charAt(0) != '#')
      {
        if (str1.indexOf('=') > 0) {
          localLineTokenizer = new LineTokenizer(str1);
        }
      }
      else {
        for (;;)
        {
          label44:
          String str2;
          String str3;
          if (localLineTokenizer.hasMoreTokens())
          {
            str2 = localLineTokenizer.nextToken();
            str3 = null;
            if ((localLineTokenizer.hasMoreTokens()) && (localLineTokenizer.nextToken().equals("=")) && (localLineTokenizer.hasMoreTokens())) {
              str3 = localLineTokenizer.nextToken();
            }
            if (str3 == null)
            {
              if (!LogSupport.isLoggable()) {
                break label14;
              }
              LogSupport.log("Bad .mime.types entry: " + str1);
              break label14;
              break label14;
            }
            if (!str2.equals("type")) {
              break label147;
            }
            localObject = str3;
            continue;
          }
          break label14;
          label147:
          if (!str2.equals("exts")) {
            break;
          }
          StringTokenizer localStringTokenizer1 = new StringTokenizer(str3, ",");
          while (localStringTokenizer1.hasMoreTokens())
          {
            String str4 = localStringTokenizer1.nextToken();
            MimeTypeEntry localMimeTypeEntry1 = new MimeTypeEntry(localObject, str4);
            this.type_hash.put(str4, localMimeTypeEntry1);
            if (LogSupport.isLoggable()) {
              LogSupport.log("Added: " + localMimeTypeEntry1.toString());
            }
          }
        }
      }
      StringTokenizer localStringTokenizer2 = new StringTokenizer(str1);
      if (localStringTokenizer2.countTokens() == 0) {
        break;
      }
      String str5 = localStringTokenizer2.nextToken();
      while (localStringTokenizer2.hasMoreTokens())
      {
        String str6 = localStringTokenizer2.nextToken();
        MimeTypeEntry localMimeTypeEntry2 = new MimeTypeEntry(str5, str6);
        this.type_hash.put(str6, localMimeTypeEntry2);
        if (LogSupport.isLoggable()) {
          LogSupport.log("Added: " + localMimeTypeEntry2.toString());
        }
      }
    }
  }
  
  public void appendToRegistry(String paramString)
  {
    try
    {
      parse(new BufferedReader(new StringReader(paramString)));
      label19:
      return;
    }
    catch (IOException localIOException)
    {
      break label19;
    }
  }
  
  public String getMIMETypeString(String paramString)
  {
    MimeTypeEntry localMimeTypeEntry = getMimeTypeEntry(paramString);
    if (localMimeTypeEntry != null) {}
    for (String str = localMimeTypeEntry.getMIMEType();; str = null) {
      return str;
    }
  }
  
  public MimeTypeEntry getMimeTypeEntry(String paramString)
  {
    return (MimeTypeEntry)this.type_hash.get(paramString);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.activation.registries.MimeTypeFile
 * JD-Core Version:    0.7.0.1
 */