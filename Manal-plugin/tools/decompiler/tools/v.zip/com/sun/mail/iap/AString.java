package com.sun.mail.iap;

class AString
{
  byte[] bytes;
  
  AString(byte[] paramArrayOfByte)
  {
    this.bytes = paramArrayOfByte;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.AString
 * JD-Core Version:    0.7.0.1
 */