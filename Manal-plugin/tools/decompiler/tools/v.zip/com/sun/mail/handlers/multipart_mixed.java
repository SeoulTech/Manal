package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import myjava.awt.datatransfer.DataFlavor;

public class multipart_mixed
  implements DataContentHandler
{
  private ActivationDataFlavor myDF = new ActivationDataFlavor(MimeMultipart.class, "multipart/mixed", "Multipart");
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      MimeMultipart localMimeMultipart = new MimeMultipart(paramDataSource);
      return localMimeMultipart;
    }
    catch (MessagingException localMessagingException)
    {
      IOException localIOException = new IOException("Exception while constructing MimeMultipart");
      localIOException.initCause(localMessagingException);
      throw localIOException;
    }
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.myDF.equals(paramDataFlavor)) {}
    for (Object localObject = getContent(paramDataSource);; localObject = null) {
      return localObject;
    }
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    DataFlavor[] arrayOfDataFlavor = new DataFlavor[1];
    arrayOfDataFlavor[0] = this.myDF;
    return arrayOfDataFlavor;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MimeMultipart)) {}
    try
    {
      ((MimeMultipart)paramObject).writeTo(paramOutputStream);
      return;
    }
    catch (MessagingException localMessagingException)
    {
      throw new IOException(localMessagingException.toString());
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.handlers.multipart_mixed
 * JD-Core Version:    0.7.0.1
 */