package com.sun.mail.imap;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.util.FolderClosedIOException;
import com.sun.mail.util.MessageRemovedIOException;
import java.io.IOException;
import java.io.InputStream;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.MessagingException;

public class IMAPInputStream
  extends InputStream
{
  private static final int slop = 64;
  private int blksize;
  private byte[] buf;
  private int bufcount;
  private int bufpos;
  private int max;
  private IMAPMessage msg;
  private boolean peek;
  private int pos;
  private ByteArray readbuf;
  private String section;
  
  public IMAPInputStream(IMAPMessage paramIMAPMessage, String paramString, int paramInt, boolean paramBoolean)
  {
    this.msg = paramIMAPMessage;
    this.section = paramString;
    this.max = paramInt;
    this.peek = paramBoolean;
    this.pos = 0;
    this.blksize = paramIMAPMessage.getFetchBlockSize();
  }
  
  private void checkSeen()
  {
    if (this.peek) {}
    for (;;)
    {
      return;
      try
      {
        Folder localFolder = this.msg.getFolder();
        if ((localFolder != null) && (localFolder.getMode() != 1) && (!this.msg.isSet(Flags.Flag.SEEN))) {
          this.msg.setFlag(Flags.Flag.SEEN, true);
        }
      }
      catch (MessagingException localMessagingException) {}
    }
  }
  
  private void fill()
    throws IOException
  {
    if ((this.max != -1) && (this.pos >= this.max))
    {
      if (this.pos == 0) {
        checkSeen();
      }
      this.readbuf = null;
    }
    for (;;)
    {
      return;
      if (this.readbuf == null) {
        this.readbuf = new ByteArray(64 + this.blksize);
      }
      ByteArray localByteArray;
      try
      {
        IMAPProtocol localIMAPProtocol;
        synchronized (this.msg.getMessageCacheLock())
        {
          try
          {
            localIMAPProtocol = this.msg.getProtocol();
            if (this.msg.isExpunged()) {
              throw new MessageRemovedIOException("No content for expunged message");
            }
          }
          catch (ProtocolException localProtocolException)
          {
            forceCheckExpunged();
            throw new IOException(localProtocolException.getMessage());
          }
        }
        int i = this.msg.getSequenceNumber();
        int j = this.blksize;
        if ((this.max != -1) && (this.pos + this.blksize > this.max)) {
          j = this.max - this.pos;
        }
        BODY localBODY2;
        if (this.peek) {
          localBODY2 = localIMAPProtocol.peekBody(i, this.section, this.pos, j, this.readbuf);
        }
        BODY localBODY1;
        for (Object localObject3 = localBODY2;; localObject3 = localBODY1)
        {
          if (localObject3 != null)
          {
            localByteArray = ((BODY)localObject3).getByteArray();
            if (localByteArray != null) {
              break;
            }
          }
          forceCheckExpunged();
          throw new IOException("No content");
          localBODY1 = localIMAPProtocol.fetchBody(i, this.section, this.pos, j, this.readbuf);
        }
      }
      catch (FolderClosedException localFolderClosedException)
      {
        throw new FolderClosedIOException(localFolderClosedException.getFolder(), localFolderClosedException.getMessage());
      }
      if (this.pos == 0) {
        checkSeen();
      }
      this.buf = localByteArray.getBytes();
      this.bufpos = localByteArray.getStart();
      int k = localByteArray.getCount();
      this.bufcount = (k + this.bufpos);
      this.pos = (k + this.pos);
    }
  }
  
  private void forceCheckExpunged()
    throws MessageRemovedIOException, FolderClosedIOException
  {
    try
    {
      synchronized (this.msg.getMessageCacheLock())
      {
        try
        {
          this.msg.getProtocol().noop();
          label20:
          if (this.msg.isExpunged()) {
            throw new MessageRemovedIOException();
          }
        }
        catch (ConnectionException localConnectionException)
        {
          throw new FolderClosedIOException(this.msg.getFolder(), localConnectionException.getMessage());
        }
      }
    }
    catch (FolderClosedException localFolderClosedException)
    {
      throw new FolderClosedIOException(localFolderClosedException.getFolder(), localFolderClosedException.getMessage());
      return;
    }
    catch (ProtocolException localProtocolException)
    {
      break label20;
    }
  }
  
  public int available()
    throws IOException
  {
    try
    {
      int i = this.bufcount;
      int j = this.bufpos;
      int k = i - j;
      return k;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public int read()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 152	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   6: aload_0
    //   7: getfield 157	com/sun/mail/imap/IMAPInputStream:bufcount	I
    //   10: if_icmplt +35 -> 45
    //   13: aload_0
    //   14: invokespecial 168	com/sun/mail/imap/IMAPInputStream:fill	()V
    //   17: aload_0
    //   18: getfield 152	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   21: istore 6
    //   23: aload_0
    //   24: getfield 157	com/sun/mail/imap/IMAPInputStream:bufcount	I
    //   27: istore 7
    //   29: iload 6
    //   31: iload 7
    //   33: if_icmplt +12 -> 45
    //   36: bipush 255
    //   38: istore 5
    //   40: aload_0
    //   41: monitorexit
    //   42: iload 5
    //   44: ireturn
    //   45: aload_0
    //   46: getfield 147	com/sun/mail/imap/IMAPInputStream:buf	[B
    //   49: astore_2
    //   50: aload_0
    //   51: getfield 152	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   54: istore_3
    //   55: aload_0
    //   56: iload_3
    //   57: iconst_1
    //   58: iadd
    //   59: putfield 152	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   62: aload_2
    //   63: iload_3
    //   64: baload
    //   65: istore 4
    //   67: iload 4
    //   69: sipush 255
    //   72: iand
    //   73: istore 5
    //   75: goto -35 -> 40
    //   78: astore_1
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_1
    //   82: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	83	0	this	IMAPInputStream
    //   78	4	1	localObject	Object
    //   49	14	2	arrayOfByte	byte[]
    //   54	10	3	i	int
    //   65	8	4	j	int
    //   38	36	5	k	int
    //   21	13	6	m	int
    //   27	7	7	n	int
    // Exception table:
    //   from	to	target	type
    //   2	29	78	finally
    //   45	67	78	finally
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    for (;;)
    {
      try
      {
        int i = this.bufcount - this.bufpos;
        int j;
        if (i <= 0)
        {
          fill();
          int k = this.bufcount;
          int m = this.bufpos;
          i = k - m;
          if (i <= 0)
          {
            j = -1;
            return j;
          }
        }
        if (i < paramInt2)
        {
          j = i;
          System.arraycopy(this.buf, this.bufpos, paramArrayOfByte, paramInt1, j);
          this.bufpos = (j + this.bufpos);
        }
        else
        {
          j = paramInt2;
        }
      }
      finally {}
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.IMAPInputStream
 * JD-Core Version:    0.7.0.1
 */