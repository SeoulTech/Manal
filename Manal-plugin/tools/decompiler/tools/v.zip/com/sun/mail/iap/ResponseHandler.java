package com.sun.mail.iap;

public abstract interface ResponseHandler
{
  public abstract void handleResponse(Response paramResponse);
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.ResponseHandler
 * JD-Core Version:    0.7.0.1
 */