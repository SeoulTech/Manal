package com.sun.mail.dsn;

import java.io.IOException;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MultipartReport
  extends MimeMultipart
{
  protected boolean constructed;
  
  public MultipartReport()
    throws MessagingException
  {
    super("report");
    setBodyPart(new MimeBodyPart(), 0);
    setBodyPart(new MimeBodyPart(), 1);
    this.constructed = true;
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus)
    throws MessagingException
  {
    super("report");
    ContentType localContentType = new ContentType(this.contentType);
    localContentType.setParameter("report-type", "delivery-status");
    this.contentType = localContentType.toString();
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setText(paramString);
    setBodyPart(localMimeBodyPart1, 0);
    MimeBodyPart localMimeBodyPart2 = new MimeBodyPart();
    localMimeBodyPart2.setContent(paramDeliveryStatus, "message/delivery-status");
    setBodyPart(localMimeBodyPart2, 1);
    this.constructed = true;
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus, InternetHeaders paramInternetHeaders)
    throws MessagingException
  {
    this(paramString, paramDeliveryStatus);
    if (paramInternetHeaders != null)
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new MessageHeaders(paramInternetHeaders), "text/rfc822-headers");
      setBodyPart(localMimeBodyPart, 2);
    }
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus, MimeMessage paramMimeMessage)
    throws MessagingException
  {
    this(paramString, paramDeliveryStatus);
    if (paramMimeMessage != null)
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(paramMimeMessage, "message/rfc822");
      setBodyPart(localMimeBodyPart, 2);
    }
  }
  
  public MultipartReport(DataSource paramDataSource)
    throws MessagingException
  {
    super(paramDataSource);
    parse();
    this.constructed = true;
  }
  
  private void setBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        this.parts = new Vector();
      }
      if (paramInt < this.parts.size()) {
        super.removeBodyPart(paramInt);
      }
      super.addBodyPart(paramBodyPart, paramInt);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      if (!this.constructed)
      {
        super.addBodyPart(paramBodyPart);
        return;
      }
      throw new MessagingException("Can't add body parts to multipart/report 1");
    }
    finally {}
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      throw new MessagingException("Can't add body parts to multipart/report 2");
    }
    finally {}
  }
  
  /* Error */
  public DeliveryStatus getDeliveryStatus()
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokevirtual 106	com/sun/mail/dsn/MultipartReport:getCount	()I
    //   8: istore_3
    //   9: iload_3
    //   10: iconst_2
    //   11: if_icmpge +7 -> 18
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: aload_0
    //   19: iconst_1
    //   20: invokevirtual 110	com/sun/mail/dsn/MultipartReport:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   23: astore 4
    //   25: aload 4
    //   27: ldc 50
    //   29: invokevirtual 116	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   32: istore 5
    //   34: iload 5
    //   36: ifeq -22 -> 14
    //   39: aload 4
    //   41: invokevirtual 120	javax/mail/BodyPart:getContent	()Ljava/lang/Object;
    //   44: checkcast 122	com/sun/mail/dsn/DeliveryStatus
    //   47: astore_1
    //   48: goto -34 -> 14
    //   51: astore 6
    //   53: new 10	javax/mail/MessagingException
    //   56: dup
    //   57: ldc 124
    //   59: aload 6
    //   61: invokespecial 127	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   64: athrow
    //   65: astore_2
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_2
    //   69: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	70	0	this	MultipartReport
    //   1	47	1	localDeliveryStatus	DeliveryStatus
    //   65	4	2	localObject	Object
    //   8	4	3	i	int
    //   23	17	4	localBodyPart	BodyPart
    //   32	3	5	bool	boolean
    //   51	9	6	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   39	48	51	java/io/IOException
    //   4	9	65	finally
    //   18	34	65	finally
    //   39	48	65	finally
    //   53	65	65	finally
  }
  
  /* Error */
  public MimeMessage getReturnedMessage()
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokevirtual 106	com/sun/mail/dsn/MultipartReport:getCount	()I
    //   8: istore_3
    //   9: iload_3
    //   10: iconst_3
    //   11: if_icmpge +7 -> 18
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: aload_0
    //   19: iconst_2
    //   20: invokevirtual 110	com/sun/mail/dsn/MultipartReport:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   23: astore 4
    //   25: aload 4
    //   27: ldc 67
    //   29: invokevirtual 116	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   32: ifne +17 -> 49
    //   35: aload 4
    //   37: ldc 64
    //   39: invokevirtual 116	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   42: istore 6
    //   44: iload 6
    //   46: ifeq -32 -> 14
    //   49: aload 4
    //   51: invokevirtual 120	javax/mail/BodyPart:getContent	()Ljava/lang/Object;
    //   54: checkcast 131	javax/mail/internet/MimeMessage
    //   57: astore_1
    //   58: goto -44 -> 14
    //   61: astore 5
    //   63: new 10	javax/mail/MessagingException
    //   66: dup
    //   67: ldc 133
    //   69: aload 5
    //   71: invokespecial 127	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   74: athrow
    //   75: astore_2
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_2
    //   79: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	80	0	this	MultipartReport
    //   1	57	1	localMimeMessage	MimeMessage
    //   75	4	2	localObject	Object
    //   8	4	3	i	int
    //   23	27	4	localBodyPart	BodyPart
    //   61	9	5	localIOException	IOException
    //   42	3	6	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   49	58	61	java/io/IOException
    //   4	9	75	finally
    //   18	44	75	finally
    //   49	58	75	finally
    //   63	75	75	finally
  }
  
  public String getText()
    throws MessagingException
  {
    for (;;)
    {
      try
      {
        BodyPart localBodyPart1 = getBodyPart(0);
        if (localBodyPart1.isMimeType("text/plain"))
        {
          str = (String)localBodyPart1.getContent();
          return str;
        }
        if (localBodyPart1.isMimeType("multipart/alternative"))
        {
          Multipart localMultipart = (Multipart)localBodyPart1.getContent();
          int i = 0;
          if (i < localMultipart.getCount())
          {
            BodyPart localBodyPart2 = localMultipart.getBodyPart(i);
            if (localBodyPart2.isMimeType("text/plain"))
            {
              str = (String)localBodyPart2.getContent();
              continue;
            }
            i++;
            continue;
          }
        }
        String str = null;
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("Exception getting text content", localIOException);
      }
      finally {}
    }
  }
  
  public MimeBodyPart getTextBodyPart()
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = (MimeBodyPart)getBodyPart(0);
      return localMimeBodyPart;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeBodyPart(int paramInt)
    throws MessagingException
  {
    throw new MessagingException("Can't remove body parts from multipart/report");
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    throw new MessagingException("Can't remove body parts from multipart/report");
  }
  
  public void setDeliveryStatus(DeliveryStatus paramDeliveryStatus)
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(paramDeliveryStatus, "message/delivery-status");
      setBodyPart(localMimeBodyPart, 2);
      ContentType localContentType = new ContentType(this.contentType);
      localContentType.setParameter("report-type", "delivery-status");
      this.contentType = localContentType.toString();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void setReturnedMessage(MimeMessage paramMimeMessage)
    throws MessagingException
  {
    if (paramMimeMessage == null) {}
    try
    {
      ((BodyPart)this.parts.elementAt(2));
      super.removeBodyPart(2);
      return;
    }
    finally {}
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    if ((paramMimeMessage instanceof MessageHeaders)) {
      localMimeBodyPart.setContent(paramMimeMessage, "text/rfc822-headers");
    }
    for (;;)
    {
      setBodyPart(localMimeBodyPart, 2);
      break;
      localMimeBodyPart.setContent(paramMimeMessage, "message/rfc822");
    }
  }
  
  public void setSubType(String paramString)
    throws MessagingException
  {
    try
    {
      throw new MessagingException("Can't change subtype of MultipartReport");
    }
    finally {}
  }
  
  public void setText(String paramString)
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setText(paramString);
      setBodyPart(localMimeBodyPart, 0);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void setTextBodyPart(MimeBodyPart paramMimeBodyPart)
    throws MessagingException
  {
    try
    {
      setBodyPart(paramMimeBodyPart, 0);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.dsn.MultipartReport
 * JD-Core Version:    0.7.0.1
 */