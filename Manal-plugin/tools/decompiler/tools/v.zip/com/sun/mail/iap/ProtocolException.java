package com.sun.mail.iap;

public class ProtocolException
  extends Exception
{
  private static final long serialVersionUID = -4360500807971797439L;
  protected transient Response response = null;
  
  public ProtocolException() {}
  
  public ProtocolException(Response paramResponse)
  {
    super(paramResponse.toString());
    this.response = paramResponse;
  }
  
  public ProtocolException(String paramString)
  {
    super(paramString);
  }
  
  public Response getResponse()
  {
    return this.response;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.ProtocolException
 * JD-Core Version:    0.7.0.1
 */