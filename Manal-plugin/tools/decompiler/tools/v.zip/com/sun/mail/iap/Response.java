package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Vector;

public class Response
{
  public static final int BAD = 12;
  public static final int BYE = 16;
  public static final int CONTINUATION = 1;
  public static final int NO = 8;
  public static final int OK = 4;
  public static final int SYNTHETIC = 32;
  public static final int TAGGED = 2;
  public static final int TAG_MASK = 3;
  public static final int TYPE_MASK = 28;
  public static final int UNTAGGED = 3;
  private static final int increment = 100;
  protected byte[] buffer = null;
  protected int index;
  protected int pindex;
  protected int size;
  protected String tag = null;
  protected int type = 0;
  
  public Response(Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    ByteArray localByteArray1 = paramProtocol.getResponseBuffer();
    ByteArray localByteArray2 = paramProtocol.getInputStream().readResponse(localByteArray1);
    this.buffer = localByteArray2.getBytes();
    this.size = (-2 + localByteArray2.getCount());
    parse();
  }
  
  public Response(Response paramResponse)
  {
    this.index = paramResponse.index;
    this.size = paramResponse.size;
    this.buffer = paramResponse.buffer;
    this.type = paramResponse.type;
    this.tag = paramResponse.tag;
  }
  
  public Response(String paramString)
  {
    this.buffer = ASCIIUtility.getBytes(paramString);
    this.size = this.buffer.length;
    parse();
  }
  
  public static Response byeResponse(Exception paramException)
  {
    Response localResponse = new Response(("* BYE JavaMail Exception: " + paramException.toString()).replace('\r', ' ').replace('\n', ' '));
    localResponse.type = (0x20 | localResponse.type);
    return localResponse;
  }
  
  private void parse()
  {
    this.index = 0;
    if (this.buffer[this.index] == 43)
    {
      this.type = (0x1 | this.type);
      this.index = (1 + this.index);
      return;
    }
    label74:
    int i;
    String str;
    if (this.buffer[this.index] == 42)
    {
      this.type = (0x3 | this.type);
      this.index = (1 + this.index);
      i = this.index;
      str = readAtom();
      if (str == null) {
        str = "";
      }
      if (!str.equalsIgnoreCase("OK")) {
        break label142;
      }
      this.type = (0x4 | this.type);
    }
    for (;;)
    {
      this.pindex = this.index;
      break;
      this.type = (0x2 | this.type);
      this.tag = readAtom();
      break label74;
      label142:
      if (str.equalsIgnoreCase("NO")) {
        this.type = (0x8 | this.type);
      } else if (str.equalsIgnoreCase("BAD")) {
        this.type = (0xC | this.type);
      } else if (str.equalsIgnoreCase("BYE")) {
        this.type = (0x10 | this.type);
      } else {
        this.index = i;
      }
    }
  }
  
  private Object parseString(boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject = null;
    skipSpaces();
    int i = this.buffer[this.index];
    int i1;
    int i2;
    int i3;
    if (i == 34)
    {
      this.index = (1 + this.index);
      i1 = this.index;
      i2 = this.index;
      i3 = this.buffer[this.index];
      if (i3 == 34)
      {
        this.index = (1 + this.index);
        if (!paramBoolean2) {
          break label150;
        }
        localObject = ASCIIUtility.toString(this.buffer, i1, i2);
      }
    }
    for (;;)
    {
      return localObject;
      if (i3 == 92) {
        this.index = (1 + this.index);
      }
      if (this.index != i2) {
        this.buffer[i2] = this.buffer[this.index];
      }
      i2++;
      this.index = (1 + this.index);
      break;
      label150:
      localObject = new ByteArray(this.buffer, i1, i2 - i1);
      continue;
      if (i == 123)
      {
        int k = 1 + this.index;
        int m;
        int n;
        for (this.index = k;; this.index = (1 + this.index)) {
          for (;;)
          {
            if (this.buffer[this.index] == 125) {}
            try
            {
              m = ASCIIUtility.parseInt(this.buffer, k, this.index);
              n = 3 + this.index;
              this.index = (n + m);
              if (!paramBoolean2) {
                break label279;
              }
              localObject = ASCIIUtility.toString(this.buffer, n, n + m);
            }
            catch (NumberFormatException localNumberFormatException) {}
          }
        }
        continue;
        label279:
        localObject = new ByteArray(this.buffer, n, m);
      }
      else if (paramBoolean1)
      {
        int j = this.index;
        localObject = readAtom();
        if (!paramBoolean2) {
          localObject = new ByteArray(this.buffer, j, this.index);
        }
      }
      else if ((i == 78) || (i == 110))
      {
        this.index = (3 + this.index);
      }
    }
  }
  
  public String getRest()
  {
    skipSpaces();
    return ASCIIUtility.toString(this.buffer, this.index, this.size);
  }
  
  public String getTag()
  {
    return this.tag;
  }
  
  public int getType()
  {
    return this.type;
  }
  
  public boolean isBAD()
  {
    if ((0x1C & this.type) == 12) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isBYE()
  {
    if ((0x1C & this.type) == 16) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isContinuation()
  {
    int i = 1;
    if ((0x3 & this.type) == i) {}
    for (;;)
    {
      return i;
      int j = 0;
    }
  }
  
  public boolean isNO()
  {
    if ((0x1C & this.type) == 8) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isOK()
  {
    if ((0x1C & this.type) == 4) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isSynthetic()
  {
    if ((0x20 & this.type) == 32) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isTagged()
  {
    if ((0x3 & this.type) == 2) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public boolean isUnTagged()
  {
    if ((0x3 & this.type) == 3) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public byte peekByte()
  {
    if (this.index < this.size) {}
    for (byte b = this.buffer[this.index];; b = 0) {
      return b;
    }
  }
  
  public String readAtom()
  {
    return readAtom('\000');
  }
  
  public String readAtom(char paramChar)
  {
    skipSpaces();
    String str;
    if (this.index >= this.size)
    {
      str = null;
      return str;
    }
    int i = this.index;
    for (;;)
    {
      if (this.index < this.size)
      {
        char c = this.buffer[this.index];
        if ((c > ' ') && (c != '(') && (c != ')') && (c != '%') && (c != '*') && (c != '"') && (c != '\\') && (c != '') && ((paramChar == 0) || (c != paramChar))) {}
      }
      else
      {
        str = ASCIIUtility.toString(this.buffer, i, this.index);
        break;
      }
      this.index = (1 + this.index);
    }
  }
  
  public String readAtomString()
  {
    return (String)parseString(true, true);
  }
  
  public byte readByte()
  {
    byte[] arrayOfByte;
    int i;
    if (this.index < this.size)
    {
      arrayOfByte = this.buffer;
      i = this.index;
      this.index = (i + 1);
    }
    for (byte b = arrayOfByte[i];; b = 0) {
      return b;
    }
  }
  
  public ByteArray readByteArray()
  {
    if (isContinuation()) {
      skipSpaces();
    }
    for (ByteArray localByteArray = new ByteArray(this.buffer, this.index, this.size - this.index);; localByteArray = (ByteArray)parseString(false, false)) {
      return localByteArray;
    }
  }
  
  public ByteArrayInputStream readBytes()
  {
    ByteArray localByteArray = readByteArray();
    if (localByteArray != null) {}
    for (ByteArrayInputStream localByteArrayInputStream = localByteArray.toByteArrayInputStream();; localByteArrayInputStream = null) {
      return localByteArrayInputStream;
    }
  }
  
  public long readLong()
  {
    skipSpaces();
    int i = this.index;
    if (((this.index < this.size) && (Character.isDigit((char)this.buffer[this.index]))) || (this.index > i)) {}
    for (;;)
    {
      try
      {
        long l2 = ASCIIUtility.parseLong(this.buffer, i, this.index);
        l1 = l2;
        return l1;
      }
      catch (NumberFormatException localNumberFormatException) {}
      this.index = (1 + this.index);
      break;
      long l1 = -1L;
    }
  }
  
  public int readNumber()
  {
    skipSpaces();
    int i = this.index;
    if (((this.index < this.size) && (Character.isDigit((char)this.buffer[this.index]))) || (this.index > i)) {}
    for (;;)
    {
      try
      {
        int k = ASCIIUtility.parseInt(this.buffer, i, this.index);
        j = k;
        return j;
      }
      catch (NumberFormatException localNumberFormatException) {}
      this.index = (1 + this.index);
      break;
      int j = -1;
    }
  }
  
  public String readString()
  {
    return (String)parseString(false, true);
  }
  
  public String readString(char paramChar)
  {
    skipSpaces();
    String str;
    if (this.index >= this.size)
    {
      str = null;
      return str;
    }
    int i = this.index;
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] == paramChar))
      {
        str = ASCIIUtility.toString(this.buffer, i, this.index);
        break;
      }
      this.index = (1 + this.index);
    }
  }
  
  public String[] readStringList()
  {
    String[] arrayOfString = null;
    skipSpaces();
    if (this.buffer[this.index] != 40) {}
    for (;;)
    {
      return arrayOfString;
      this.index = (1 + this.index);
      Vector localVector = new Vector();
      byte[] arrayOfByte;
      int i;
      do
      {
        localVector.addElement(readString());
        arrayOfByte = this.buffer;
        i = this.index;
        this.index = (i + 1);
      } while (arrayOfByte[i] != 41);
      int j = localVector.size();
      if (j > 0)
      {
        arrayOfString = new String[j];
        localVector.copyInto(arrayOfString);
      }
    }
  }
  
  public void reset()
  {
    this.index = this.pindex;
  }
  
  public void skip(int paramInt)
  {
    this.index = (paramInt + this.index);
  }
  
  public void skipSpaces()
  {
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] != 32)) {
        return;
      }
      this.index = (1 + this.index);
    }
  }
  
  public void skipToken()
  {
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] == 32)) {
        return;
      }
      this.index = (1 + this.index);
    }
  }
  
  public String toString()
  {
    return ASCIIUtility.toString(this.buffer, 0, this.size);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.Response
 * JD-Core Version:    0.7.0.1
 */