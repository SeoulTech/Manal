package com.sun.mail.imap;

import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.IMAPProtocol;

class DefaultFolder$2
  implements IMAPFolder.ProtocolCommand
{
  DefaultFolder$2(DefaultFolder paramDefaultFolder, String paramString) {}
  
  public Object doCommand(IMAPProtocol paramIMAPProtocol)
    throws ProtocolException
  {
    return paramIMAPProtocol.lsub("", this.val$pattern);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.DefaultFolder.2
 * JD-Core Version:    0.7.0.1
 */