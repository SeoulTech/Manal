package com.sun.mail.imap;

import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.IMAPProtocol;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import javax.activation.DataHandler;
import javax.mail.FolderClosedException;
import javax.mail.IllegalWriteException;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParameterList;

public class IMAPBodyPart
  extends MimeBodyPart
{
  private BODYSTRUCTURE bs;
  private String description;
  private boolean headersLoaded = false;
  private IMAPMessage message;
  private String sectionId;
  private String type;
  
  protected IMAPBodyPart(BODYSTRUCTURE paramBODYSTRUCTURE, String paramString, IMAPMessage paramIMAPMessage)
  {
    this.bs = paramBODYSTRUCTURE;
    this.sectionId = paramString;
    this.message = paramIMAPMessage;
    this.type = new ContentType(paramBODYSTRUCTURE.type, paramBODYSTRUCTURE.subtype, paramBODYSTRUCTURE.cParams).toString();
  }
  
  /* Error */
  private void loadHeaders()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 21	com/sun/mail/imap/IMAPBodyPart:headersLoaded	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   18: ifnonnull +14 -> 32
    //   21: aload_0
    //   22: new 61	javax/mail/internet/InternetHeaders
    //   25: dup
    //   26: invokespecial 62	javax/mail/internet/InternetHeaders:<init>	()V
    //   29: putfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   32: aload_0
    //   33: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   36: invokevirtual 68	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   39: astore_3
    //   40: aload_3
    //   41: monitorenter
    //   42: aload_0
    //   43: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   46: invokevirtual 72	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   49: astore 7
    //   51: aload_0
    //   52: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   55: invokevirtual 75	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   58: aload 7
    //   60: invokevirtual 81	com/sun/mail/imap/protocol/IMAPProtocol:isREV1	()Z
    //   63: ifeq +146 -> 209
    //   66: aload 7
    //   68: aload_0
    //   69: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   72: invokevirtual 85	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   75: new 87	java/lang/StringBuilder
    //   78: dup
    //   79: aload_0
    //   80: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   83: invokestatic 93	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   86: invokespecial 96	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   89: ldc 98
    //   91: invokevirtual 102	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: invokevirtual 103	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   97: invokevirtual 107	com/sun/mail/imap/protocol/IMAPProtocol:peekBody	(ILjava/lang/String;)Lcom/sun/mail/imap/protocol/BODY;
    //   100: astore 8
    //   102: aload 8
    //   104: ifnonnull +47 -> 151
    //   107: new 51	javax/mail/MessagingException
    //   110: dup
    //   111: ldc 109
    //   113: invokespecial 110	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   116: athrow
    //   117: astore 6
    //   119: new 112	javax/mail/FolderClosedException
    //   122: dup
    //   123: aload_0
    //   124: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   127: invokevirtual 116	com/sun/mail/imap/IMAPMessage:getFolder	()Ljavax/mail/Folder;
    //   130: aload 6
    //   132: invokevirtual 119	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   135: invokespecial 122	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   138: athrow
    //   139: astore 5
    //   141: aload_3
    //   142: monitorexit
    //   143: aload 5
    //   145: athrow
    //   146: astore_1
    //   147: aload_0
    //   148: monitorexit
    //   149: aload_1
    //   150: athrow
    //   151: aload 8
    //   153: invokevirtual 128	com/sun/mail/imap/protocol/BODY:getByteArrayInputStream	()Ljava/io/ByteArrayInputStream;
    //   156: astore 9
    //   158: aload 9
    //   160: ifnonnull +30 -> 190
    //   163: new 51	javax/mail/MessagingException
    //   166: dup
    //   167: ldc 109
    //   169: invokespecial 110	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   172: athrow
    //   173: astore 4
    //   175: new 51	javax/mail/MessagingException
    //   178: dup
    //   179: aload 4
    //   181: invokevirtual 129	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   184: aload 4
    //   186: invokespecial 132	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   189: athrow
    //   190: aload_0
    //   191: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   194: aload 9
    //   196: invokevirtual 136	javax/mail/internet/InternetHeaders:load	(Ljava/io/InputStream;)V
    //   199: aload_3
    //   200: monitorexit
    //   201: aload_0
    //   202: iconst_1
    //   203: putfield 21	com/sun/mail/imap/IMAPBodyPart:headersLoaded	Z
    //   206: goto -195 -> 11
    //   209: aload_0
    //   210: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   213: ldc 138
    //   215: aload_0
    //   216: getfield 48	com/sun/mail/imap/IMAPBodyPart:type	Ljava/lang/String;
    //   219: invokevirtual 142	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   222: aload_0
    //   223: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   226: ldc 144
    //   228: aload_0
    //   229: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   232: getfield 147	com/sun/mail/imap/protocol/BODYSTRUCTURE:encoding	Ljava/lang/String;
    //   235: invokevirtual 142	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   238: aload_0
    //   239: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   242: getfield 149	com/sun/mail/imap/protocol/BODYSTRUCTURE:description	Ljava/lang/String;
    //   245: ifnull +19 -> 264
    //   248: aload_0
    //   249: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   252: ldc 151
    //   254: aload_0
    //   255: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   258: getfield 149	com/sun/mail/imap/protocol/BODYSTRUCTURE:description	Ljava/lang/String;
    //   261: invokevirtual 142	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   264: aload_0
    //   265: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   268: getfield 154	com/sun/mail/imap/protocol/BODYSTRUCTURE:id	Ljava/lang/String;
    //   271: ifnull +19 -> 290
    //   274: aload_0
    //   275: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   278: ldc 156
    //   280: aload_0
    //   281: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   284: getfield 154	com/sun/mail/imap/protocol/BODYSTRUCTURE:id	Ljava/lang/String;
    //   287: invokevirtual 142	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   290: aload_0
    //   291: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   294: getfield 159	com/sun/mail/imap/protocol/BODYSTRUCTURE:md5	Ljava/lang/String;
    //   297: ifnull -98 -> 199
    //   300: aload_0
    //   301: getfield 59	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   304: ldc 161
    //   306: aload_0
    //   307: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   310: getfield 159	com/sun/mail/imap/protocol/BODYSTRUCTURE:md5	Ljava/lang/String;
    //   313: invokevirtual 142	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   316: goto -117 -> 199
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	319	0	this	IMAPBodyPart
    //   146	4	1	localObject1	Object
    //   6	2	2	bool	boolean
    //   173	12	4	localProtocolException	ProtocolException
    //   139	5	5	localObject3	Object
    //   117	14	6	localConnectionException	ConnectionException
    //   49	18	7	localIMAPProtocol	IMAPProtocol
    //   100	52	8	localBODY	BODY
    //   156	39	9	localByteArrayInputStream	ByteArrayInputStream
    // Exception table:
    //   from	to	target	type
    //   42	117	117	com/sun/mail/iap/ConnectionException
    //   151	173	117	com/sun/mail/iap/ConnectionException
    //   190	199	117	com/sun/mail/iap/ConnectionException
    //   209	316	117	com/sun/mail/iap/ConnectionException
    //   42	117	139	finally
    //   119	143	139	finally
    //   151	173	139	finally
    //   175	190	139	finally
    //   190	199	139	finally
    //   199	201	139	finally
    //   209	316	139	finally
    //   2	7	146	finally
    //   14	42	146	finally
    //   143	146	146	finally
    //   201	206	146	finally
    //   42	117	173	com/sun/mail/iap/ProtocolException
    //   151	173	173	com/sun/mail/iap/ProtocolException
    //   190	199	173	com/sun/mail/iap/ProtocolException
    //   209	316	173	com/sun/mail/iap/ProtocolException
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    loadHeaders();
    return super.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    loadHeaders();
    return super.getAllHeaders();
  }
  
  public String getContentID()
    throws MessagingException
  {
    return this.bs.id;
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    return this.bs.md5;
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    Object localObject1 = null;
    boolean bool = this.message.getPeek();
    for (;;)
    {
      try
      {
        synchronized (this.message.getMessageCacheLock())
        {
          try
          {
            IMAPProtocol localIMAPProtocol = this.message.getProtocol();
            this.message.checkExpunged();
            if ((localIMAPProtocol.isREV1()) && (this.message.getFetchBlockSize() != -1))
            {
              localObject5 = new IMAPInputStream(this.message, this.sectionId, this.bs.size, bool);
              return localObject5;
            }
            int i = this.message.getSequenceNumber();
            Object localObject4;
            if (bool)
            {
              localObject4 = localIMAPProtocol.peekBody(i, this.sectionId);
              if (localObject4 != null)
              {
                ByteArrayInputStream localByteArrayInputStream = ((BODY)localObject4).getByteArrayInputStream();
                localObject1 = localByteArrayInputStream;
              }
              if (localObject1 == null) {
                throw new MessagingException("No content");
              }
            }
            else
            {
              BODY localBODY = localIMAPProtocol.fetchBody(i, this.sectionId);
              localObject4 = localBODY;
              continue;
              localObject3 = finally;
            }
          }
          catch (ConnectionException localConnectionException)
          {
            throw new FolderClosedException(this.message.getFolder(), localConnectionException.getMessage());
          }
        }
        Object localObject5 = localObject1;
      }
      catch (ProtocolException localProtocolException)
      {
        throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
      }
    }
  }
  
  public String getContentType()
    throws MessagingException
  {
    return this.type;
  }
  
  /* Error */
  public DataHandler getDataHandler()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 207	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   6: ifnonnull +47 -> 53
    //   9: aload_0
    //   10: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   13: invokevirtual 210	com/sun/mail/imap/protocol/BODYSTRUCTURE:isMulti	()Z
    //   16: ifeq +46 -> 62
    //   19: aload_0
    //   20: new 212	javax/activation/DataHandler
    //   23: dup
    //   24: new 214	com/sun/mail/imap/IMAPMultipartDataSource
    //   27: dup
    //   28: aload_0
    //   29: aload_0
    //   30: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   33: getfield 218	com/sun/mail/imap/protocol/BODYSTRUCTURE:bodies	[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   36: aload_0
    //   37: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   40: aload_0
    //   41: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   44: invokespecial 221	com/sun/mail/imap/IMAPMultipartDataSource:<init>	(Ljavax/mail/internet/MimePart;[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;Ljava/lang/String;Lcom/sun/mail/imap/IMAPMessage;)V
    //   47: invokespecial 224	javax/activation/DataHandler:<init>	(Ljavax/activation/DataSource;)V
    //   50: putfield 207	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   53: aload_0
    //   54: invokespecial 226	javax/mail/internet/MimeBodyPart:getDataHandler	()Ljavax/activation/DataHandler;
    //   57: astore_2
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_2
    //   61: areturn
    //   62: aload_0
    //   63: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   66: invokevirtual 229	com/sun/mail/imap/protocol/BODYSTRUCTURE:isNested	()Z
    //   69: ifeq -16 -> 53
    //   72: aload_0
    //   73: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   76: invokevirtual 230	com/sun/mail/imap/IMAPMessage:isREV1	()Z
    //   79: ifeq -26 -> 53
    //   82: aload_0
    //   83: new 212	javax/activation/DataHandler
    //   86: dup
    //   87: new 232	com/sun/mail/imap/IMAPNestedMessage
    //   90: dup
    //   91: aload_0
    //   92: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   95: aload_0
    //   96: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   99: getfield 218	com/sun/mail/imap/protocol/BODYSTRUCTURE:bodies	[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   102: iconst_0
    //   103: aaload
    //   104: aload_0
    //   105: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   108: getfield 236	com/sun/mail/imap/protocol/BODYSTRUCTURE:envelope	Lcom/sun/mail/imap/protocol/ENVELOPE;
    //   111: aload_0
    //   112: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   115: invokespecial 239	com/sun/mail/imap/IMAPNestedMessage:<init>	(Lcom/sun/mail/imap/IMAPMessage;Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;Lcom/sun/mail/imap/protocol/ENVELOPE;Ljava/lang/String;)V
    //   118: aload_0
    //   119: getfield 48	com/sun/mail/imap/IMAPBodyPart:type	Ljava/lang/String;
    //   122: invokespecial 242	javax/activation/DataHandler:<init>	(Ljava/lang/Object;Ljava/lang/String;)V
    //   125: putfield 207	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   128: goto -75 -> 53
    //   131: astore_1
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	136	0	this	IMAPBodyPart
    //   131	4	1	localObject	Object
    //   57	4	2	localDataHandler	DataHandler
    // Exception table:
    //   from	to	target	type
    //   2	58	131	finally
    //   62	128	131	finally
  }
  
  public String getDescription()
    throws MessagingException
  {
    String str;
    if (this.description != null) {
      str = this.description;
    }
    for (;;)
    {
      return str;
      if (this.bs.description == null)
      {
        str = null;
        continue;
      }
      try
      {
        this.description = MimeUtility.decodeText(this.bs.description);
        str = this.description;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        for (;;)
        {
          this.description = this.bs.description;
        }
      }
    }
  }
  
  public String getDisposition()
    throws MessagingException
  {
    return this.bs.disposition;
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return this.bs.encoding;
  }
  
  public String getFileName()
    throws MessagingException
  {
    String str = null;
    if (this.bs.dParams != null) {
      str = this.bs.dParams.get("filename");
    }
    if ((str == null) && (this.bs.cParams != null)) {
      str = this.bs.cParams.get("name");
    }
    return str;
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    loadHeaders();
    return super.getHeader(paramString);
  }
  
  public int getLineCount()
    throws MessagingException
  {
    return this.bs.lines;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public int getSize()
    throws MessagingException
  {
    return this.bs.size;
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContent(Object paramObject, String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContent(Multipart paramMultipart)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  protected void updateHeaders() {}
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.IMAPBodyPart
 * JD-Core Version:    0.7.0.1
 */