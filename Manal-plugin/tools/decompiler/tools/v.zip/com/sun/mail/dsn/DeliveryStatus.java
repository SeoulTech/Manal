package com.sun.mail.dsn;

import com.sun.mail.util.LineOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Vector;
import javax.mail.MessagingException;
import javax.mail.internet.InternetHeaders;

public class DeliveryStatus
{
  private static boolean debug = false;
  protected InternetHeaders messageDSN;
  protected InternetHeaders[] recipientDSN;
  
  static
  {
    boolean bool = false;
    try
    {
      String str = System.getProperty("mail.dsn.debug");
      if ((str != null) && (!str.equalsIgnoreCase("false"))) {
        bool = true;
      }
      debug = bool;
      label31:
      return;
    }
    catch (SecurityException localSecurityException)
    {
      break label31;
    }
  }
  
  public DeliveryStatus()
    throws MessagingException
  {
    this.messageDSN = new InternetHeaders();
    this.recipientDSN = new InternetHeaders[0];
  }
  
  public DeliveryStatus(InputStream paramInputStream)
    throws MessagingException, IOException
  {
    this.messageDSN = new InternetHeaders(paramInputStream);
    if (debug) {
      System.out.println("DSN: got messageDSN");
    }
    Vector localVector = new Vector();
    for (;;)
    {
      try
      {
        int i = paramInputStream.available();
        if (i > 0) {
          continue;
        }
      }
      catch (EOFException localEOFException)
      {
        InternetHeaders localInternetHeaders;
        if (!debug) {
          continue;
        }
        System.out.println("DSN: got EOFException");
        continue;
      }
      if (debug) {
        System.out.println("DSN: recipientDSN size " + localVector.size());
      }
      this.recipientDSN = new InternetHeaders[localVector.size()];
      localVector.copyInto(this.recipientDSN);
      return;
      localInternetHeaders = new InternetHeaders(paramInputStream);
      if (debug) {
        System.out.println("DSN: got recipientDSN");
      }
      localVector.addElement(localInternetHeaders);
    }
  }
  
  /* Error */
  private static void writeInternetHeaders(InternetHeaders paramInternetHeaders, LineOutputStream paramLineOutputStream)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 107	javax/mail/internet/InternetHeaders:getAllHeaderLines	()Ljava/util/Enumeration;
    //   4: astore_2
    //   5: aload_2
    //   6: invokeinterface 113 1 0
    //   11: ifne +4 -> 15
    //   14: return
    //   15: aload_1
    //   16: aload_2
    //   17: invokeinterface 117 1 0
    //   22: checkcast 28	java/lang/String
    //   25: invokevirtual 122	com/sun/mail/util/LineOutputStream:writeln	(Ljava/lang/String;)V
    //   28: goto -23 -> 5
    //   31: astore_3
    //   32: aload_3
    //   33: invokevirtual 126	javax/mail/MessagingException:getNextException	()Ljava/lang/Exception;
    //   36: astore 4
    //   38: aload 4
    //   40: instanceof 47
    //   43: ifeq +9 -> 52
    //   46: aload 4
    //   48: checkcast 47	java/io/IOException
    //   51: athrow
    //   52: new 47	java/io/IOException
    //   55: dup
    //   56: new 74	java/lang/StringBuilder
    //   59: dup
    //   60: ldc 128
    //   62: invokespecial 78	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   65: aload_3
    //   66: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   69: invokevirtual 89	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   72: invokespecial 132	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   75: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	76	0	paramInternetHeaders	InternetHeaders
    //   0	76	1	paramLineOutputStream	LineOutputStream
    //   4	13	2	localEnumeration	java.util.Enumeration
    //   31	35	3	localMessagingException	MessagingException
    //   36	11	4	localException	java.lang.Exception
    // Exception table:
    //   from	to	target	type
    //   5	28	31	javax/mail/MessagingException
  }
  
  public void addRecipientDSN(InternetHeaders paramInternetHeaders)
  {
    InternetHeaders[] arrayOfInternetHeaders = new InternetHeaders[1 + this.recipientDSN.length];
    System.arraycopy(this.recipientDSN, 0, arrayOfInternetHeaders, 0, this.recipientDSN.length);
    this.recipientDSN = arrayOfInternetHeaders;
    this.recipientDSN[(-1 + this.recipientDSN.length)] = paramInternetHeaders;
  }
  
  public InternetHeaders getMessageDSN()
  {
    return this.messageDSN;
  }
  
  public InternetHeaders getRecipientDSN(int paramInt)
  {
    return this.recipientDSN[paramInt];
  }
  
  public int getRecipientDSNCount()
  {
    return this.recipientDSN.length;
  }
  
  public void setMessageDSN(InternetHeaders paramInternetHeaders)
  {
    this.messageDSN = paramInternetHeaders;
  }
  
  public String toString()
  {
    return "DeliveryStatus: Reporting-MTA=" + this.messageDSN.getHeader("Reporting-MTA", null) + ", #Recipients=" + this.recipientDSN.length;
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    LineOutputStream localLineOutputStream;
    if ((paramOutputStream instanceof LineOutputStream))
    {
      localLineOutputStream = (LineOutputStream)paramOutputStream;
      writeInternetHeaders(this.messageDSN, localLineOutputStream);
      localLineOutputStream.writeln();
    }
    for (int i = 0;; i++)
    {
      if (i >= this.recipientDSN.length)
      {
        return;
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        break;
      }
      writeInternetHeaders(this.recipientDSN[i], localLineOutputStream);
      localLineOutputStream.writeln();
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.dsn.DeliveryStatus
 * JD-Core Version:    0.7.0.1
 */