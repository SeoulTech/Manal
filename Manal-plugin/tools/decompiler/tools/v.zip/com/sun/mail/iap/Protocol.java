package com.sun.mail.iap;

import com.sun.mail.util.SocketFetcher;
import com.sun.mail.util.TraceInputStream;
import com.sun.mail.util.TraceOutputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Properties;
import java.util.Vector;

public class Protocol
{
  private static final byte[] CRLF;
  private boolean connected = false;
  protected boolean debug;
  private volatile Vector handlers = null;
  protected String host = "localhost";
  private volatile ResponseInputStream input;
  protected PrintStream out;
  private volatile DataOutputStream output;
  protected String prefix;
  protected Properties props;
  protected boolean quote;
  private Socket socket;
  private int tagCounter = 0;
  private volatile long timestamp;
  private TraceInputStream traceInput;
  private TraceOutputStream traceOutput;
  
  static
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = 13;
    arrayOfByte[1] = 10;
    CRLF = arrayOfByte;
  }
  
  public Protocol(InputStream paramInputStream, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException
  {
    this.debug = paramBoolean;
    this.quote = false;
    this.out = System.out;
    this.traceInput = new TraceInputStream(paramInputStream, System.out);
    this.traceInput.setTrace(paramBoolean);
    this.traceInput.setQuote(this.quote);
    this.input = new ResponseInputStream(this.traceInput);
    this.traceOutput = new TraceOutputStream(paramOutputStream, System.out);
    this.traceOutput.setTrace(paramBoolean);
    this.traceOutput.setQuote(this.quote);
    this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
    this.timestamp = System.currentTimeMillis();
  }
  
  /* Error */
  public Protocol(String paramString1, int paramInt, boolean paramBoolean1, PrintStream paramPrintStream, Properties paramProperties, String paramString2, boolean paramBoolean2)
    throws IOException, ProtocolException
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore 8
    //   3: aload_0
    //   4: invokespecial 45	java/lang/Object:<init>	()V
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield 47	com/sun/mail/iap/Protocol:connected	Z
    //   12: aload_0
    //   13: iconst_0
    //   14: putfield 49	com/sun/mail/iap/Protocol:tagCounter	I
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield 51	com/sun/mail/iap/Protocol:handlers	Ljava/util/Vector;
    //   22: aload_0
    //   23: aload_1
    //   24: putfield 55	com/sun/mail/iap/Protocol:host	Ljava/lang/String;
    //   27: aload_0
    //   28: iload_3
    //   29: putfield 57	com/sun/mail/iap/Protocol:debug	Z
    //   32: aload_0
    //   33: aload 4
    //   35: putfield 64	com/sun/mail/iap/Protocol:out	Ljava/io/PrintStream;
    //   38: aload_0
    //   39: aload 5
    //   41: putfield 115	com/sun/mail/iap/Protocol:props	Ljava/util/Properties;
    //   44: aload_0
    //   45: aload 6
    //   47: putfield 117	com/sun/mail/iap/Protocol:prefix	Ljava/lang/String;
    //   50: aload_0
    //   51: aload_1
    //   52: iload_2
    //   53: aload 5
    //   55: aload 6
    //   57: iload 7
    //   59: invokestatic 123	com/sun/mail/util/SocketFetcher:getSocket	(Ljava/lang/String;ILjava/util/Properties;Ljava/lang/String;Z)Ljava/net/Socket;
    //   62: putfield 125	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   65: aload 5
    //   67: ldc 127
    //   69: invokevirtual 133	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   72: astore 10
    //   74: aload 10
    //   76: ifnull +57 -> 133
    //   79: aload 10
    //   81: ldc 135
    //   83: invokevirtual 141	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   86: ifeq +47 -> 133
    //   89: aload_0
    //   90: iload 8
    //   92: putfield 59	com/sun/mail/iap/Protocol:quote	Z
    //   95: aload_0
    //   96: aload 4
    //   98: invokespecial 145	com/sun/mail/iap/Protocol:initStreams	(Ljava/io/PrintStream;)V
    //   101: aload_0
    //   102: aload_0
    //   103: invokevirtual 149	com/sun/mail/iap/Protocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   106: invokevirtual 153	com/sun/mail/iap/Protocol:processGreeting	(Lcom/sun/mail/iap/Response;)V
    //   109: aload_0
    //   110: invokestatic 108	java/lang/System:currentTimeMillis	()J
    //   113: putfield 110	com/sun/mail/iap/Protocol:timestamp	J
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield 47	com/sun/mail/iap/Protocol:connected	Z
    //   121: aload_0
    //   122: getfield 47	com/sun/mail/iap/Protocol:connected	Z
    //   125: ifne +7 -> 132
    //   128: aload_0
    //   129: invokevirtual 156	com/sun/mail/iap/Protocol:disconnect	()V
    //   132: return
    //   133: iconst_0
    //   134: istore 8
    //   136: goto -47 -> 89
    //   139: astore 9
    //   141: aload_0
    //   142: getfield 47	com/sun/mail/iap/Protocol:connected	Z
    //   145: ifne +7 -> 152
    //   148: aload_0
    //   149: invokevirtual 156	com/sun/mail/iap/Protocol:disconnect	()V
    //   152: aload 9
    //   154: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	155	0	this	Protocol
    //   0	155	1	paramString1	String
    //   0	155	2	paramInt	int
    //   0	155	3	paramBoolean1	boolean
    //   0	155	4	paramPrintStream	PrintStream
    //   0	155	5	paramProperties	Properties
    //   0	155	6	paramString2	String
    //   0	155	7	paramBoolean2	boolean
    //   1	134	8	bool	boolean
    //   139	14	9	localObject	Object
    //   72	8	10	str	String
    // Exception table:
    //   from	to	target	type
    //   22	121	139	finally
  }
  
  private void initStreams(PrintStream paramPrintStream)
    throws IOException
  {
    this.traceInput = new TraceInputStream(this.socket.getInputStream(), paramPrintStream);
    this.traceInput.setTrace(this.debug);
    this.traceInput.setQuote(this.quote);
    this.input = new ResponseInputStream(this.traceInput);
    this.traceOutput = new TraceOutputStream(this.socket.getOutputStream(), paramPrintStream);
    this.traceOutput.setTrace(this.debug);
    this.traceOutput.setQuote(this.quote);
    this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
  }
  
  public void addResponseHandler(ResponseHandler paramResponseHandler)
  {
    try
    {
      if (this.handlers == null) {
        this.handlers = new Vector();
      }
      this.handlers.addElement(paramResponseHandler);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public Response[] command(String paramString, Argument paramArgument)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 170	java/util/Vector
    //   5: dup
    //   6: invokespecial 171	java/util/Vector:<init>	()V
    //   9: astore_3
    //   10: iconst_0
    //   11: istore 4
    //   13: aconst_null
    //   14: astore 5
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokevirtual 185	com/sun/mail/iap/Protocol:writeCommand	(Ljava/lang/String;Lcom/sun/mail/iap/Argument;)Ljava/lang/String;
    //   22: astore 15
    //   24: aload 15
    //   26: astore 5
    //   28: iload 4
    //   30: ifeq +64 -> 94
    //   33: aload_3
    //   34: invokevirtual 189	java/util/Vector:size	()I
    //   37: anewarray 191	com/sun/mail/iap/Response
    //   40: astore 13
    //   42: aload_3
    //   43: aload 13
    //   45: invokevirtual 195	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   48: aload_0
    //   49: invokestatic 108	java/lang/System:currentTimeMillis	()J
    //   52: putfield 110	com/sun/mail/iap/Protocol:timestamp	J
    //   55: aload_0
    //   56: monitorexit
    //   57: aload 13
    //   59: areturn
    //   60: astore 14
    //   62: aload_3
    //   63: aload 14
    //   65: invokevirtual 198	com/sun/mail/iap/LiteralException:getResponse	()Lcom/sun/mail/iap/Response;
    //   68: invokevirtual 175	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   71: iconst_1
    //   72: istore 4
    //   74: goto -46 -> 28
    //   77: astore 7
    //   79: aload_3
    //   80: aload 7
    //   82: invokestatic 202	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   85: invokevirtual 175	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   88: iconst_1
    //   89: istore 4
    //   91: goto -63 -> 28
    //   94: aload_0
    //   95: invokevirtual 149	com/sun/mail/iap/Protocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   98: astore 12
    //   100: aload 12
    //   102: astore 11
    //   104: aload_3
    //   105: aload 11
    //   107: invokevirtual 175	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   110: aload 11
    //   112: invokevirtual 206	com/sun/mail/iap/Response:isBYE	()Z
    //   115: ifeq +6 -> 121
    //   118: iconst_1
    //   119: istore 4
    //   121: aload 11
    //   123: invokevirtual 209	com/sun/mail/iap/Response:isTagged	()Z
    //   126: ifeq -98 -> 28
    //   129: aload 11
    //   131: invokevirtual 213	com/sun/mail/iap/Response:getTag	()Ljava/lang/String;
    //   134: aload 5
    //   136: invokevirtual 217	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   139: ifeq -111 -> 28
    //   142: iconst_1
    //   143: istore 4
    //   145: goto -117 -> 28
    //   148: astore 9
    //   150: aload 9
    //   152: invokestatic 202	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   155: astore 10
    //   157: aload 10
    //   159: astore 11
    //   161: goto -57 -> 104
    //   164: astore 8
    //   166: goto -138 -> 28
    //   169: astore 6
    //   171: aload_0
    //   172: monitorexit
    //   173: aload 6
    //   175: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	176	0	this	Protocol
    //   0	176	1	paramString	String
    //   0	176	2	paramArgument	Argument
    //   9	96	3	localVector	Vector
    //   11	133	4	i	int
    //   14	121	5	localObject1	Object
    //   169	5	6	localObject2	Object
    //   77	4	7	localException	java.lang.Exception
    //   164	1	8	localProtocolException	ProtocolException
    //   148	3	9	localIOException	IOException
    //   155	3	10	localResponse1	Response
    //   102	58	11	localObject3	Object
    //   98	3	12	localResponse2	Response
    //   40	18	13	arrayOfResponse	Response[]
    //   60	4	14	localLiteralException	LiteralException
    //   22	3	15	str	String
    // Exception table:
    //   from	to	target	type
    //   16	24	60	com/sun/mail/iap/LiteralException
    //   16	24	77	java/lang/Exception
    //   94	100	148	java/io/IOException
    //   94	100	164	com/sun/mail/iap/ProtocolException
    //   2	10	169	finally
    //   16	24	169	finally
    //   33	55	169	finally
    //   62	88	169	finally
    //   94	100	169	finally
    //   104	157	169	finally
  }
  
  /* Error */
  protected void disconnect()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 125	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull +15 -> 23
    //   11: aload_0
    //   12: getfield 125	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   15: invokevirtual 220	java/net/Socket:close	()V
    //   18: aload_0
    //   19: aconst_null
    //   20: putfield 125	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    //   31: astore_3
    //   32: goto -14 -> 18
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	35	0	this	Protocol
    //   26	4	1	localObject	Object
    //   6	2	2	localSocket	Socket
    //   31	1	3	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   2	7	26	finally
    //   11	18	26	finally
    //   18	23	26	finally
    //   11	18	31	java/io/IOException
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    disconnect();
  }
  
  protected ResponseInputStream getInputStream()
  {
    return this.input;
  }
  
  protected OutputStream getOutputStream()
  {
    return this.output;
  }
  
  protected ByteArray getResponseBuffer()
  {
    return null;
  }
  
  public long getTimestamp()
  {
    return this.timestamp;
  }
  
  public void handleResult(Response paramResponse)
    throws ProtocolException
  {
    if (paramResponse.isOK()) {}
    do
    {
      return;
      if (paramResponse.isNO()) {
        throw new CommandFailedException(paramResponse);
      }
      if (paramResponse.isBAD()) {
        throw new BadCommandException(paramResponse);
      }
    } while (!paramResponse.isBYE());
    disconnect();
    throw new ConnectionException(this, paramResponse);
  }
  
  public void notifyResponseHandlers(Response[] paramArrayOfResponse)
  {
    if (this.handlers == null) {
      return;
    }
    int i = 0;
    label10:
    Response localResponse;
    if (i < paramArrayOfResponse.length)
    {
      localResponse = paramArrayOfResponse[i];
      if (localResponse != null) {
        break label30;
      }
    }
    for (;;)
    {
      i++;
      break label10;
      break;
      label30:
      int j = this.handlers.size();
      if (j == 0) {
        break;
      }
      Object[] arrayOfObject = new Object[j];
      this.handlers.copyInto(arrayOfObject);
      for (int k = 0; k < j; k++) {
        ((ResponseHandler)arrayOfObject[k]).handleResponse(localResponse);
      }
    }
  }
  
  protected void processGreeting(Response paramResponse)
    throws ProtocolException
  {
    if (paramResponse.isBYE()) {
      throw new ConnectionException(this, paramResponse);
    }
  }
  
  public Response readResponse()
    throws IOException, ProtocolException
  {
    return new Response(this);
  }
  
  public void removeResponseHandler(ResponseHandler paramResponseHandler)
  {
    try
    {
      if (this.handlers != null) {
        this.handlers.removeElement(paramResponseHandler);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void simpleCommand(String paramString, Argument paramArgument)
    throws ProtocolException
  {
    Response[] arrayOfResponse = command(paramString, paramArgument);
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[(-1 + arrayOfResponse.length)]);
  }
  
  public void startTLS(String paramString)
    throws IOException, ProtocolException
  {
    try
    {
      simpleCommand(paramString, null);
      this.socket = SocketFetcher.startTLS(this.socket, this.props, this.prefix);
      initStreams(this.out);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  protected boolean supportsNonSyncLiterals()
  {
    return false;
  }
  
  public String writeCommand(String paramString, Argument paramArgument)
    throws IOException, ProtocolException
  {
    StringBuilder localStringBuilder = new StringBuilder("A");
    int i = this.tagCounter;
    this.tagCounter = (i + 1);
    String str = Integer.toString(i, 10);
    this.output.writeBytes(str + " " + paramString);
    if (paramArgument != null)
    {
      this.output.write(32);
      paramArgument.write(this);
    }
    this.output.write(CRLF);
    this.output.flush();
    return str;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.Protocol
 * JD-Core Version:    0.7.0.1
 */