package com.sun.mail.imap;

import com.sun.mail.iap.BadCommandException;
import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.iap.ResponseHandler;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.IMAPResponse;
import com.sun.mail.imap.protocol.ListInfo;
import com.sun.mail.imap.protocol.Status;
import java.io.PrintStream;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import javax.mail.FetchProfile;
import javax.mail.FetchProfile.Item;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Quota;
import javax.mail.Session;
import javax.mail.StoreClosedException;
import javax.mail.UIDFolder;

public class IMAPFolder
  extends Folder
  implements UIDFolder, ResponseHandler
{
  private static final int ABORTING = 2;
  private static final int IDLE = 1;
  private static final int RUNNING = 0;
  protected static final char UNKNOWN_SEPARATOR = '����';
  protected String[] attributes;
  protected Flags availableFlags;
  private Status cachedStatus = null;
  private long cachedStatusTime = 0L;
  private boolean connectionPoolDebug;
  private boolean debug = false;
  private boolean doExpungeNotification = true;
  protected boolean exists = false;
  protected String fullName;
  private int idleState = 0;
  protected boolean isNamespace = false;
  protected Vector messageCache;
  protected Object messageCacheLock;
  protected String name;
  private boolean opened = false;
  private PrintStream out;
  protected Flags permanentFlags;
  protected IMAPProtocol protocol;
  private int realTotal = -1;
  private boolean reallyClosed = true;
  private int recent = -1;
  protected char separator;
  private int total = -1;
  protected int type;
  protected Hashtable uidTable;
  private long uidnext = -1L;
  private long uidvalidity = -1L;
  
  static
  {
    if (!IMAPFolder.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      return;
    }
  }
  
  protected IMAPFolder(ListInfo paramListInfo, IMAPStore paramIMAPStore)
  {
    this(paramListInfo.name, paramListInfo.separator, paramIMAPStore);
    if (paramListInfo.hasInferiors) {
      this.type = (0x2 | this.type);
    }
    if (paramListInfo.canOpen) {
      this.type = (0x1 | this.type);
    }
    this.exists = true;
    this.attributes = paramListInfo.attrs;
  }
  
  protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore)
  {
    super(paramIMAPStore);
    if (paramString == null) {
      throw new NullPointerException("Folder name is null");
    }
    this.fullName = paramString;
    this.separator = paramChar;
    this.messageCacheLock = new Object();
    this.debug = paramIMAPStore.getSession().getDebug();
    this.connectionPoolDebug = paramIMAPStore.getConnectionPoolDebug();
    this.out = paramIMAPStore.getSession().getDebugOut();
    if (this.out == null) {
      this.out = System.out;
    }
    this.isNamespace = false;
    if ((paramChar != 65535) && (paramChar != 0))
    {
      int i = this.fullName.indexOf(paramChar);
      if ((i > 0) && (i == -1 + this.fullName.length()))
      {
        this.fullName = this.fullName.substring(0, i);
        this.isNamespace = true;
      }
    }
  }
  
  protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore, boolean paramBoolean)
  {
    this(paramString, paramChar, paramIMAPStore);
    this.isNamespace = paramBoolean;
  }
  
  private void checkClosed()
  {
    if (this.opened) {
      throw new IllegalStateException("This operation is not allowed on an open folder");
    }
  }
  
  private void checkExists()
    throws MessagingException
  {
    if ((!this.exists) && (!exists())) {
      throw new FolderNotFoundException(this, this.fullName + " not found");
    }
  }
  
  private void checkFlags(Flags paramFlags)
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    if (this.mode != 2) {
      throw new IllegalStateException("Cannot change flags on READ_ONLY folder: " + this.fullName);
    }
  }
  
  private void checkOpened()
    throws FolderClosedException
  {
    assert (Thread.holdsLock(this));
    if (!this.opened)
    {
      if (this.reallyClosed) {
        throw new IllegalStateException("This operation is not allowed on a closed folder");
      }
      throw new FolderClosedException(this, "Lost folder connection to server");
    }
  }
  
  /* Error */
  private void checkRange(int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: iload_1
    //   1: iconst_1
    //   2: if_icmpge +11 -> 13
    //   5: new 299	java/lang/IndexOutOfBoundsException
    //   8: dup
    //   9: invokespecial 300	java/lang/IndexOutOfBoundsException:<init>	()V
    //   12: athrow
    //   13: iload_1
    //   14: aload_0
    //   15: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   18: if_icmpgt +4 -> 22
    //   21: return
    //   22: aload_0
    //   23: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   26: astore_2
    //   27: aload_2
    //   28: monitorenter
    //   29: aload_0
    //   30: iconst_0
    //   31: invokespecial 304	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   34: aload_2
    //   35: monitorexit
    //   36: iload_1
    //   37: aload_0
    //   38: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   41: if_icmple -20 -> 21
    //   44: new 299	java/lang/IndexOutOfBoundsException
    //   47: dup
    //   48: invokespecial 300	java/lang/IndexOutOfBoundsException:<init>	()V
    //   51: athrow
    //   52: astore 5
    //   54: new 288	javax/mail/FolderClosedException
    //   57: dup
    //   58: aload_0
    //   59: aload 5
    //   61: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   64: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   67: athrow
    //   68: astore 4
    //   70: aload_2
    //   71: monitorexit
    //   72: aload 4
    //   74: athrow
    //   75: astore_3
    //   76: new 245	javax/mail/MessagingException
    //   79: dup
    //   80: aload_3
    //   81: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   84: aload_3
    //   85: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   88: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	89	0	this	IMAPFolder
    //   0	89	1	paramInt	int
    //   75	10	3	localProtocolException	ProtocolException
    //   68	5	4	localObject2	Object
    //   52	8	5	localConnectionException	ConnectionException
    // Exception table:
    //   from	to	target	type
    //   29	34	52	com/sun/mail/iap/ConnectionException
    //   29	34	68	finally
    //   34	36	68	finally
    //   54	72	68	finally
    //   76	89	68	finally
    //   29	34	75	com/sun/mail/iap/ProtocolException
  }
  
  private void cleanup(boolean paramBoolean)
  {
    releaseProtocol(paramBoolean);
    this.protocol = null;
    this.messageCache = null;
    this.uidTable = null;
    this.exists = false;
    this.attributes = null;
    this.opened = false;
    this.idleState = 0;
    notifyConnectionListeners(3);
  }
  
  /* Error */
  private void close(boolean paramBoolean1, boolean paramBoolean2)
    throws MessagingException
  {
    // Byte code:
    //   0: getstatic 111	com/sun/mail/imap/IMAPFolder:$assertionsDisabled	Z
    //   3: ifne +18 -> 21
    //   6: aload_0
    //   7: invokestatic 277	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
    //   10: ifne +11 -> 21
    //   13: new 279	java/lang/AssertionError
    //   16: dup
    //   17: invokespecial 280	java/lang/AssertionError:<init>	()V
    //   20: athrow
    //   21: aload_0
    //   22: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   25: astore_3
    //   26: aload_3
    //   27: monitorenter
    //   28: aload_0
    //   29: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   32: ifne +28 -> 60
    //   35: aload_0
    //   36: getfield 146	com/sun/mail/imap/IMAPFolder:reallyClosed	Z
    //   39: ifeq +21 -> 60
    //   42: new 239	java/lang/IllegalStateException
    //   45: dup
    //   46: ldc_w 290
    //   49: invokespecial 242	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   52: athrow
    //   53: astore 4
    //   55: aload_3
    //   56: monitorexit
    //   57: aload 4
    //   59: athrow
    //   60: aload_0
    //   61: iconst_1
    //   62: putfield 146	com/sun/mail/imap/IMAPFolder:reallyClosed	Z
    //   65: aload_0
    //   66: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   69: ifne +6 -> 75
    //   72: aload_3
    //   73: monitorexit
    //   74: return
    //   75: aload_0
    //   76: invokevirtual 329	com/sun/mail/imap/IMAPFolder:waitIfIdle	()V
    //   79: iload_2
    //   80: ifeq +74 -> 154
    //   83: aload_0
    //   84: getfield 168	com/sun/mail/imap/IMAPFolder:debug	Z
    //   87: ifeq +36 -> 123
    //   90: aload_0
    //   91: getfield 206	com/sun/mail/imap/IMAPFolder:out	Ljava/io/PrintStream;
    //   94: new 251	java/lang/StringBuilder
    //   97: dup
    //   98: ldc_w 331
    //   101: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   104: aload_0
    //   105: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   108: invokevirtual 262	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: ldc_w 333
    //   114: invokevirtual 262	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   120: invokevirtual 338	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   123: aload_0
    //   124: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   127: ifnull +10 -> 137
    //   130: aload_0
    //   131: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   134: invokevirtual 343	com/sun/mail/imap/protocol/IMAPProtocol:disconnect	()V
    //   137: aload_0
    //   138: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   141: ifeq +8 -> 149
    //   144: aload_0
    //   145: iconst_1
    //   146: invokespecial 345	com/sun/mail/imap/IMAPFolder:cleanup	(Z)V
    //   149: aload_3
    //   150: monitorexit
    //   151: goto -77 -> 74
    //   154: aload_0
    //   155: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   158: checkcast 186	com/sun/mail/imap/IMAPStore
    //   161: invokevirtual 352	com/sun/mail/imap/IMAPStore:isConnectionPoolFull	()Z
    //   164: ifeq +82 -> 246
    //   167: aload_0
    //   168: getfield 168	com/sun/mail/imap/IMAPFolder:debug	Z
    //   171: ifeq +13 -> 184
    //   174: aload_0
    //   175: getfield 206	com/sun/mail/imap/IMAPFolder:out	Ljava/io/PrintStream;
    //   178: ldc_w 354
    //   181: invokevirtual 338	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   184: iload_1
    //   185: ifeq +10 -> 195
    //   188: aload_0
    //   189: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   192: invokevirtual 356	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   195: aload_0
    //   196: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   199: ifnull -62 -> 137
    //   202: aload_0
    //   203: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   206: invokevirtual 359	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   209: goto -72 -> 137
    //   212: astore 6
    //   214: new 245	javax/mail/MessagingException
    //   217: dup
    //   218: aload 6
    //   220: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   223: aload 6
    //   225: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   228: athrow
    //   229: astore 5
    //   231: aload_0
    //   232: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   235: ifeq +8 -> 243
    //   238: aload_0
    //   239: iconst_1
    //   240: invokespecial 345	com/sun/mail/imap/IMAPFolder:cleanup	(Z)V
    //   243: aload 5
    //   245: athrow
    //   246: iload_1
    //   247: ifne +27 -> 274
    //   250: aload_0
    //   251: getfield 283	com/sun/mail/imap/IMAPFolder:mode	I
    //   254: istore 7
    //   256: iload 7
    //   258: iconst_2
    //   259: if_icmpne +15 -> 274
    //   262: aload_0
    //   263: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   266: aload_0
    //   267: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   270: invokevirtual 363	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   273: pop
    //   274: aload_0
    //   275: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   278: ifnull -141 -> 137
    //   281: aload_0
    //   282: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   285: invokevirtual 356	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   288: goto -151 -> 137
    //   291: astore 8
    //   293: aload_0
    //   294: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   297: ifnull -23 -> 274
    //   300: aload_0
    //   301: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   304: invokevirtual 343	com/sun/mail/imap/protocol/IMAPProtocol:disconnect	()V
    //   307: goto -33 -> 274
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	310	0	this	IMAPFolder
    //   0	310	1	paramBoolean1	boolean
    //   0	310	2	paramBoolean2	boolean
    //   25	125	3	localObject1	Object
    //   53	5	4	localObject2	Object
    //   229	15	5	localObject3	Object
    //   212	12	6	localProtocolException1	ProtocolException
    //   254	6	7	i	int
    //   291	1	8	localProtocolException2	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   28	57	53	finally
    //   60	74	53	finally
    //   137	151	53	finally
    //   231	246	53	finally
    //   75	137	212	com/sun/mail/iap/ProtocolException
    //   154	209	212	com/sun/mail/iap/ProtocolException
    //   250	256	212	com/sun/mail/iap/ProtocolException
    //   274	307	212	com/sun/mail/iap/ProtocolException
    //   75	137	229	finally
    //   154	209	229	finally
    //   214	229	229	finally
    //   250	256	229	finally
    //   262	274	229	finally
    //   274	307	229	finally
    //   262	274	291	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  private Folder[] doList(final String paramString, final boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: invokespecial 370	com/sun/mail/imap/IMAPFolder:isDirectory	()Z
    //   10: ifne +14 -> 24
    //   13: iconst_0
    //   14: anewarray 4	javax/mail/Folder
    //   17: astore 7
    //   19: aload_0
    //   20: monitorexit
    //   21: aload 7
    //   23: areturn
    //   24: aload_0
    //   25: invokevirtual 374	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   28: istore 4
    //   30: aload_0
    //   31: new 32	com/sun/mail/imap/IMAPFolder$2
    //   34: dup
    //   35: aload_0
    //   36: iload_2
    //   37: iload 4
    //   39: aload_1
    //   40: invokespecial 377	com/sun/mail/imap/IMAPFolder$2:<init>	(Lcom/sun/mail/imap/IMAPFolder;ZCLjava/lang/String;)V
    //   43: invokevirtual 381	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   46: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   49: astore 5
    //   51: aload 5
    //   53: ifnonnull +12 -> 65
    //   56: iconst_0
    //   57: anewarray 4	javax/mail/Folder
    //   60: astore 7
    //   62: goto -43 -> 19
    //   65: iconst_0
    //   66: istore 6
    //   68: aload 5
    //   70: arraylength
    //   71: ifle +41 -> 112
    //   74: aload 5
    //   76: iconst_0
    //   77: aaload
    //   78: getfield 117	com/sun/mail/imap/protocol/ListInfo:name	Ljava/lang/String;
    //   81: new 251	java/lang/StringBuilder
    //   84: dup
    //   85: aload_0
    //   86: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   89: invokestatic 255	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   92: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   95: iload 4
    //   97: invokevirtual 386	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   100: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   103: invokevirtual 389	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   106: ifeq +6 -> 112
    //   109: iconst_1
    //   110: istore 6
    //   112: aload 5
    //   114: arraylength
    //   115: iload 6
    //   117: isub
    //   118: anewarray 2	com/sun/mail/imap/IMAPFolder
    //   121: astore 7
    //   123: iload 6
    //   125: istore 8
    //   127: iload 8
    //   129: aload 5
    //   131: arraylength
    //   132: if_icmpge -113 -> 19
    //   135: aload 7
    //   137: iload 8
    //   139: iload 6
    //   141: isub
    //   142: new 2	com/sun/mail/imap/IMAPFolder
    //   145: dup
    //   146: aload 5
    //   148: iload 8
    //   150: aaload
    //   151: aload_0
    //   152: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   155: checkcast 186	com/sun/mail/imap/IMAPStore
    //   158: invokespecial 391	com/sun/mail/imap/IMAPFolder:<init>	(Lcom/sun/mail/imap/protocol/ListInfo;Lcom/sun/mail/imap/IMAPStore;)V
    //   161: aastore
    //   162: iinc 8 1
    //   165: goto -38 -> 127
    //   168: astore_3
    //   169: aload_0
    //   170: monitorexit
    //   171: aload_3
    //   172: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	173	0	this	IMAPFolder
    //   0	173	1	paramString	String
    //   0	173	2	paramBoolean	boolean
    //   168	4	3	localObject1	Object
    //   28	68	4	c	char
    //   49	98	5	arrayOfListInfo	ListInfo[]
    //   66	76	6	i	int
    //   17	119	7	localObject2	Object
    //   125	38	8	j	int
    // Exception table:
    //   from	to	target	type
    //   2	19	168	finally
    //   24	162	168	finally
  }
  
  private int findName(ListInfo[] paramArrayOfListInfo, String paramString)
  {
    for (int i = 0;; i++)
    {
      if (i >= paramArrayOfListInfo.length) {}
      while (paramArrayOfListInfo[i].name.equals(paramString))
      {
        if (i >= paramArrayOfListInfo.length) {
          i = 0;
        }
        return i;
      }
    }
  }
  
  private IMAPProtocol getProtocol()
    throws ProtocolException
  {
    assert (Thread.holdsLock(this.messageCacheLock));
    waitIfIdle();
    return this.protocol;
  }
  
  private Status getStatus()
    throws ProtocolException
  {
    int i = ((IMAPStore)this.store).getStatusCacheTimeout();
    Status localStatus;
    if ((i > 0) && (this.cachedStatus != null) && (System.currentTimeMillis() - this.cachedStatusTime < i)) {
      localStatus = this.cachedStatus;
    }
    for (;;)
    {
      return localStatus;
      IMAPProtocol localIMAPProtocol = null;
      try
      {
        localIMAPProtocol = getStoreProtocol();
        localStatus = localIMAPProtocol.status(this.fullName, null);
        if (i > 0)
        {
          this.cachedStatus = localStatus;
          this.cachedStatusTime = System.currentTimeMillis();
        }
        releaseStoreProtocol(localIMAPProtocol);
      }
      finally
      {
        releaseStoreProtocol(localIMAPProtocol);
      }
    }
  }
  
  private boolean isDirectory()
  {
    if ((0x2 & this.type) != 0) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  private void keepConnectionAlive(boolean paramBoolean)
    throws ProtocolException
  {
    if (System.currentTimeMillis() - this.protocol.getTimestamp() > 1000L)
    {
      waitIfIdle();
      this.protocol.noop();
    }
    IMAPProtocol localIMAPProtocol;
    if ((paramBoolean) && (((IMAPStore)this.store).hasSeparateStoreConnection())) {
      localIMAPProtocol = null;
    }
    try
    {
      localIMAPProtocol = ((IMAPStore)this.store).getStoreProtocol();
      if (System.currentTimeMillis() - localIMAPProtocol.getTimestamp() > 1000L) {
        localIMAPProtocol.noop();
      }
      return;
    }
    finally
    {
      ((IMAPStore)this.store).releaseStoreProtocol(localIMAPProtocol);
    }
  }
  
  private void releaseProtocol(boolean paramBoolean)
  {
    if (this.protocol != null)
    {
      this.protocol.removeResponseHandler(this);
      if (!paramBoolean) {
        break label35;
      }
      ((IMAPStore)this.store).releaseProtocol(this, this.protocol);
    }
    for (;;)
    {
      return;
      label35:
      ((IMAPStore)this.store).releaseProtocol(this, null);
    }
  }
  
  private void setACL(final ACL paramACL, final char paramChar)
    throws MessagingException
  {
    doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.setACL(IMAPFolder.this.fullName, paramChar, paramACL);
        return null;
      }
    });
  }
  
  private void throwClosedException(ConnectionException paramConnectionException)
    throws FolderClosedException, StoreClosedException
  {
    try
    {
      if (((this.protocol != null) && (paramConnectionException.getProtocol() == this.protocol)) || ((this.protocol == null) && (!this.reallyClosed))) {
        throw new FolderClosedException(this, paramConnectionException.getMessage());
      }
    }
    finally {}
    throw new StoreClosedException(this.store, paramConnectionException.getMessage());
  }
  
  public void addACL(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '\000');
  }
  
  /* Error */
  public Message[] addMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_1
    //   7: arraylength
    //   8: anewarray 464	javax/mail/internet/MimeMessage
    //   11: astore_3
    //   12: aload_0
    //   13: aload_1
    //   14: invokevirtual 468	com/sun/mail/imap/IMAPFolder:appendUIDMessages	([Ljavax/mail/Message;)[Lcom/sun/mail/imap/AppendUID;
    //   17: astore 4
    //   19: iconst_0
    //   20: istore 5
    //   22: aload 4
    //   24: arraylength
    //   25: istore 6
    //   27: iload 5
    //   29: iload 6
    //   31: if_icmplt +7 -> 38
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_3
    //   37: areturn
    //   38: aload 4
    //   40: iload 5
    //   42: aaload
    //   43: astore 7
    //   45: aload 7
    //   47: ifnull +37 -> 84
    //   50: aload 7
    //   52: getfield 471	com/sun/mail/imap/AppendUID:uidvalidity	J
    //   55: lstore 8
    //   57: aload_0
    //   58: getfield 158	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   61: lstore 10
    //   63: lload 8
    //   65: lload 10
    //   67: lcmp
    //   68: ifne +16 -> 84
    //   71: aload_3
    //   72: iload 5
    //   74: aload_0
    //   75: aload 7
    //   77: getfield 474	com/sun/mail/imap/AppendUID:uid	J
    //   80: invokevirtual 478	com/sun/mail/imap/IMAPFolder:getMessageByUID	(J)Ljavax/mail/Message;
    //   83: aastore
    //   84: iinc 5 1
    //   87: goto -65 -> 22
    //   90: astore_2
    //   91: aload_0
    //   92: monitorexit
    //   93: aload_2
    //   94: athrow
    //   95: astore 12
    //   97: goto -13 -> 84
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	100	0	this	IMAPFolder
    //   0	100	1	paramArrayOfMessage	Message[]
    //   90	4	2	localObject	Object
    //   11	61	3	arrayOfMimeMessage	javax.mail.internet.MimeMessage[]
    //   17	22	4	arrayOfAppendUID	AppendUID[]
    //   20	65	5	i	int
    //   25	7	6	j	int
    //   43	33	7	localAppendUID	AppendUID
    //   55	9	8	l1	long
    //   61	5	10	l2	long
    //   95	1	12	localMessagingException	MessagingException
    // Exception table:
    //   from	to	target	type
    //   2	27	90	finally
    //   38	63	90	finally
    //   71	84	90	finally
    //   71	84	95	javax/mail/MessagingException
  }
  
  public void addRights(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '+');
  }
  
  /* Error */
  public void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   10: checkcast 186	com/sun/mail/imap/IMAPStore
    //   13: invokevirtual 488	com/sun/mail/imap/IMAPStore:getAppendBufferSize	()I
    //   16: istore_3
    //   17: iconst_0
    //   18: istore 4
    //   20: aload_1
    //   21: arraylength
    //   22: istore 5
    //   24: iload 4
    //   26: iload 5
    //   28: if_icmplt +6 -> 34
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: aload_1
    //   35: iload 4
    //   37: aaload
    //   38: astore 6
    //   40: aload 6
    //   42: invokevirtual 493	javax/mail/Message:getSize	()I
    //   45: iload_3
    //   46: if_icmple +95 -> 141
    //   49: iconst_0
    //   50: istore 9
    //   52: new 495	com/sun/mail/imap/MessageLiteral
    //   55: dup
    //   56: aload 6
    //   58: iload 9
    //   60: invokespecial 498	com/sun/mail/imap/MessageLiteral:<init>	(Ljavax/mail/Message;I)V
    //   63: astore 10
    //   65: aload 6
    //   67: invokevirtual 502	javax/mail/Message:getReceivedDate	()Ljava/util/Date;
    //   70: astore 11
    //   72: aload 11
    //   74: ifnonnull +10 -> 84
    //   77: aload 6
    //   79: invokevirtual 505	javax/mail/Message:getSentDate	()Ljava/util/Date;
    //   82: astore 11
    //   84: aload 11
    //   86: astore 12
    //   88: aload_0
    //   89: new 10	com/sun/mail/imap/IMAPFolder$10
    //   92: dup
    //   93: aload_0
    //   94: aload 6
    //   96: invokevirtual 509	javax/mail/Message:getFlags	()Ljavax/mail/Flags;
    //   99: aload 12
    //   101: aload 10
    //   103: invokespecial 512	com/sun/mail/imap/IMAPFolder$10:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljavax/mail/Flags;Ljava/util/Date;Lcom/sun/mail/imap/MessageLiteral;)V
    //   106: invokevirtual 515	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   109: pop
    //   110: goto +25 -> 135
    //   113: astore 8
    //   115: new 245	javax/mail/MessagingException
    //   118: dup
    //   119: ldc_w 517
    //   122: aload 8
    //   124: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   127: athrow
    //   128: astore_2
    //   129: aload_0
    //   130: monitorexit
    //   131: aload_2
    //   132: athrow
    //   133: astore 7
    //   135: iinc 4 1
    //   138: goto -118 -> 20
    //   141: iload_3
    //   142: istore 9
    //   144: goto -92 -> 52
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	147	0	this	IMAPFolder
    //   0	147	1	paramArrayOfMessage	Message[]
    //   128	4	2	localObject	Object
    //   16	126	3	i	int
    //   18	118	4	j	int
    //   22	7	5	k	int
    //   38	57	6	localMessage	Message
    //   133	1	7	localMessageRemovedException	javax.mail.MessageRemovedException
    //   113	10	8	localIOException	java.io.IOException
    //   50	93	9	m	int
    //   63	39	10	localMessageLiteral	MessageLiteral
    //   70	15	11	localDate1	Date
    //   86	14	12	localDate2	Date
    // Exception table:
    //   from	to	target	type
    //   40	65	113	java/io/IOException
    //   2	24	128	finally
    //   34	40	128	finally
    //   40	65	128	finally
    //   65	128	128	finally
    //   40	65	133	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public AppendUID[] appendUIDMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   10: checkcast 186	com/sun/mail/imap/IMAPStore
    //   13: invokevirtual 488	com/sun/mail/imap/IMAPStore:getAppendBufferSize	()I
    //   16: istore_3
    //   17: aload_1
    //   18: arraylength
    //   19: anewarray 470	com/sun/mail/imap/AppendUID
    //   22: astore 4
    //   24: iconst_0
    //   25: istore 5
    //   27: aload_1
    //   28: arraylength
    //   29: istore 6
    //   31: iload 5
    //   33: iload 6
    //   35: if_icmplt +8 -> 43
    //   38: aload_0
    //   39: monitorexit
    //   40: aload 4
    //   42: areturn
    //   43: aload_1
    //   44: iload 5
    //   46: aaload
    //   47: astore 7
    //   49: aload 7
    //   51: invokevirtual 493	javax/mail/Message:getSize	()I
    //   54: iload_3
    //   55: if_icmple +102 -> 157
    //   58: iconst_0
    //   59: istore 10
    //   61: new 495	com/sun/mail/imap/MessageLiteral
    //   64: dup
    //   65: aload 7
    //   67: iload 10
    //   69: invokespecial 498	com/sun/mail/imap/MessageLiteral:<init>	(Ljavax/mail/Message;I)V
    //   72: astore 11
    //   74: aload 7
    //   76: invokevirtual 502	javax/mail/Message:getReceivedDate	()Ljava/util/Date;
    //   79: astore 12
    //   81: aload 12
    //   83: ifnonnull +10 -> 93
    //   86: aload 7
    //   88: invokevirtual 505	javax/mail/Message:getSentDate	()Ljava/util/Date;
    //   91: astore 12
    //   93: aload 12
    //   95: astore 13
    //   97: aload 4
    //   99: iload 5
    //   101: aload_0
    //   102: new 12	com/sun/mail/imap/IMAPFolder$11
    //   105: dup
    //   106: aload_0
    //   107: aload 7
    //   109: invokevirtual 509	javax/mail/Message:getFlags	()Ljavax/mail/Flags;
    //   112: aload 13
    //   114: aload 11
    //   116: invokespecial 518	com/sun/mail/imap/IMAPFolder$11:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljavax/mail/Flags;Ljava/util/Date;Lcom/sun/mail/imap/MessageLiteral;)V
    //   119: invokevirtual 515	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   122: checkcast 470	com/sun/mail/imap/AppendUID
    //   125: aastore
    //   126: goto +25 -> 151
    //   129: astore 9
    //   131: new 245	javax/mail/MessagingException
    //   134: dup
    //   135: ldc_w 517
    //   138: aload 9
    //   140: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   143: athrow
    //   144: astore_2
    //   145: aload_0
    //   146: monitorexit
    //   147: aload_2
    //   148: athrow
    //   149: astore 8
    //   151: iinc 5 1
    //   154: goto -127 -> 27
    //   157: iload_3
    //   158: istore 10
    //   160: goto -99 -> 61
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	163	0	this	IMAPFolder
    //   0	163	1	paramArrayOfMessage	Message[]
    //   144	4	2	localObject	Object
    //   16	142	3	i	int
    //   22	76	4	arrayOfAppendUID	AppendUID[]
    //   25	127	5	j	int
    //   29	7	6	k	int
    //   47	61	7	localMessage	Message
    //   149	1	8	localMessageRemovedException	javax.mail.MessageRemovedException
    //   129	10	9	localIOException	java.io.IOException
    //   59	100	10	m	int
    //   72	43	11	localMessageLiteral	MessageLiteral
    //   79	15	12	localDate1	Date
    //   95	18	13	localDate2	Date
    // Exception table:
    //   from	to	target	type
    //   49	74	129	java/io/IOException
    //   2	31	144	finally
    //   43	49	144	finally
    //   49	74	144	finally
    //   74	144	144	finally
    //   49	74	149	javax/mail/MessageRemovedException
  }
  
  public void close(boolean paramBoolean)
    throws MessagingException
  {
    try
    {
      close(paramBoolean, false);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_1
    //   7: arraylength
    //   8: istore 4
    //   10: iload 4
    //   12: ifne +6 -> 18
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: aload_2
    //   19: invokevirtual 528	javax/mail/Folder:getStore	()Ljavax/mail/Store;
    //   22: aload_0
    //   23: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   26: if_acmpne +169 -> 195
    //   29: aload_0
    //   30: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   33: astore 5
    //   35: aload 5
    //   37: monitorenter
    //   38: aload_0
    //   39: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   42: astore 10
    //   44: aload_1
    //   45: aconst_null
    //   46: invokestatic 536	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   49: astore 11
    //   51: aload 11
    //   53: ifnonnull +77 -> 130
    //   56: new 485	javax/mail/MessageRemovedException
    //   59: dup
    //   60: ldc_w 538
    //   63: invokespecial 539	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   66: athrow
    //   67: astore 9
    //   69: aload 9
    //   71: invokevirtual 540	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   74: ldc_w 542
    //   77: invokevirtual 545	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   80: bipush 255
    //   82: if_icmpeq +65 -> 147
    //   85: new 249	javax/mail/FolderNotFoundException
    //   88: dup
    //   89: aload_2
    //   90: new 251	java/lang/StringBuilder
    //   93: dup
    //   94: aload_2
    //   95: invokevirtual 548	javax/mail/Folder:getFullName	()Ljava/lang/String;
    //   98: invokestatic 255	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   101: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   104: ldc_w 550
    //   107: invokevirtual 262	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   113: invokespecial 269	javax/mail/FolderNotFoundException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   116: athrow
    //   117: astore 7
    //   119: aload 5
    //   121: monitorexit
    //   122: aload 7
    //   124: athrow
    //   125: astore_3
    //   126: aload_0
    //   127: monitorexit
    //   128: aload_3
    //   129: athrow
    //   130: aload 10
    //   132: aload 11
    //   134: aload_2
    //   135: invokevirtual 548	javax/mail/Folder:getFullName	()Ljava/lang/String;
    //   138: invokevirtual 554	com/sun/mail/imap/protocol/IMAPProtocol:copy	([Lcom/sun/mail/imap/protocol/MessageSet;Ljava/lang/String;)V
    //   141: aload 5
    //   143: monitorexit
    //   144: goto -129 -> 15
    //   147: new 245	javax/mail/MessagingException
    //   150: dup
    //   151: aload 9
    //   153: invokevirtual 540	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   156: aload 9
    //   158: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   161: athrow
    //   162: astore 8
    //   164: new 288	javax/mail/FolderClosedException
    //   167: dup
    //   168: aload_0
    //   169: aload 8
    //   171: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   174: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   177: athrow
    //   178: astore 6
    //   180: new 245	javax/mail/MessagingException
    //   183: dup
    //   184: aload 6
    //   186: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   189: aload 6
    //   191: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   194: athrow
    //   195: aload_0
    //   196: aload_1
    //   197: aload_2
    //   198: invokespecial 556	javax/mail/Folder:copyMessages	([Ljavax/mail/Message;Ljavax/mail/Folder;)V
    //   201: goto -186 -> 15
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	204	0	this	IMAPFolder
    //   0	204	1	paramArrayOfMessage	Message[]
    //   0	204	2	paramFolder	Folder
    //   125	4	3	localObject1	Object
    //   8	3	4	i	int
    //   178	12	6	localProtocolException	ProtocolException
    //   117	6	7	localObject3	Object
    //   162	8	8	localConnectionException	ConnectionException
    //   67	90	9	localCommandFailedException	CommandFailedException
    //   42	89	10	localIMAPProtocol	IMAPProtocol
    //   49	84	11	arrayOfMessageSet	com.sun.mail.imap.protocol.MessageSet[]
    // Exception table:
    //   from	to	target	type
    //   38	67	67	com/sun/mail/iap/CommandFailedException
    //   130	141	67	com/sun/mail/iap/CommandFailedException
    //   38	67	117	finally
    //   69	122	117	finally
    //   130	141	117	finally
    //   141	195	117	finally
    //   2	10	125	finally
    //   18	38	125	finally
    //   122	125	125	finally
    //   195	201	125	finally
    //   38	67	162	com/sun/mail/iap/ConnectionException
    //   130	141	162	com/sun/mail/iap/ConnectionException
    //   38	67	178	com/sun/mail/iap/ProtocolException
    //   130	141	178	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public boolean create(final int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: iload_1
    //   5: iconst_1
    //   6: iand
    //   7: ifne +8 -> 15
    //   10: aload_0
    //   11: invokevirtual 374	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   14: istore_2
    //   15: aload_0
    //   16: new 40	com/sun/mail/imap/IMAPFolder$6
    //   19: dup
    //   20: aload_0
    //   21: iload_1
    //   22: iload_2
    //   23: invokespecial 561	com/sun/mail/imap/IMAPFolder$6:<init>	(Lcom/sun/mail/imap/IMAPFolder;IC)V
    //   26: invokevirtual 381	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   29: astore 4
    //   31: aload 4
    //   33: ifnonnull +11 -> 44
    //   36: iconst_0
    //   37: istore 5
    //   39: aload_0
    //   40: monitorexit
    //   41: iload 5
    //   43: ireturn
    //   44: aload_0
    //   45: invokevirtual 247	com/sun/mail/imap/IMAPFolder:exists	()Z
    //   48: istore 5
    //   50: iload 5
    //   52: ifeq -13 -> 39
    //   55: aload_0
    //   56: iconst_1
    //   57: invokevirtual 564	com/sun/mail/imap/IMAPFolder:notifyFolderListeners	(I)V
    //   60: goto -21 -> 39
    //   63: astore_3
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	68	0	this	IMAPFolder
    //   0	68	1	paramInt	int
    //   3	20	2	c	char
    //   63	4	3	localObject1	Object
    //   29	3	4	localObject2	Object
    //   37	14	5	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   10	31	63	finally
    //   44	60	63	finally
  }
  
  /* Error */
  public boolean delete(boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial 568	com/sun/mail/imap/IMAPFolder:checkClosed	()V
    //   8: iload_1
    //   9: ifeq +20 -> 29
    //   12: aload_0
    //   13: invokevirtual 572	com/sun/mail/imap/IMAPFolder:list	()[Ljavax/mail/Folder;
    //   16: astore 5
    //   18: iconst_0
    //   19: istore 6
    //   21: iload 6
    //   23: aload 5
    //   25: arraylength
    //   26: if_icmplt +26 -> 52
    //   29: aload_0
    //   30: new 44	com/sun/mail/imap/IMAPFolder$8
    //   33: dup
    //   34: aload_0
    //   35: invokespecial 575	com/sun/mail/imap/IMAPFolder$8:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   38: invokevirtual 381	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   41: astore 4
    //   43: aload 4
    //   45: ifnonnull +23 -> 68
    //   48: aload_0
    //   49: monitorexit
    //   50: iload_2
    //   51: ireturn
    //   52: aload 5
    //   54: iload 6
    //   56: aaload
    //   57: iload_1
    //   58: invokevirtual 577	javax/mail/Folder:delete	(Z)Z
    //   61: pop
    //   62: iinc 6 1
    //   65: goto -44 -> 21
    //   68: aload_0
    //   69: iconst_0
    //   70: putfield 132	com/sun/mail/imap/IMAPFolder:exists	Z
    //   73: aload_0
    //   74: aconst_null
    //   75: putfield 137	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   78: aload_0
    //   79: iconst_2
    //   80: invokevirtual 564	com/sun/mail/imap/IMAPFolder:notifyFolderListeners	(I)V
    //   83: iconst_1
    //   84: istore_2
    //   85: goto -37 -> 48
    //   88: astore_3
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_3
    //   92: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	93	0	this	IMAPFolder
    //   0	93	1	paramBoolean	boolean
    //   1	84	2	bool	boolean
    //   88	4	3	localObject1	Object
    //   41	3	4	localObject2	Object
    //   16	37	5	arrayOfFolder	Folder[]
    //   19	44	6	i	int
    // Exception table:
    //   from	to	target	type
    //   4	43	88	finally
    //   52	83	88	finally
  }
  
  public Object doCommand(ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    try
    {
      Object localObject2 = doProtocolCommand(paramProtocolCommand);
      localObject1 = localObject2;
    }
    catch (ConnectionException localConnectionException)
    {
      for (;;)
      {
        throwClosedException(localConnectionException);
        Object localObject1 = null;
      }
    }
    catch (ProtocolException localProtocolException)
    {
      throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
    }
    return localObject1;
  }
  
  public Object doCommandIgnoreFailure(ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    Object localObject1 = null;
    try
    {
      Object localObject2 = doProtocolCommand(paramProtocolCommand);
      localObject1 = localObject2;
    }
    catch (CommandFailedException localCommandFailedException)
    {
      break label12;
    }
    catch (ConnectionException localConnectionException)
    {
      for (;;)
      {
        throwClosedException(localConnectionException);
      }
    }
    catch (ProtocolException localProtocolException)
    {
      label12:
      throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
    }
    return localObject1;
  }
  
  public Object doOptionalCommand(String paramString, ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    try
    {
      Object localObject2 = doProtocolCommand(paramProtocolCommand);
      localObject1 = localObject2;
    }
    catch (BadCommandException localBadCommandException)
    {
      throw new MessagingException(paramString, localBadCommandException);
    }
    catch (ConnectionException localConnectionException)
    {
      for (;;)
      {
        throwClosedException(localConnectionException);
        Object localObject1 = null;
      }
    }
    catch (ProtocolException localProtocolException)
    {
      throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
    }
    return localObject1;
  }
  
  protected Object doProtocolCommand(ProtocolCommand paramProtocolCommand)
    throws ProtocolException
  {
    for (;;)
    {
      Object localObject4;
      try
      {
        if ((this.opened) && (!((IMAPStore)this.store).hasSeparateStoreConnection())) {
          synchronized (this.messageCacheLock)
          {
            localObject4 = paramProtocolCommand.doCommand(getProtocol());
            return localObject4;
          }
        }
      }
      finally {}
      IMAPProtocol localIMAPProtocol = null;
      try
      {
        localIMAPProtocol = getStoreProtocol();
        Object localObject3 = paramProtocolCommand.doCommand(localIMAPProtocol);
        localObject4 = localObject3;
        releaseStoreProtocol(localIMAPProtocol);
      }
      finally
      {
        releaseStoreProtocol(localIMAPProtocol);
      }
    }
  }
  
  /* Error */
  public boolean exists()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   6: pop
    //   7: aload_0
    //   8: getfield 142	com/sun/mail/imap/IMAPFolder:isNamespace	Z
    //   11: ifeq +221 -> 232
    //   14: aload_0
    //   15: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   18: ifeq +214 -> 232
    //   21: new 251	java/lang/StringBuilder
    //   24: dup
    //   25: aload_0
    //   26: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   29: invokestatic 255	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   32: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   35: aload_0
    //   36: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   39: invokevirtual 386	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   42: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   45: astore_3
    //   46: aload_0
    //   47: new 30	com/sun/mail/imap/IMAPFolder$1
    //   50: dup
    //   51: aload_0
    //   52: aload_3
    //   53: invokespecial 590	com/sun/mail/imap/IMAPFolder$1:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljava/lang/String;)V
    //   56: invokevirtual 515	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   59: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   62: astore 4
    //   64: aload 4
    //   66: ifnull +174 -> 240
    //   69: aload_0
    //   70: aload 4
    //   72: aload_3
    //   73: invokespecial 592	com/sun/mail/imap/IMAPFolder:findName	([Lcom/sun/mail/imap/protocol/ListInfo;Ljava/lang/String;)I
    //   76: istore 6
    //   78: aload_0
    //   79: aload 4
    //   81: iload 6
    //   83: aaload
    //   84: getfield 117	com/sun/mail/imap/protocol/ListInfo:name	Ljava/lang/String;
    //   87: putfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   90: aload_0
    //   91: aload 4
    //   93: iload 6
    //   95: aaload
    //   96: getfield 119	com/sun/mail/imap/protocol/ListInfo:separator	C
    //   99: putfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   102: aload_0
    //   103: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   106: invokevirtual 219	java/lang/String:length	()I
    //   109: istore 7
    //   111: aload_0
    //   112: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   115: ifeq +42 -> 157
    //   118: iload 7
    //   120: ifle +37 -> 157
    //   123: aload_0
    //   124: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   127: iload 7
    //   129: iconst_1
    //   130: isub
    //   131: invokevirtual 596	java/lang/String:charAt	(I)C
    //   134: aload_0
    //   135: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   138: if_icmpne +19 -> 157
    //   141: aload_0
    //   142: aload_0
    //   143: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   146: iconst_0
    //   147: iload 7
    //   149: iconst_1
    //   150: isub
    //   151: invokevirtual 223	java/lang/String:substring	(II)Ljava/lang/String;
    //   154: putfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   157: aload_0
    //   158: iconst_0
    //   159: putfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   162: aload 4
    //   164: iload 6
    //   166: aaload
    //   167: getfield 125	com/sun/mail/imap/protocol/ListInfo:hasInferiors	Z
    //   170: ifeq +13 -> 183
    //   173: aload_0
    //   174: iconst_2
    //   175: aload_0
    //   176: getfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   179: ior
    //   180: putfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   183: aload 4
    //   185: iload 6
    //   187: aaload
    //   188: getfield 130	com/sun/mail/imap/protocol/ListInfo:canOpen	Z
    //   191: ifeq +13 -> 204
    //   194: aload_0
    //   195: iconst_1
    //   196: aload_0
    //   197: getfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   200: ior
    //   201: putfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   204: aload_0
    //   205: iconst_1
    //   206: putfield 132	com/sun/mail/imap/IMAPFolder:exists	Z
    //   209: aload_0
    //   210: aload 4
    //   212: iload 6
    //   214: aaload
    //   215: getfield 135	com/sun/mail/imap/protocol/ListInfo:attrs	[Ljava/lang/String;
    //   218: putfield 137	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   221: aload_0
    //   222: getfield 132	com/sun/mail/imap/IMAPFolder:exists	Z
    //   225: istore 5
    //   227: aload_0
    //   228: monitorexit
    //   229: iload 5
    //   231: ireturn
    //   232: aload_0
    //   233: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   236: astore_3
    //   237: goto -191 -> 46
    //   240: aload_0
    //   241: aload_0
    //   242: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   245: putfield 132	com/sun/mail/imap/IMAPFolder:exists	Z
    //   248: aload_0
    //   249: aconst_null
    //   250: putfield 137	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   253: goto -32 -> 221
    //   256: astore_1
    //   257: aload_0
    //   258: monitorexit
    //   259: aload_1
    //   260: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	261	0	this	IMAPFolder
    //   256	4	1	localObject	Object
    //   45	192	3	str	String
    //   62	149	4	arrayOfListInfo	ListInfo[]
    //   225	5	5	bool	boolean
    //   76	137	6	i	int
    //   109	42	7	j	int
    // Exception table:
    //   from	to	target	type
    //   2	227	256	finally
    //   232	253	256	finally
  }
  
  public Message[] expunge()
    throws MessagingException
  {
    try
    {
      Message[] arrayOfMessage = expunge(null);
      return arrayOfMessage;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public Message[] expunge(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: new 602	java/util/Vector
    //   9: dup
    //   10: invokespecial 603	java/util/Vector:<init>	()V
    //   13: astore_3
    //   14: aload_1
    //   15: ifnull +27 -> 42
    //   18: new 605	javax/mail/FetchProfile
    //   21: dup
    //   22: invokespecial 606	javax/mail/FetchProfile:<init>	()V
    //   25: astore 4
    //   27: aload 4
    //   29: getstatic 612	javax/mail/UIDFolder$FetchProfileItem:UID	Ljavax/mail/UIDFolder$FetchProfileItem;
    //   32: invokevirtual 616	javax/mail/FetchProfile:add	(Ljavax/mail/FetchProfile$Item;)V
    //   35: aload_0
    //   36: aload_1
    //   37: aload 4
    //   39: invokevirtual 620	com/sun/mail/imap/IMAPFolder:fetch	([Ljavax/mail/Message;Ljavax/mail/FetchProfile;)V
    //   42: aload_0
    //   43: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   46: astore 5
    //   48: aload 5
    //   50: monitorenter
    //   51: aload_0
    //   52: iconst_0
    //   53: putfield 162	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   56: aload_0
    //   57: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   60: astore 11
    //   62: aload_1
    //   63: ifnull +79 -> 142
    //   66: aload 11
    //   68: aload_1
    //   69: invokestatic 624	com/sun/mail/imap/Utility:toUIDSet	([Ljavax/mail/Message;)[Lcom/sun/mail/imap/protocol/UIDSet;
    //   72: invokevirtual 628	com/sun/mail/imap/protocol/IMAPProtocol:uidexpunge	([Lcom/sun/mail/imap/protocol/UIDSet;)V
    //   75: aload_0
    //   76: iconst_1
    //   77: putfield 162	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   80: iconst_0
    //   81: istore 12
    //   83: iload 12
    //   85: aload_0
    //   86: getfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   89: invokevirtual 631	java/util/Vector:size	()I
    //   92: if_icmplt +167 -> 259
    //   95: aload 5
    //   97: monitorexit
    //   98: aload_0
    //   99: aload_0
    //   100: getfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   103: invokevirtual 631	java/util/Vector:size	()I
    //   106: putfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   109: aload_3
    //   110: invokevirtual 631	java/util/Vector:size	()I
    //   113: anewarray 490	javax/mail/Message
    //   116: astore 17
    //   118: aload_3
    //   119: aload 17
    //   121: invokevirtual 635	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   124: aload 17
    //   126: arraylength
    //   127: ifle +10 -> 137
    //   130: aload_0
    //   131: iconst_1
    //   132: aload 17
    //   134: invokevirtual 639	com/sun/mail/imap/IMAPFolder:notifyMessageRemovedListeners	(Z[Ljavax/mail/Message;)V
    //   137: aload_0
    //   138: monitorexit
    //   139: aload 17
    //   141: areturn
    //   142: aload 11
    //   144: invokevirtual 641	com/sun/mail/imap/protocol/IMAPProtocol:expunge	()V
    //   147: goto -72 -> 75
    //   150: astore 10
    //   152: aload_0
    //   153: getfield 283	com/sun/mail/imap/IMAPFolder:mode	I
    //   156: iconst_2
    //   157: if_icmpeq +54 -> 211
    //   160: new 239	java/lang/IllegalStateException
    //   163: dup
    //   164: new 251	java/lang/StringBuilder
    //   167: dup
    //   168: ldc_w 643
    //   171: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   174: aload_0
    //   175: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   178: invokevirtual 262	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   184: invokespecial 242	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   187: athrow
    //   188: astore 8
    //   190: aload_0
    //   191: iconst_1
    //   192: putfield 162	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   195: aload 8
    //   197: athrow
    //   198: astore 6
    //   200: aload 5
    //   202: monitorexit
    //   203: aload 6
    //   205: athrow
    //   206: astore_2
    //   207: aload_0
    //   208: monitorexit
    //   209: aload_2
    //   210: athrow
    //   211: new 245	javax/mail/MessagingException
    //   214: dup
    //   215: aload 10
    //   217: invokevirtual 540	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   220: aload 10
    //   222: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   225: athrow
    //   226: astore 9
    //   228: new 288	javax/mail/FolderClosedException
    //   231: dup
    //   232: aload_0
    //   233: aload 9
    //   235: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   238: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   241: athrow
    //   242: astore 7
    //   244: new 245	javax/mail/MessagingException
    //   247: dup
    //   248: aload 7
    //   250: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   253: aload 7
    //   255: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   258: athrow
    //   259: aload_0
    //   260: getfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   263: iload 12
    //   265: invokevirtual 647	java/util/Vector:elementAt	(I)Ljava/lang/Object;
    //   268: checkcast 649	com/sun/mail/imap/IMAPMessage
    //   271: astore 13
    //   273: aload 13
    //   275: invokevirtual 652	com/sun/mail/imap/IMAPMessage:isExpunged	()Z
    //   278: ifeq +61 -> 339
    //   281: aload_3
    //   282: aload 13
    //   284: invokevirtual 656	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   287: aload_0
    //   288: getfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   291: iload 12
    //   293: invokevirtual 659	java/util/Vector:removeElementAt	(I)V
    //   296: aload_0
    //   297: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   300: ifnull -217 -> 83
    //   303: aload 13
    //   305: invokevirtual 662	com/sun/mail/imap/IMAPMessage:getUID	()J
    //   308: lstore 14
    //   310: lload 14
    //   312: ldc2_w 155
    //   315: lcmp
    //   316: ifeq -233 -> 83
    //   319: aload_0
    //   320: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   323: new 664	java/lang/Long
    //   326: dup
    //   327: lload 14
    //   329: invokespecial 667	java/lang/Long:<init>	(J)V
    //   332: invokevirtual 673	java/util/Hashtable:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   335: pop
    //   336: goto -253 -> 83
    //   339: aload 13
    //   341: aload 13
    //   343: invokevirtual 676	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   346: invokevirtual 679	com/sun/mail/imap/IMAPMessage:setMessageNumber	(I)V
    //   349: iinc 12 1
    //   352: goto -269 -> 83
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	355	0	this	IMAPFolder
    //   0	355	1	paramArrayOfMessage	Message[]
    //   206	4	2	localObject1	Object
    //   13	269	3	localVector	Vector
    //   25	13	4	localFetchProfile	FetchProfile
    //   46	155	5	localObject2	Object
    //   198	6	6	localObject3	Object
    //   242	12	7	localProtocolException	ProtocolException
    //   188	8	8	localObject4	Object
    //   226	8	9	localConnectionException	ConnectionException
    //   150	71	10	localCommandFailedException	CommandFailedException
    //   60	83	11	localIMAPProtocol	IMAPProtocol
    //   81	269	12	i	int
    //   271	71	13	localIMAPMessage	IMAPMessage
    //   308	20	14	l	long
    //   116	24	17	arrayOfMessage	Message[]
    // Exception table:
    //   from	to	target	type
    //   56	75	150	com/sun/mail/iap/CommandFailedException
    //   142	147	150	com/sun/mail/iap/CommandFailedException
    //   56	75	188	finally
    //   142	147	188	finally
    //   152	188	188	finally
    //   211	259	188	finally
    //   51	56	198	finally
    //   75	98	198	finally
    //   190	203	198	finally
    //   259	349	198	finally
    //   2	51	206	finally
    //   98	137	206	finally
    //   203	206	206	finally
    //   56	75	226	com/sun/mail/iap/ConnectionException
    //   142	147	226	com/sun/mail/iap/ConnectionException
    //   56	75	242	com/sun/mail/iap/ProtocolException
    //   142	147	242	com/sun/mail/iap/ProtocolException
  }
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile)
    throws MessagingException
  {
    try
    {
      checkOpened();
      IMAPMessage.fetch(this, paramArrayOfMessage, paramFetchProfile);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void forceClose()
    throws MessagingException
  {
    try
    {
      close(false, true);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public ACL[] getACL()
    throws MessagingException
  {
    (ACL[])doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.getACL(IMAPFolder.this.fullName);
      }
    });
  }
  
  public String[] getAttributes()
    throws MessagingException
  {
    if (this.attributes == null) {
      exists();
    }
    return (String[])this.attributes.clone();
  }
  
  /* Error */
  public int getDeletedMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +16 -> 22
    //   9: aload_0
    //   10: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: bipush 255
    //   15: istore 7
    //   17: aload_0
    //   18: monitorexit
    //   19: iload 7
    //   21: ireturn
    //   22: new 698	javax/mail/Flags
    //   25: dup
    //   26: invokespecial 699	javax/mail/Flags:<init>	()V
    //   29: astore_2
    //   30: aload_2
    //   31: getstatic 705	javax/mail/Flags$Flag:DELETED	Ljavax/mail/Flags$Flag;
    //   34: invokevirtual 708	javax/mail/Flags:add	(Ljavax/mail/Flags$Flag;)V
    //   37: aload_0
    //   38: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   41: astore 5
    //   43: aload 5
    //   45: monitorenter
    //   46: aload_0
    //   47: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   50: new 710	javax/mail/search/FlagTerm
    //   53: dup
    //   54: aload_2
    //   55: iconst_1
    //   56: invokespecial 713	javax/mail/search/FlagTerm:<init>	(Ljavax/mail/Flags;Z)V
    //   59: invokevirtual 717	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   62: arraylength
    //   63: istore 7
    //   65: aload 5
    //   67: monitorexit
    //   68: goto -51 -> 17
    //   71: astore 6
    //   73: aload 5
    //   75: monitorexit
    //   76: aload 6
    //   78: athrow
    //   79: astore 4
    //   81: new 288	javax/mail/FolderClosedException
    //   84: dup
    //   85: aload_0
    //   86: aload 4
    //   88: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   91: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   94: athrow
    //   95: astore_1
    //   96: aload_0
    //   97: monitorexit
    //   98: aload_1
    //   99: athrow
    //   100: astore_3
    //   101: new 245	javax/mail/MessagingException
    //   104: dup
    //   105: aload_3
    //   106: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   109: aload_3
    //   110: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   113: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	114	0	this	IMAPFolder
    //   95	4	1	localObject1	Object
    //   29	26	2	localFlags	Flags
    //   100	10	3	localProtocolException	ProtocolException
    //   79	8	4	localConnectionException	ConnectionException
    //   71	6	6	localObject3	Object
    //   15	49	7	i	int
    // Exception table:
    //   from	to	target	type
    //   46	76	71	finally
    //   37	46	79	com/sun/mail/iap/ConnectionException
    //   76	79	79	com/sun/mail/iap/ConnectionException
    //   2	13	95	finally
    //   22	37	95	finally
    //   37	46	95	finally
    //   76	79	95	finally
    //   81	95	95	finally
    //   101	114	95	finally
    //   37	46	100	com/sun/mail/iap/ProtocolException
    //   76	79	100	com/sun/mail/iap/ProtocolException
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    if ((this.attributes != null) && (!isDirectory())) {
      throw new MessagingException("Cannot contain subfolders");
    }
    char c = getSeparator();
    return new IMAPFolder(this.fullName + c + paramString, c, (IMAPStore)this.store);
  }
  
  public String getFullName()
  {
    try
    {
      String str = this.fullName;
      return str;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public Message getMessage(int paramInt)
    throws MessagingException
  {
    try
    {
      checkOpened();
      checkRange(paramInt);
      Message localMessage = (Message)this.messageCache.elementAt(paramInt - 1);
      return localMessage;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  IMAPMessage getMessageBySeqNumber(int paramInt)
  {
    for (int i = paramInt - 1;; i++)
    {
      IMAPMessage localIMAPMessage;
      if (i >= this.total) {
        localIMAPMessage = null;
      }
      do
      {
        return localIMAPMessage;
        localIMAPMessage = (IMAPMessage)this.messageCache.elementAt(i);
      } while (localIMAPMessage.getSequenceNumber() == paramInt);
    }
  }
  
  /* Error */
  public Message getMessageByUID(long paramLong)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aconst_null
    //   7: astore 4
    //   9: aload_0
    //   10: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   13: astore 7
    //   15: aload 7
    //   17: monitorenter
    //   18: new 664	java/lang/Long
    //   21: dup
    //   22: lload_1
    //   23: invokespecial 667	java/lang/Long:<init>	(J)V
    //   26: astore 8
    //   28: aload_0
    //   29: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   32: ifnull +34 -> 66
    //   35: aload_0
    //   36: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   39: aload 8
    //   41: invokevirtual 730	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   44: checkcast 649	com/sun/mail/imap/IMAPMessage
    //   47: astore 4
    //   49: aload 4
    //   51: ifnull +26 -> 77
    //   54: aload 7
    //   56: monitorexit
    //   57: aload 4
    //   59: astore 11
    //   61: aload_0
    //   62: monitorexit
    //   63: aload 11
    //   65: areturn
    //   66: aload_0
    //   67: new 669	java/util/Hashtable
    //   70: dup
    //   71: invokespecial 731	java/util/Hashtable:<init>	()V
    //   74: putfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   77: aload_0
    //   78: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   81: lload_1
    //   82: invokevirtual 735	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumber	(J)Lcom/sun/mail/imap/protocol/UID;
    //   85: astore 10
    //   87: aload 10
    //   89: ifnull +48 -> 137
    //   92: aload 10
    //   94: getfield 740	com/sun/mail/imap/protocol/UID:seqnum	I
    //   97: aload_0
    //   98: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   101: if_icmpgt +36 -> 137
    //   104: aload_0
    //   105: aload 10
    //   107: getfield 740	com/sun/mail/imap/protocol/UID:seqnum	I
    //   110: invokevirtual 742	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   113: astore 4
    //   115: aload 4
    //   117: aload 10
    //   119: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   122: invokevirtual 746	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   125: aload_0
    //   126: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   129: aload 8
    //   131: aload 4
    //   133: invokevirtual 750	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   136: pop
    //   137: aload 7
    //   139: monitorexit
    //   140: aload 4
    //   142: astore 11
    //   144: goto -83 -> 61
    //   147: astore 9
    //   149: aload 7
    //   151: monitorexit
    //   152: aload 9
    //   154: athrow
    //   155: astore 6
    //   157: new 288	javax/mail/FolderClosedException
    //   160: dup
    //   161: aload_0
    //   162: aload 6
    //   164: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   167: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   170: athrow
    //   171: astore_3
    //   172: aload_0
    //   173: monitorexit
    //   174: aload_3
    //   175: athrow
    //   176: astore 5
    //   178: new 245	javax/mail/MessagingException
    //   181: dup
    //   182: aload 5
    //   184: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   187: aload 5
    //   189: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   192: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	193	0	this	IMAPFolder
    //   0	193	1	paramLong	long
    //   171	4	3	localObject1	Object
    //   7	134	4	localIMAPMessage1	IMAPMessage
    //   176	12	5	localProtocolException	ProtocolException
    //   155	8	6	localConnectionException	ConnectionException
    //   26	104	8	localLong	java.lang.Long
    //   147	6	9	localObject3	Object
    //   85	33	10	localUID	com.sun.mail.imap.protocol.UID
    //   59	84	11	localIMAPMessage2	IMAPMessage
    // Exception table:
    //   from	to	target	type
    //   18	57	147	finally
    //   66	152	147	finally
    //   9	18	155	com/sun/mail/iap/ConnectionException
    //   152	155	155	com/sun/mail/iap/ConnectionException
    //   2	6	171	finally
    //   9	18	171	finally
    //   152	155	171	finally
    //   157	171	171	finally
    //   178	193	171	finally
    //   9	18	176	com/sun/mail/iap/ProtocolException
    //   152	155	176	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public int getMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +133 -> 139
    //   9: aload_0
    //   10: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 232	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 754	com/sun/mail/imap/protocol/Status:total	I
    //   20: istore 6
    //   22: aload_0
    //   23: monitorexit
    //   24: iload 6
    //   26: ireturn
    //   27: astore 9
    //   29: aconst_null
    //   30: astore 10
    //   32: aload_0
    //   33: invokevirtual 405	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 10
    //   38: aload 10
    //   40: aload_0
    //   41: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   44: invokevirtual 363	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   47: astore 13
    //   49: aload 10
    //   51: invokevirtual 356	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   54: aload 13
    //   56: getfield 757	com/sun/mail/imap/protocol/MailboxInfo:total	I
    //   59: istore 6
    //   61: aload_0
    //   62: aload 10
    //   64: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   67: goto -45 -> 22
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    //   75: astore 12
    //   77: new 245	javax/mail/MessagingException
    //   80: dup
    //   81: aload 12
    //   83: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   86: aload 12
    //   88: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   91: athrow
    //   92: astore 11
    //   94: aload_0
    //   95: aload 10
    //   97: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   100: aload 11
    //   102: athrow
    //   103: astore 8
    //   105: new 448	javax/mail/StoreClosedException
    //   108: dup
    //   109: aload_0
    //   110: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   113: aload 8
    //   115: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   118: invokespecial 454	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   121: athrow
    //   122: astore 7
    //   124: new 245	javax/mail/MessagingException
    //   127: dup
    //   128: aload 7
    //   130: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   133: aload 7
    //   135: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   138: athrow
    //   139: aload_0
    //   140: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   143: astore_2
    //   144: aload_2
    //   145: monitorenter
    //   146: aload_0
    //   147: iconst_1
    //   148: invokespecial 304	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   151: aload_0
    //   152: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   155: istore 6
    //   157: aload_2
    //   158: monitorexit
    //   159: goto -137 -> 22
    //   162: astore 4
    //   164: aload_2
    //   165: monitorexit
    //   166: aload 4
    //   168: athrow
    //   169: astore 5
    //   171: new 288	javax/mail/FolderClosedException
    //   174: dup
    //   175: aload_0
    //   176: aload 5
    //   178: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   181: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   184: athrow
    //   185: astore_3
    //   186: new 245	javax/mail/MessagingException
    //   189: dup
    //   190: aload_3
    //   191: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   194: aload_3
    //   195: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   198: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	199	0	this	IMAPFolder
    //   70	4	1	localObject1	Object
    //   185	10	3	localProtocolException1	ProtocolException
    //   162	5	4	localObject3	Object
    //   169	8	5	localConnectionException1	ConnectionException
    //   20	136	6	i	int
    //   122	12	7	localProtocolException2	ProtocolException
    //   103	11	8	localConnectionException2	ConnectionException
    //   27	1	9	localBadCommandException	BadCommandException
    //   30	66	10	localIMAPProtocol	IMAPProtocol
    //   92	9	11	localObject4	Object
    //   75	12	12	localProtocolException3	ProtocolException
    //   47	8	13	localMailboxInfo	com.sun.mail.imap.protocol.MailboxInfo
    // Exception table:
    //   from	to	target	type
    //   13	22	27	com/sun/mail/iap/BadCommandException
    //   2	13	70	finally
    //   13	22	70	finally
    //   61	67	70	finally
    //   94	146	70	finally
    //   166	169	70	finally
    //   32	61	75	com/sun/mail/iap/ProtocolException
    //   32	61	92	finally
    //   77	92	92	finally
    //   13	22	103	com/sun/mail/iap/ConnectionException
    //   13	22	122	com/sun/mail/iap/ProtocolException
    //   146	157	162	finally
    //   157	166	162	finally
    //   171	199	162	finally
    //   146	157	169	com/sun/mail/iap/ConnectionException
    //   146	157	185	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] getMessagesByUID(long paramLong1, long paramLong2)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   10: astore 8
    //   12: aload 8
    //   14: monitorenter
    //   15: aload_0
    //   16: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   19: ifnonnull +14 -> 33
    //   22: aload_0
    //   23: new 669	java/util/Hashtable
    //   26: dup
    //   27: invokespecial 731	java/util/Hashtable:<init>	()V
    //   30: putfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   33: aload_0
    //   34: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   37: lload_1
    //   38: lload_3
    //   39: invokevirtual 763	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumbers	(JJ)[Lcom/sun/mail/imap/protocol/UID;
    //   42: astore 10
    //   44: aload 10
    //   46: arraylength
    //   47: anewarray 490	javax/mail/Message
    //   50: astore 11
    //   52: iconst_0
    //   53: istore 12
    //   55: iload 12
    //   57: aload 10
    //   59: arraylength
    //   60: if_icmplt +11 -> 71
    //   63: aload 8
    //   65: monitorexit
    //   66: aload_0
    //   67: monitorexit
    //   68: aload 11
    //   70: areturn
    //   71: aload_0
    //   72: aload 10
    //   74: iload 12
    //   76: aaload
    //   77: getfield 740	com/sun/mail/imap/protocol/UID:seqnum	I
    //   80: invokevirtual 742	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   83: astore 13
    //   85: aload 13
    //   87: aload 10
    //   89: iload 12
    //   91: aaload
    //   92: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   95: invokevirtual 746	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   98: aload 11
    //   100: iload 12
    //   102: aload 13
    //   104: aastore
    //   105: aload_0
    //   106: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   109: new 664	java/lang/Long
    //   112: dup
    //   113: aload 10
    //   115: iload 12
    //   117: aaload
    //   118: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   121: invokespecial 667	java/lang/Long:<init>	(J)V
    //   124: aload 13
    //   126: invokevirtual 750	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   129: pop
    //   130: iinc 12 1
    //   133: goto -78 -> 55
    //   136: astore 9
    //   138: aload 8
    //   140: monitorexit
    //   141: aload 9
    //   143: athrow
    //   144: astore 7
    //   146: new 288	javax/mail/FolderClosedException
    //   149: dup
    //   150: aload_0
    //   151: aload 7
    //   153: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   156: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   159: athrow
    //   160: astore 5
    //   162: aload_0
    //   163: monitorexit
    //   164: aload 5
    //   166: athrow
    //   167: astore 6
    //   169: new 245	javax/mail/MessagingException
    //   172: dup
    //   173: aload 6
    //   175: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   178: aload 6
    //   180: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   183: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	184	0	this	IMAPFolder
    //   0	184	1	paramLong1	long
    //   0	184	3	paramLong2	long
    //   160	5	5	localObject1	Object
    //   167	12	6	localProtocolException	ProtocolException
    //   144	8	7	localConnectionException	ConnectionException
    //   136	6	9	localObject3	Object
    //   42	72	10	arrayOfUID	com.sun.mail.imap.protocol.UID[]
    //   50	49	11	arrayOfMessage	Message[]
    //   53	78	12	i	int
    //   83	42	13	localIMAPMessage	IMAPMessage
    // Exception table:
    //   from	to	target	type
    //   15	66	136	finally
    //   71	141	136	finally
    //   6	15	144	com/sun/mail/iap/ConnectionException
    //   141	144	144	com/sun/mail/iap/ConnectionException
    //   2	6	160	finally
    //   6	15	160	finally
    //   141	144	160	finally
    //   146	160	160	finally
    //   169	184	160	finally
    //   6	15	167	com/sun/mail/iap/ProtocolException
    //   141	144	167	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] getMessagesByUID(long[] paramArrayOfLong)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   10: astore 5
    //   12: aload 5
    //   14: monitorenter
    //   15: aload_1
    //   16: astore 6
    //   18: aload_0
    //   19: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   22: ifnull +157 -> 179
    //   25: new 602	java/util/Vector
    //   28: dup
    //   29: invokespecial 603	java/util/Vector:<init>	()V
    //   32: astore 8
    //   34: iconst_0
    //   35: istore 9
    //   37: iload 9
    //   39: aload_1
    //   40: arraylength
    //   41: if_icmplt +75 -> 116
    //   44: aload 8
    //   46: invokevirtual 631	java/util/Vector:size	()I
    //   49: istore 12
    //   51: iload 12
    //   53: newarray long
    //   55: astore 6
    //   57: iconst_0
    //   58: istore 13
    //   60: goto +266 -> 326
    //   63: aload 6
    //   65: arraylength
    //   66: ifle +25 -> 91
    //   69: aload_0
    //   70: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   73: aload 6
    //   75: invokevirtual 767	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumbers	([J)[Lcom/sun/mail/imap/protocol/UID;
    //   78: astore 16
    //   80: iconst_0
    //   81: istore 17
    //   83: iload 17
    //   85: aload 16
    //   87: arraylength
    //   88: if_icmplt +134 -> 222
    //   91: aload_1
    //   92: arraylength
    //   93: anewarray 490	javax/mail/Message
    //   96: astore 14
    //   98: iconst_0
    //   99: istore 15
    //   101: iload 15
    //   103: aload_1
    //   104: arraylength
    //   105: if_icmplt +175 -> 280
    //   108: aload 5
    //   110: monitorexit
    //   111: aload_0
    //   112: monitorexit
    //   113: aload 14
    //   115: areturn
    //   116: aload_0
    //   117: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   120: astore 10
    //   122: new 664	java/lang/Long
    //   125: dup
    //   126: aload_1
    //   127: iload 9
    //   129: laload
    //   130: invokespecial 667	java/lang/Long:<init>	(J)V
    //   133: astore 11
    //   135: aload 10
    //   137: aload 11
    //   139: invokevirtual 770	java/util/Hashtable:containsKey	(Ljava/lang/Object;)Z
    //   142: ifne +194 -> 336
    //   145: aload 8
    //   147: aload 11
    //   149: invokevirtual 656	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   152: goto +184 -> 336
    //   155: aload 6
    //   157: iload 13
    //   159: aload 8
    //   161: iload 13
    //   163: invokevirtual 647	java/util/Vector:elementAt	(I)Ljava/lang/Object;
    //   166: checkcast 664	java/lang/Long
    //   169: invokevirtual 773	java/lang/Long:longValue	()J
    //   172: lastore
    //   173: iinc 13 1
    //   176: goto +150 -> 326
    //   179: aload_0
    //   180: new 669	java/util/Hashtable
    //   183: dup
    //   184: invokespecial 731	java/util/Hashtable:<init>	()V
    //   187: putfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   190: goto -127 -> 63
    //   193: astore 7
    //   195: aload 5
    //   197: monitorexit
    //   198: aload 7
    //   200: athrow
    //   201: astore 4
    //   203: new 288	javax/mail/FolderClosedException
    //   206: dup
    //   207: aload_0
    //   208: aload 4
    //   210: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   213: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   216: athrow
    //   217: astore_2
    //   218: aload_0
    //   219: monitorexit
    //   220: aload_2
    //   221: athrow
    //   222: aload_0
    //   223: aload 16
    //   225: iload 17
    //   227: aaload
    //   228: getfield 740	com/sun/mail/imap/protocol/UID:seqnum	I
    //   231: invokevirtual 742	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   234: astore 18
    //   236: aload 18
    //   238: aload 16
    //   240: iload 17
    //   242: aaload
    //   243: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   246: invokevirtual 746	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   249: aload_0
    //   250: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   253: new 664	java/lang/Long
    //   256: dup
    //   257: aload 16
    //   259: iload 17
    //   261: aaload
    //   262: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   265: invokespecial 667	java/lang/Long:<init>	(J)V
    //   268: aload 18
    //   270: invokevirtual 750	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   273: pop
    //   274: iinc 17 1
    //   277: goto -194 -> 83
    //   280: aload 14
    //   282: iload 15
    //   284: aload_0
    //   285: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   288: new 664	java/lang/Long
    //   291: dup
    //   292: aload_1
    //   293: iload 15
    //   295: laload
    //   296: invokespecial 667	java/lang/Long:<init>	(J)V
    //   299: invokevirtual 730	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   302: checkcast 490	javax/mail/Message
    //   305: aastore
    //   306: iinc 15 1
    //   309: goto -208 -> 101
    //   312: astore_3
    //   313: new 245	javax/mail/MessagingException
    //   316: dup
    //   317: aload_3
    //   318: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   321: aload_3
    //   322: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   325: athrow
    //   326: iload 13
    //   328: iload 12
    //   330: if_icmplt -175 -> 155
    //   333: goto -270 -> 63
    //   336: iinc 9 1
    //   339: goto -302 -> 37
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	342	0	this	IMAPFolder
    //   0	342	1	paramArrayOfLong	long[]
    //   217	4	2	localObject1	Object
    //   312	10	3	localProtocolException	ProtocolException
    //   201	8	4	localConnectionException	ConnectionException
    //   10	186	5	localObject2	Object
    //   16	140	6	arrayOfLong	long[]
    //   193	6	7	localObject3	Object
    //   32	128	8	localVector	Vector
    //   35	302	9	i	int
    //   120	16	10	localHashtable	Hashtable
    //   133	15	11	localLong	java.lang.Long
    //   49	282	12	j	int
    //   58	273	13	k	int
    //   96	185	14	arrayOfMessage	Message[]
    //   99	208	15	m	int
    //   78	180	16	arrayOfUID	com.sun.mail.imap.protocol.UID[]
    //   81	194	17	n	int
    //   234	35	18	localIMAPMessage	IMAPMessage
    // Exception table:
    //   from	to	target	type
    //   18	111	193	finally
    //   116	198	193	finally
    //   222	306	193	finally
    //   6	15	201	com/sun/mail/iap/ConnectionException
    //   198	201	201	com/sun/mail/iap/ConnectionException
    //   2	6	217	finally
    //   6	15	217	finally
    //   198	201	217	finally
    //   203	217	217	finally
    //   313	326	217	finally
    //   6	15	312	com/sun/mail/iap/ProtocolException
    //   198	201	312	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public String getName()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 775	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull +27 -> 35
    //   11: aload_0
    //   12: aload_0
    //   13: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   16: iconst_1
    //   17: aload_0
    //   18: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   21: aload_0
    //   22: invokevirtual 374	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   25: invokevirtual 778	java/lang/String:lastIndexOf	(I)I
    //   28: iadd
    //   29: invokevirtual 781	java/lang/String:substring	(I)Ljava/lang/String;
    //   32: putfield 775	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   35: aload_0
    //   36: getfield 775	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   39: astore_3
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_3
    //   43: areturn
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    //   49: astore 4
    //   51: goto -16 -> 35
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	54	0	this	IMAPFolder
    //   44	4	1	localObject	Object
    //   6	2	2	str1	String
    //   39	4	3	str2	String
    //   49	1	4	localMessagingException	MessagingException
    // Exception table:
    //   from	to	target	type
    //   2	7	44	finally
    //   11	35	44	finally
    //   35	40	44	finally
    //   11	35	49	javax/mail/MessagingException
  }
  
  /* Error */
  public int getNewMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +133 -> 139
    //   9: aload_0
    //   10: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 232	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 783	com/sun/mail/imap/protocol/Status:recent	I
    //   20: istore 6
    //   22: aload_0
    //   23: monitorexit
    //   24: iload 6
    //   26: ireturn
    //   27: astore 9
    //   29: aconst_null
    //   30: astore 10
    //   32: aload_0
    //   33: invokevirtual 405	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 10
    //   38: aload 10
    //   40: aload_0
    //   41: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   44: invokevirtual 363	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   47: astore 13
    //   49: aload 10
    //   51: invokevirtual 356	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   54: aload 13
    //   56: getfield 784	com/sun/mail/imap/protocol/MailboxInfo:recent	I
    //   59: istore 6
    //   61: aload_0
    //   62: aload 10
    //   64: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   67: goto -45 -> 22
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    //   75: astore 12
    //   77: new 245	javax/mail/MessagingException
    //   80: dup
    //   81: aload 12
    //   83: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   86: aload 12
    //   88: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   91: athrow
    //   92: astore 11
    //   94: aload_0
    //   95: aload 10
    //   97: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   100: aload 11
    //   102: athrow
    //   103: astore 8
    //   105: new 448	javax/mail/StoreClosedException
    //   108: dup
    //   109: aload_0
    //   110: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   113: aload 8
    //   115: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   118: invokespecial 454	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   121: athrow
    //   122: astore 7
    //   124: new 245	javax/mail/MessagingException
    //   127: dup
    //   128: aload 7
    //   130: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   133: aload 7
    //   135: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   138: athrow
    //   139: aload_0
    //   140: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   143: astore_2
    //   144: aload_2
    //   145: monitorenter
    //   146: aload_0
    //   147: iconst_1
    //   148: invokespecial 304	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   151: aload_0
    //   152: getfield 152	com/sun/mail/imap/IMAPFolder:recent	I
    //   155: istore 6
    //   157: aload_2
    //   158: monitorexit
    //   159: goto -137 -> 22
    //   162: astore 4
    //   164: aload_2
    //   165: monitorexit
    //   166: aload 4
    //   168: athrow
    //   169: astore 5
    //   171: new 288	javax/mail/FolderClosedException
    //   174: dup
    //   175: aload_0
    //   176: aload 5
    //   178: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   181: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   184: athrow
    //   185: astore_3
    //   186: new 245	javax/mail/MessagingException
    //   189: dup
    //   190: aload_3
    //   191: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   194: aload_3
    //   195: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   198: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	199	0	this	IMAPFolder
    //   70	4	1	localObject1	Object
    //   185	10	3	localProtocolException1	ProtocolException
    //   162	5	4	localObject3	Object
    //   169	8	5	localConnectionException1	ConnectionException
    //   20	136	6	i	int
    //   122	12	7	localProtocolException2	ProtocolException
    //   103	11	8	localConnectionException2	ConnectionException
    //   27	1	9	localBadCommandException	BadCommandException
    //   30	66	10	localIMAPProtocol	IMAPProtocol
    //   92	9	11	localObject4	Object
    //   75	12	12	localProtocolException3	ProtocolException
    //   47	8	13	localMailboxInfo	com.sun.mail.imap.protocol.MailboxInfo
    // Exception table:
    //   from	to	target	type
    //   13	22	27	com/sun/mail/iap/BadCommandException
    //   2	13	70	finally
    //   13	22	70	finally
    //   61	67	70	finally
    //   94	146	70	finally
    //   166	169	70	finally
    //   32	61	75	com/sun/mail/iap/ProtocolException
    //   32	61	92	finally
    //   77	92	92	finally
    //   13	22	103	com/sun/mail/iap/ConnectionException
    //   13	22	122	com/sun/mail/iap/ProtocolException
    //   146	157	162	finally
    //   157	166	162	finally
    //   171	199	162	finally
    //   146	157	169	com/sun/mail/iap/ConnectionException
    //   146	157	185	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Folder getParent()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 374	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   6: istore_2
    //   7: aload_0
    //   8: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   11: iload_2
    //   12: invokevirtual 778	java/lang/String:lastIndexOf	(I)I
    //   15: istore_3
    //   16: iload_3
    //   17: bipush 255
    //   19: if_icmpeq +38 -> 57
    //   22: new 2	com/sun/mail/imap/IMAPFolder
    //   25: dup
    //   26: aload_0
    //   27: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   30: iconst_0
    //   31: iload_3
    //   32: invokevirtual 223	java/lang/String:substring	(II)Ljava/lang/String;
    //   35: iload_2
    //   36: aload_0
    //   37: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   40: checkcast 186	com/sun/mail/imap/IMAPStore
    //   43: invokespecial 122	com/sun/mail/imap/IMAPFolder:<init>	(Ljava/lang/String;CLcom/sun/mail/imap/IMAPStore;)V
    //   46: astore 4
    //   48: aload 4
    //   50: astore 5
    //   52: aload_0
    //   53: monitorexit
    //   54: aload 5
    //   56: areturn
    //   57: new 788	com/sun/mail/imap/DefaultFolder
    //   60: dup
    //   61: aload_0
    //   62: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   65: checkcast 186	com/sun/mail/imap/IMAPStore
    //   68: invokespecial 791	com/sun/mail/imap/DefaultFolder:<init>	(Lcom/sun/mail/imap/IMAPStore;)V
    //   71: astore 6
    //   73: aload 6
    //   75: astore 5
    //   77: goto -25 -> 52
    //   80: astore_1
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	85	0	this	IMAPFolder
    //   80	4	1	localObject1	Object
    //   6	30	2	c	char
    //   15	17	3	i	int
    //   46	3	4	localIMAPFolder	IMAPFolder
    //   50	26	5	localObject2	Object
    //   71	3	6	localDefaultFolder	DefaultFolder
    // Exception table:
    //   from	to	target	type
    //   2	48	80	finally
    //   57	73	80	finally
  }
  
  public Flags getPermanentFlags()
  {
    try
    {
      Flags localFlags = (Flags)this.permanentFlags.clone();
      return localFlags;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public Quota[] getQuota()
    throws MessagingException
  {
    (Quota[])doOptionalCommand("QUOTA not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.getQuotaRoot(IMAPFolder.this.fullName);
      }
    });
  }
  
  /* Error */
  public char getSeparator()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   6: ldc 64
    //   8: if_icmpne +41 -> 49
    //   11: aconst_null
    //   12: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   15: pop
    //   16: aload_0
    //   17: new 34	com/sun/mail/imap/IMAPFolder$3
    //   20: dup
    //   21: aload_0
    //   22: invokespecial 803	com/sun/mail/imap/IMAPFolder$3:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   25: invokevirtual 515	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   28: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   31: astore 4
    //   33: aload 4
    //   35: ifnull +23 -> 58
    //   38: aload_0
    //   39: aload 4
    //   41: iconst_0
    //   42: aaload
    //   43: getfield 119	com/sun/mail/imap/protocol/ListInfo:separator	C
    //   46: putfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   49: aload_0
    //   50: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   53: istore_2
    //   54: aload_0
    //   55: monitorexit
    //   56: iload_2
    //   57: ireturn
    //   58: aload_0
    //   59: bipush 47
    //   61: putfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   64: goto -15 -> 49
    //   67: astore_1
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	72	0	this	IMAPFolder
    //   67	4	1	localObject	Object
    //   53	4	2	c	char
    //   31	9	4	arrayOfListInfo	ListInfo[]
    // Exception table:
    //   from	to	target	type
    //   2	54	67	finally
    //   58	64	67	finally
  }
  
  protected IMAPProtocol getStoreProtocol()
    throws ProtocolException
  {
    try
    {
      if (this.connectionPoolDebug) {
        this.out.println("DEBUG: getStoreProtocol() - borrowing a connection");
      }
      IMAPProtocol localIMAPProtocol = ((IMAPStore)this.store).getStoreProtocol();
      return localIMAPProtocol;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public int getType()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +24 -> 30
    //   9: aload_0
    //   10: getfield 137	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   13: ifnonnull +8 -> 21
    //   16: aload_0
    //   17: invokevirtual 247	com/sun/mail/imap/IMAPFolder:exists	()Z
    //   20: pop
    //   21: aload_0
    //   22: getfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   25: istore_2
    //   26: aload_0
    //   27: monitorexit
    //   28: iload_2
    //   29: ireturn
    //   30: aload_0
    //   31: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   34: goto -13 -> 21
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	42	0	this	IMAPFolder
    //   37	4	1	localObject	Object
    //   25	4	2	i	int
    // Exception table:
    //   from	to	target	type
    //   2	26	37	finally
    //   30	34	37	finally
  }
  
  /* Error */
  public long getUID(Message paramMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokevirtual 809	javax/mail/Message:getFolder	()Ljavax/mail/Folder;
    //   6: aload_0
    //   7: if_acmpeq +19 -> 26
    //   10: new 811	java/util/NoSuchElementException
    //   13: dup
    //   14: ldc_w 813
    //   17: invokespecial 814	java/util/NoSuchElementException:<init>	(Ljava/lang/String;)V
    //   20: athrow
    //   21: astore_2
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_2
    //   25: athrow
    //   26: aload_0
    //   27: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   30: aload_1
    //   31: checkcast 649	com/sun/mail/imap/IMAPMessage
    //   34: astore_3
    //   35: aload_3
    //   36: invokevirtual 662	com/sun/mail/imap/IMAPMessage:getUID	()J
    //   39: lstore 4
    //   41: lload 4
    //   43: lstore 6
    //   45: lload 6
    //   47: ldc2_w 155
    //   50: lcmp
    //   51: ifeq +12 -> 63
    //   54: lload 6
    //   56: lstore 14
    //   58: aload_0
    //   59: monitorexit
    //   60: lload 14
    //   62: lreturn
    //   63: aload_0
    //   64: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   67: astore 8
    //   69: aload 8
    //   71: monitorenter
    //   72: aload_0
    //   73: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   76: astore 12
    //   78: aload_3
    //   79: invokevirtual 817	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   82: aload 12
    //   84: aload_3
    //   85: invokevirtual 676	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   88: invokevirtual 821	com/sun/mail/imap/protocol/IMAPProtocol:fetchUID	(I)Lcom/sun/mail/imap/protocol/UID;
    //   91: astore 13
    //   93: aload 13
    //   95: ifnull +52 -> 147
    //   98: aload 13
    //   100: getfield 743	com/sun/mail/imap/protocol/UID:uid	J
    //   103: lstore 6
    //   105: aload_3
    //   106: lload 6
    //   108: invokevirtual 746	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   111: aload_0
    //   112: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   115: ifnonnull +14 -> 129
    //   118: aload_0
    //   119: new 669	java/util/Hashtable
    //   122: dup
    //   123: invokespecial 731	java/util/Hashtable:<init>	()V
    //   126: putfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   129: aload_0
    //   130: getfield 321	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   133: new 664	java/lang/Long
    //   136: dup
    //   137: lload 6
    //   139: invokespecial 667	java/lang/Long:<init>	(J)V
    //   142: aload_3
    //   143: invokevirtual 750	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   146: pop
    //   147: aload 8
    //   149: monitorexit
    //   150: lload 6
    //   152: lstore 14
    //   154: goto -96 -> 58
    //   157: astore 11
    //   159: new 288	javax/mail/FolderClosedException
    //   162: dup
    //   163: aload_0
    //   164: aload 11
    //   166: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   169: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   172: athrow
    //   173: astore 10
    //   175: aload 8
    //   177: monitorexit
    //   178: aload 10
    //   180: athrow
    //   181: astore 9
    //   183: new 245	javax/mail/MessagingException
    //   186: dup
    //   187: aload 9
    //   189: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   192: aload 9
    //   194: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   197: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	198	0	this	IMAPFolder
    //   0	198	1	paramMessage	Message
    //   21	4	2	localObject1	Object
    //   34	109	3	localIMAPMessage	IMAPMessage
    //   39	3	4	l1	long
    //   43	108	6	l2	long
    //   181	12	9	localProtocolException	ProtocolException
    //   173	6	10	localObject3	Object
    //   157	8	11	localConnectionException	ConnectionException
    //   76	7	12	localIMAPProtocol	IMAPProtocol
    //   91	8	13	localUID	com.sun.mail.imap.protocol.UID
    //   56	97	14	l3	long
    // Exception table:
    //   from	to	target	type
    //   2	21	21	finally
    //   26	41	21	finally
    //   63	72	21	finally
    //   178	181	21	finally
    //   72	147	157	com/sun/mail/iap/ConnectionException
    //   72	147	173	finally
    //   147	178	173	finally
    //   183	198	173	finally
    //   72	147	181	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public long getUIDNext()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +14 -> 20
    //   9: aload_0
    //   10: getfield 160	com/sun/mail/imap/IMAPFolder:uidnext	J
    //   13: lstore 7
    //   15: aload_0
    //   16: monitorexit
    //   17: lload 7
    //   19: lreturn
    //   20: aconst_null
    //   21: astore_2
    //   22: aconst_null
    //   23: astore_3
    //   24: aload_0
    //   25: invokevirtual 405	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   28: astore_2
    //   29: iconst_1
    //   30: anewarray 211	java/lang/String
    //   33: astore 10
    //   35: aload 10
    //   37: iconst_0
    //   38: ldc_w 824
    //   41: aastore
    //   42: aload_2
    //   43: aload_0
    //   44: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   47: aload 10
    //   49: invokevirtual 409	com/sun/mail/imap/protocol/IMAPProtocol:status	(Ljava/lang/String;[Ljava/lang/String;)Lcom/sun/mail/imap/protocol/Status;
    //   52: astore 11
    //   54: aload 11
    //   56: astore_3
    //   57: aload_0
    //   58: aload_2
    //   59: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   62: aload_3
    //   63: getfield 825	com/sun/mail/imap/protocol/Status:uidnext	J
    //   66: lstore 7
    //   68: goto -53 -> 15
    //   71: astore 9
    //   73: new 245	javax/mail/MessagingException
    //   76: dup
    //   77: ldc_w 827
    //   80: aload 9
    //   82: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   85: athrow
    //   86: astore 5
    //   88: aload_0
    //   89: aload_2
    //   90: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   93: aload 5
    //   95: athrow
    //   96: astore_1
    //   97: aload_0
    //   98: monitorexit
    //   99: aload_1
    //   100: athrow
    //   101: astore 6
    //   103: aload_0
    //   104: aload 6
    //   106: invokespecial 582	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   109: aload_0
    //   110: aload_2
    //   111: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   114: goto -52 -> 62
    //   117: astore 4
    //   119: new 245	javax/mail/MessagingException
    //   122: dup
    //   123: aload 4
    //   125: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   128: aload 4
    //   130: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   133: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	134	0	this	IMAPFolder
    //   96	4	1	localObject1	Object
    //   21	90	2	localIMAPProtocol	IMAPProtocol
    //   23	40	3	localObject2	Object
    //   117	12	4	localProtocolException	ProtocolException
    //   86	8	5	localObject3	Object
    //   101	4	6	localConnectionException	ConnectionException
    //   13	54	7	l	long
    //   71	10	9	localBadCommandException	BadCommandException
    //   33	15	10	arrayOfString	String[]
    //   52	3	11	localStatus	Status
    // Exception table:
    //   from	to	target	type
    //   24	54	71	com/sun/mail/iap/BadCommandException
    //   24	54	86	finally
    //   73	86	86	finally
    //   103	109	86	finally
    //   119	134	86	finally
    //   2	15	96	finally
    //   57	68	96	finally
    //   88	96	96	finally
    //   109	114	96	finally
    //   24	54	101	com/sun/mail/iap/ConnectionException
    //   24	54	117	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public long getUIDValidity()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +14 -> 20
    //   9: aload_0
    //   10: getfield 158	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   13: lstore 7
    //   15: aload_0
    //   16: monitorexit
    //   17: lload 7
    //   19: lreturn
    //   20: aconst_null
    //   21: astore_2
    //   22: aconst_null
    //   23: astore_3
    //   24: aload_0
    //   25: invokevirtual 405	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   28: astore_2
    //   29: iconst_1
    //   30: anewarray 211	java/lang/String
    //   33: astore 10
    //   35: aload 10
    //   37: iconst_0
    //   38: ldc_w 830
    //   41: aastore
    //   42: aload_2
    //   43: aload_0
    //   44: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   47: aload 10
    //   49: invokevirtual 409	com/sun/mail/imap/protocol/IMAPProtocol:status	(Ljava/lang/String;[Ljava/lang/String;)Lcom/sun/mail/imap/protocol/Status;
    //   52: astore 11
    //   54: aload 11
    //   56: astore_3
    //   57: aload_0
    //   58: aload_2
    //   59: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   62: aload_3
    //   63: getfield 831	com/sun/mail/imap/protocol/Status:uidvalidity	J
    //   66: lstore 7
    //   68: goto -53 -> 15
    //   71: astore 9
    //   73: new 245	javax/mail/MessagingException
    //   76: dup
    //   77: ldc_w 833
    //   80: aload 9
    //   82: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   85: athrow
    //   86: astore 5
    //   88: aload_0
    //   89: aload_2
    //   90: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   93: aload 5
    //   95: athrow
    //   96: astore_1
    //   97: aload_0
    //   98: monitorexit
    //   99: aload_1
    //   100: athrow
    //   101: astore 6
    //   103: aload_0
    //   104: aload 6
    //   106: invokespecial 582	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   109: aload_0
    //   110: aload_2
    //   111: invokevirtual 413	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   114: goto -52 -> 62
    //   117: astore 4
    //   119: new 245	javax/mail/MessagingException
    //   122: dup
    //   123: aload 4
    //   125: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   128: aload 4
    //   130: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   133: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	134	0	this	IMAPFolder
    //   96	4	1	localObject1	Object
    //   21	90	2	localIMAPProtocol	IMAPProtocol
    //   23	40	3	localObject2	Object
    //   117	12	4	localProtocolException	ProtocolException
    //   86	8	5	localObject3	Object
    //   101	4	6	localConnectionException	ConnectionException
    //   13	54	7	l	long
    //   71	10	9	localBadCommandException	BadCommandException
    //   33	15	10	arrayOfString	String[]
    //   52	3	11	localStatus	Status
    // Exception table:
    //   from	to	target	type
    //   24	54	71	com/sun/mail/iap/BadCommandException
    //   24	54	86	finally
    //   73	86	86	finally
    //   103	109	86	finally
    //   119	134	86	finally
    //   2	15	96	finally
    //   57	68	96	finally
    //   88	96	96	finally
    //   109	114	96	finally
    //   24	54	101	com/sun/mail/iap/ConnectionException
    //   24	54	117	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public int getUnreadMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +71 -> 77
    //   9: aload_0
    //   10: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 232	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 837	com/sun/mail/imap/protocol/Status:unseen	I
    //   20: istore 7
    //   22: aload_0
    //   23: monitorexit
    //   24: iload 7
    //   26: ireturn
    //   27: astore 10
    //   29: bipush 255
    //   31: istore 7
    //   33: goto -11 -> 22
    //   36: astore 9
    //   38: new 448	javax/mail/StoreClosedException
    //   41: dup
    //   42: aload_0
    //   43: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   46: aload 9
    //   48: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   51: invokespecial 454	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   54: athrow
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    //   60: astore 8
    //   62: new 245	javax/mail/MessagingException
    //   65: dup
    //   66: aload 8
    //   68: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   71: aload 8
    //   73: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   76: athrow
    //   77: new 698	javax/mail/Flags
    //   80: dup
    //   81: invokespecial 699	javax/mail/Flags:<init>	()V
    //   84: astore_2
    //   85: aload_2
    //   86: getstatic 840	javax/mail/Flags$Flag:SEEN	Ljavax/mail/Flags$Flag;
    //   89: invokevirtual 708	javax/mail/Flags:add	(Ljavax/mail/Flags$Flag;)V
    //   92: aload_0
    //   93: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   96: astore 5
    //   98: aload 5
    //   100: monitorenter
    //   101: aload_0
    //   102: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   105: new 710	javax/mail/search/FlagTerm
    //   108: dup
    //   109: aload_2
    //   110: iconst_0
    //   111: invokespecial 713	javax/mail/search/FlagTerm:<init>	(Ljavax/mail/Flags;Z)V
    //   114: invokevirtual 717	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   117: arraylength
    //   118: istore 7
    //   120: aload 5
    //   122: monitorexit
    //   123: goto -101 -> 22
    //   126: astore 6
    //   128: aload 5
    //   130: monitorexit
    //   131: aload 6
    //   133: athrow
    //   134: astore 4
    //   136: new 288	javax/mail/FolderClosedException
    //   139: dup
    //   140: aload_0
    //   141: aload 4
    //   143: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   146: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   149: athrow
    //   150: astore_3
    //   151: new 245	javax/mail/MessagingException
    //   154: dup
    //   155: aload_3
    //   156: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   159: aload_3
    //   160: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   163: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	164	0	this	IMAPFolder
    //   55	4	1	localObject1	Object
    //   84	26	2	localFlags	Flags
    //   150	10	3	localProtocolException1	ProtocolException
    //   134	8	4	localConnectionException1	ConnectionException
    //   126	6	6	localObject3	Object
    //   20	99	7	i	int
    //   60	12	8	localProtocolException2	ProtocolException
    //   36	11	9	localConnectionException2	ConnectionException
    //   27	1	10	localBadCommandException	BadCommandException
    // Exception table:
    //   from	to	target	type
    //   13	22	27	com/sun/mail/iap/BadCommandException
    //   13	22	36	com/sun/mail/iap/ConnectionException
    //   2	13	55	finally
    //   13	22	55	finally
    //   38	55	55	finally
    //   62	92	55	finally
    //   92	101	55	finally
    //   131	134	55	finally
    //   136	164	55	finally
    //   13	22	60	com/sun/mail/iap/ProtocolException
    //   101	131	126	finally
    //   92	101	134	com/sun/mail/iap/ConnectionException
    //   131	134	134	com/sun/mail/iap/ConnectionException
    //   92	101	150	com/sun/mail/iap/ProtocolException
    //   131	134	150	com/sun/mail/iap/ProtocolException
  }
  
  public void handleResponse(Response paramResponse)
  {
    assert (Thread.holdsLock(this.messageCacheLock));
    if ((paramResponse.isOK()) || (paramResponse.isNO()) || (paramResponse.isBAD()) || (paramResponse.isBYE())) {
      ((IMAPStore)this.store).handleResponseCode(paramResponse);
    }
    if (paramResponse.isBYE()) {
      if (this.opened) {
        cleanup(false);
      }
    }
    for (;;)
    {
      return;
      if ((!paramResponse.isOK()) && (paramResponse.isUnTagged())) {
        if (!(paramResponse instanceof IMAPResponse))
        {
          this.out.println("UNEXPECTED RESPONSE : " + paramResponse.toString());
          this.out.println("CONTACT javamail@sun.com");
        }
        else
        {
          IMAPResponse localIMAPResponse = (IMAPResponse)paramResponse;
          if (localIMAPResponse.keyEquals("EXISTS"))
          {
            int j = localIMAPResponse.getNumber();
            if (j > this.realTotal)
            {
              int k = j - this.realTotal;
              Message[] arrayOfMessage2 = new Message[k];
              for (int m = 0;; m++)
              {
                if (m >= k)
                {
                  notifyMessageAddedListeners(arrayOfMessage2);
                  break;
                }
                int n = 1 + this.total;
                this.total = n;
                int i1 = 1 + this.realTotal;
                this.realTotal = i1;
                IMAPMessage localIMAPMessage4 = new IMAPMessage(this, n, i1);
                arrayOfMessage2[m] = localIMAPMessage4;
                this.messageCache.addElement(localIMAPMessage4);
              }
            }
          }
          else if (localIMAPResponse.keyEquals("EXPUNGE"))
          {
            IMAPMessage localIMAPMessage2 = getMessageBySeqNumber(localIMAPResponse.getNumber());
            localIMAPMessage2.setExpunged(true);
            int i = localIMAPMessage2.getMessageNumber();
            if (i >= this.total)
            {
              this.realTotal = (-1 + this.realTotal);
              if (this.doExpungeNotification)
              {
                Message[] arrayOfMessage1 = new Message[1];
                arrayOfMessage1[0] = localIMAPMessage2;
                notifyMessageRemovedListeners(false, arrayOfMessage1);
              }
            }
            else
            {
              IMAPMessage localIMAPMessage3 = (IMAPMessage)this.messageCache.elementAt(i);
              if (localIMAPMessage3.isExpunged()) {}
              for (;;)
              {
                i++;
                break;
                localIMAPMessage3.setSequenceNumber(-1 + localIMAPMessage3.getSequenceNumber());
              }
            }
          }
          else if (localIMAPResponse.keyEquals("FETCH"))
          {
            assert ((localIMAPResponse instanceof FetchResponse)) : "!ir instanceof FetchResponse";
            FetchResponse localFetchResponse = (FetchResponse)localIMAPResponse;
            Flags localFlags = (Flags)localFetchResponse.getItem(Flags.class);
            if (localFlags != null)
            {
              IMAPMessage localIMAPMessage1 = getMessageBySeqNumber(localFetchResponse.getNumber());
              if (localIMAPMessage1 != null)
              {
                localIMAPMessage1._setFlags(localFlags);
                notifyMessageChangedListeners(1, localIMAPMessage1);
              }
            }
          }
          else if (localIMAPResponse.keyEquals("RECENT"))
          {
            this.recent = localIMAPResponse.getNumber();
          }
        }
      }
    }
  }
  
  void handleResponses(Response[] paramArrayOfResponse)
  {
    for (int i = 0;; i++)
    {
      if (i >= paramArrayOfResponse.length) {
        return;
      }
      if (paramArrayOfResponse[i] != null) {
        handleResponse(paramArrayOfResponse[i]);
      }
    }
  }
  
  /* Error */
  public boolean hasNewMessages()
    throws MessagingException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   8: ifeq +79 -> 87
    //   11: aload_0
    //   12: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   15: astore 5
    //   17: aload 5
    //   19: monitorenter
    //   20: aload_0
    //   21: iconst_1
    //   22: invokespecial 304	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   25: aload_0
    //   26: getfield 152	com/sun/mail/imap/IMAPFolder:recent	I
    //   29: ifle +5 -> 34
    //   32: iconst_1
    //   33: istore_1
    //   34: aload 5
    //   36: monitorexit
    //   37: aload_0
    //   38: monitorexit
    //   39: iload_1
    //   40: ireturn
    //   41: astore 8
    //   43: new 288	javax/mail/FolderClosedException
    //   46: dup
    //   47: aload_0
    //   48: aload 8
    //   50: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   53: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   56: athrow
    //   57: astore 7
    //   59: aload 5
    //   61: monitorexit
    //   62: aload 7
    //   64: athrow
    //   65: astore_2
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_2
    //   69: athrow
    //   70: astore 6
    //   72: new 245	javax/mail/MessagingException
    //   75: dup
    //   76: aload 6
    //   78: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   81: aload 6
    //   83: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   86: athrow
    //   87: aload_0
    //   88: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   91: aload_0
    //   92: new 42	com/sun/mail/imap/IMAPFolder$7
    //   95: dup
    //   96: aload_0
    //   97: invokespecial 923	com/sun/mail/imap/IMAPFolder$7:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   100: invokevirtual 381	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   103: checkcast 925	java/lang/Boolean
    //   106: astore_3
    //   107: aload_3
    //   108: ifnull -71 -> 37
    //   111: aload_3
    //   112: invokevirtual 928	java/lang/Boolean:booleanValue	()Z
    //   115: istore 4
    //   117: iload 4
    //   119: istore_1
    //   120: goto -83 -> 37
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	123	0	this	IMAPFolder
    //   1	119	1	bool1	boolean
    //   65	4	2	localObject1	Object
    //   106	6	3	localBoolean	Boolean
    //   115	3	4	bool2	boolean
    //   70	12	6	localProtocolException	ProtocolException
    //   57	6	7	localObject3	Object
    //   41	8	8	localConnectionException	ConnectionException
    // Exception table:
    //   from	to	target	type
    //   20	25	41	com/sun/mail/iap/ConnectionException
    //   20	25	57	finally
    //   25	37	57	finally
    //   43	62	57	finally
    //   72	87	57	finally
    //   4	20	65	finally
    //   62	65	65	finally
    //   87	117	65	finally
    //   20	25	70	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public void idle()
    throws MessagingException
  {
    // Byte code:
    //   0: getstatic 111	com/sun/mail/imap/IMAPFolder:$assertionsDisabled	Z
    //   3: ifne +18 -> 21
    //   6: aload_0
    //   7: invokestatic 277	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
    //   10: ifeq +11 -> 21
    //   13: new 279	java/lang/AssertionError
    //   16: dup
    //   17: invokespecial 280	java/lang/AssertionError:<init>	()V
    //   20: athrow
    //   21: aload_0
    //   22: monitorenter
    //   23: aload_0
    //   24: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   27: aload_0
    //   28: ldc_w 933
    //   31: new 28	com/sun/mail/imap/IMAPFolder$19
    //   34: dup
    //   35: aload_0
    //   36: invokespecial 934	com/sun/mail/imap/IMAPFolder$19:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   39: invokevirtual 444	com/sun/mail/imap/IMAPFolder:doOptionalCommand	(Ljava/lang/String;Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   42: checkcast 925	java/lang/Boolean
    //   45: invokevirtual 928	java/lang/Boolean:booleanValue	()Z
    //   48: ifne +8 -> 56
    //   51: aload_0
    //   52: monitorexit
    //   53: goto +138 -> 191
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_0
    //   59: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   62: invokevirtual 938	com/sun/mail/imap/protocol/IMAPProtocol:readIdleResponse	()Lcom/sun/mail/iap/Response;
    //   65: astore_2
    //   66: aload_0
    //   67: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   70: astore 5
    //   72: aload 5
    //   74: monitorenter
    //   75: aload_2
    //   76: ifnull +21 -> 97
    //   79: aload_0
    //   80: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   83: ifnull +14 -> 97
    //   86: aload_0
    //   87: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   90: aload_2
    //   91: invokevirtual 942	com/sun/mail/imap/protocol/IMAPProtocol:processIdleResponse	(Lcom/sun/mail/iap/Response;)Z
    //   94: ifne +58 -> 152
    //   97: aload_0
    //   98: iconst_0
    //   99: putfield 148	com/sun/mail/imap/IMAPFolder:idleState	I
    //   102: aload_0
    //   103: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   106: invokevirtual 945	java/lang/Object:notifyAll	()V
    //   109: aload 5
    //   111: monitorexit
    //   112: aload_0
    //   113: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   116: checkcast 186	com/sun/mail/imap/IMAPStore
    //   119: invokevirtual 948	com/sun/mail/imap/IMAPStore:getMinIdleTime	()I
    //   122: istore 7
    //   124: iload 7
    //   126: ifle +65 -> 191
    //   129: iload 7
    //   131: i2l
    //   132: lstore 8
    //   134: lload 8
    //   136: invokestatic 951	java/lang/Thread:sleep	(J)V
    //   139: goto +52 -> 191
    //   142: astore 10
    //   144: goto +47 -> 191
    //   147: astore_1
    //   148: aload_0
    //   149: monitorexit
    //   150: aload_1
    //   151: athrow
    //   152: aload 5
    //   154: monitorexit
    //   155: goto -97 -> 58
    //   158: astore 6
    //   160: aload 5
    //   162: monitorexit
    //   163: aload 6
    //   165: athrow
    //   166: astore 4
    //   168: aload_0
    //   169: aload 4
    //   171: invokespecial 582	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   174: goto -116 -> 58
    //   177: astore_3
    //   178: new 245	javax/mail/MessagingException
    //   181: dup
    //   182: aload_3
    //   183: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   186: aload_3
    //   187: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   190: athrow
    //   191: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	192	0	this	IMAPFolder
    //   147	4	1	localObject1	Object
    //   65	26	2	localResponse	Response
    //   177	10	3	localProtocolException	ProtocolException
    //   166	4	4	localConnectionException	ConnectionException
    //   70	91	5	localObject2	Object
    //   158	6	6	localObject3	Object
    //   122	8	7	i	int
    //   132	3	8	l	long
    //   142	1	10	localInterruptedException	InterruptedException
    // Exception table:
    //   from	to	target	type
    //   134	139	142	java/lang/InterruptedException
    //   23	58	147	finally
    //   148	150	147	finally
    //   79	112	158	finally
    //   152	163	158	finally
    //   66	75	166	com/sun/mail/iap/ConnectionException
    //   163	166	166	com/sun/mail/iap/ConnectionException
    //   66	75	177	com/sun/mail/iap/ProtocolException
    //   163	166	177	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public boolean isOpen()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   6: astore_2
    //   7: aload_2
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   13: istore 4
    //   15: iload 4
    //   17: ifeq +8 -> 25
    //   20: aload_0
    //   21: iconst_0
    //   22: invokespecial 304	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   25: aload_2
    //   26: monitorexit
    //   27: aload_0
    //   28: getfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   31: istore 5
    //   33: aload_0
    //   34: monitorexit
    //   35: iload 5
    //   37: ireturn
    //   38: astore_3
    //   39: aload_2
    //   40: monitorexit
    //   41: aload_3
    //   42: athrow
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    //   48: astore 6
    //   50: goto -25 -> 25
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	53	0	this	IMAPFolder
    //   43	4	1	localObject1	Object
    //   38	4	3	localObject3	Object
    //   13	3	4	bool1	boolean
    //   31	5	5	bool2	boolean
    //   48	1	6	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   9	15	38	finally
    //   20	25	38	finally
    //   25	27	38	finally
    //   39	41	38	finally
    //   2	9	43	finally
    //   27	33	43	finally
    //   41	43	43	finally
    //   20	25	48	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public boolean isSubscribed()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   6: astore_2
    //   7: aload_0
    //   8: getfield 142	com/sun/mail/imap/IMAPFolder:isNamespace	Z
    //   11: ifeq +78 -> 89
    //   14: aload_0
    //   15: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   18: ifeq +71 -> 89
    //   21: new 251	java/lang/StringBuilder
    //   24: dup
    //   25: aload_0
    //   26: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   29: invokestatic 255	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   32: invokespecial 256	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   35: aload_0
    //   36: getfield 178	com/sun/mail/imap/IMAPFolder:separator	C
    //   39: invokevirtual 386	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   42: invokevirtual 266	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   45: astore 6
    //   47: aload 6
    //   49: astore_3
    //   50: aload_0
    //   51: new 36	com/sun/mail/imap/IMAPFolder$4
    //   54: dup
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 954	com/sun/mail/imap/IMAPFolder$4:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljava/lang/String;)V
    //   60: invokevirtual 580	com/sun/mail/imap/IMAPFolder:doProtocolCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   63: checkcast 383	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   66: astore_2
    //   67: aload_2
    //   68: ifnull +29 -> 97
    //   71: aload_2
    //   72: aload_0
    //   73: aload_2
    //   74: aload_3
    //   75: invokespecial 592	com/sun/mail/imap/IMAPFolder:findName	([Lcom/sun/mail/imap/protocol/ListInfo;Ljava/lang/String;)I
    //   78: aaload
    //   79: getfield 130	com/sun/mail/imap/protocol/ListInfo:canOpen	Z
    //   82: istore 5
    //   84: aload_0
    //   85: monitorexit
    //   86: iload 5
    //   88: ireturn
    //   89: aload_0
    //   90: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   93: astore_3
    //   94: goto -44 -> 50
    //   97: iconst_0
    //   98: istore 5
    //   100: goto -16 -> 84
    //   103: astore_1
    //   104: aload_0
    //   105: monitorexit
    //   106: aload_1
    //   107: athrow
    //   108: astore 4
    //   110: goto -43 -> 67
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	113	0	this	IMAPFolder
    //   103	4	1	localObject	Object
    //   6	68	2	arrayOfListInfo	ListInfo[]
    //   49	45	3	str1	String
    //   108	1	4	localProtocolException	ProtocolException
    //   82	17	5	bool	boolean
    //   45	3	6	str2	String
    // Exception table:
    //   from	to	target	type
    //   2	47	103	finally
    //   50	67	103	finally
    //   71	84	103	finally
    //   89	94	103	finally
    //   50	67	108	com/sun/mail/iap/ProtocolException
  }
  
  public Folder[] list(String paramString)
    throws MessagingException
  {
    return doList(paramString, false);
  }
  
  public Rights[] listRights(final String paramString)
    throws MessagingException
  {
    (Rights[])doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.listRights(IMAPFolder.this.fullName, paramString);
      }
    });
  }
  
  public Folder[] listSubscribed(String paramString)
    throws MessagingException
  {
    return doList(paramString, true);
  }
  
  public Rights myRights()
    throws MessagingException
  {
    (Rights)doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.myRights(IMAPFolder.this.fullName);
      }
    });
  }
  
  /* Error */
  public void open(int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 568	com/sun/mail/imap/IMAPFolder:checkClosed	()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   11: checkcast 186	com/sun/mail/imap/IMAPStore
    //   14: aload_0
    //   15: invokevirtual 972	com/sun/mail/imap/IMAPStore:getProtocol	(Lcom/sun/mail/imap/IMAPFolder;)Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   18: putfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   21: aconst_null
    //   22: astore_3
    //   23: aload_0
    //   24: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   27: astore 4
    //   29: aload 4
    //   31: monitorenter
    //   32: aload_0
    //   33: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: aload_0
    //   37: invokevirtual 975	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   40: iload_1
    //   41: iconst_1
    //   42: if_icmpne +202 -> 244
    //   45: aload_0
    //   46: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   49: aload_0
    //   50: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   53: invokevirtual 363	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   56: astore 18
    //   58: aload 18
    //   60: astore 11
    //   62: aload 11
    //   64: getfield 976	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   67: iload_1
    //   68: if_icmpeq +30 -> 98
    //   71: iload_1
    //   72: iconst_2
    //   73: if_icmpne +254 -> 327
    //   76: aload 11
    //   78: getfield 976	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   81: iconst_1
    //   82: if_icmpne +245 -> 327
    //   85: aload_0
    //   86: getfield 349	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   89: checkcast 186	com/sun/mail/imap/IMAPStore
    //   92: invokevirtual 979	com/sun/mail/imap/IMAPStore:allowReadOnlySelect	()Z
    //   95: ifeq +232 -> 327
    //   98: aload_0
    //   99: iconst_1
    //   100: putfield 144	com/sun/mail/imap/IMAPFolder:opened	Z
    //   103: aload_0
    //   104: iconst_0
    //   105: putfield 146	com/sun/mail/imap/IMAPFolder:reallyClosed	Z
    //   108: aload_0
    //   109: aload 11
    //   111: getfield 976	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   114: putfield 283	com/sun/mail/imap/IMAPFolder:mode	I
    //   117: aload_0
    //   118: aload 11
    //   120: getfield 981	com/sun/mail/imap/protocol/MailboxInfo:availableFlags	Ljavax/mail/Flags;
    //   123: putfield 982	com/sun/mail/imap/IMAPFolder:availableFlags	Ljavax/mail/Flags;
    //   126: aload_0
    //   127: aload 11
    //   129: getfield 983	com/sun/mail/imap/protocol/MailboxInfo:permanentFlags	Ljavax/mail/Flags;
    //   132: putfield 794	com/sun/mail/imap/IMAPFolder:permanentFlags	Ljavax/mail/Flags;
    //   135: aload 11
    //   137: getfield 757	com/sun/mail/imap/protocol/MailboxInfo:total	I
    //   140: istore 12
    //   142: aload_0
    //   143: iload 12
    //   145: putfield 154	com/sun/mail/imap/IMAPFolder:realTotal	I
    //   148: aload_0
    //   149: iload 12
    //   151: putfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   154: aload_0
    //   155: aload 11
    //   157: getfield 784	com/sun/mail/imap/protocol/MailboxInfo:recent	I
    //   160: putfield 152	com/sun/mail/imap/IMAPFolder:recent	I
    //   163: aload_0
    //   164: aload 11
    //   166: getfield 984	com/sun/mail/imap/protocol/MailboxInfo:uidvalidity	J
    //   169: putfield 158	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   172: aload_0
    //   173: aload 11
    //   175: getfield 985	com/sun/mail/imap/protocol/MailboxInfo:uidnext	J
    //   178: putfield 160	com/sun/mail/imap/IMAPFolder:uidnext	J
    //   181: aload_0
    //   182: new 602	java/util/Vector
    //   185: dup
    //   186: aload_0
    //   187: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   190: invokespecial 987	java/util/Vector:<init>	(I)V
    //   193: putfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   196: iconst_0
    //   197: istore 13
    //   199: iload 13
    //   201: aload_0
    //   202: getfield 150	com/sun/mail/imap/IMAPFolder:total	I
    //   205: if_icmplt +188 -> 393
    //   208: aload 4
    //   210: monitorexit
    //   211: aload_3
    //   212: ifnull +223 -> 435
    //   215: aload_0
    //   216: invokespecial 367	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   219: iconst_1
    //   220: aload_0
    //   221: getfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   224: iand
    //   225: ifne +197 -> 422
    //   228: new 245	javax/mail/MessagingException
    //   231: dup
    //   232: ldc_w 989
    //   235: invokespecial 722	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   238: athrow
    //   239: astore_2
    //   240: aload_0
    //   241: monitorexit
    //   242: aload_2
    //   243: athrow
    //   244: aload_0
    //   245: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   248: aload_0
    //   249: getfield 177	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   252: invokevirtual 992	com/sun/mail/imap/protocol/IMAPProtocol:select	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   255: astore 10
    //   257: aload 10
    //   259: astore 11
    //   261: goto -199 -> 62
    //   264: astore 9
    //   266: aload_0
    //   267: iconst_1
    //   268: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   271: aload_0
    //   272: aconst_null
    //   273: putfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   276: aload 9
    //   278: astore_3
    //   279: aload 4
    //   281: monitorexit
    //   282: goto -71 -> 211
    //   285: astore 5
    //   287: aload 4
    //   289: monitorexit
    //   290: aload 5
    //   292: athrow
    //   293: astore 6
    //   295: aload_0
    //   296: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   299: invokevirtual 359	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   302: aload_0
    //   303: iconst_0
    //   304: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   307: aload_0
    //   308: aconst_null
    //   309: putfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   312: new 245	javax/mail/MessagingException
    //   315: dup
    //   316: aload 6
    //   318: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   321: aload 6
    //   323: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   326: athrow
    //   327: aload_0
    //   328: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   331: invokevirtual 356	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   334: aload_0
    //   335: iconst_1
    //   336: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   339: aload_0
    //   340: aconst_null
    //   341: putfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   344: new 994	javax/mail/ReadOnlyFolderException
    //   347: dup
    //   348: aload_0
    //   349: ldc_w 996
    //   352: invokespecial 997	javax/mail/ReadOnlyFolderException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   355: athrow
    //   356: astore 15
    //   358: aload_0
    //   359: getfield 317	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   362: invokevirtual 359	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   365: aload_0
    //   366: iconst_0
    //   367: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   370: goto -31 -> 339
    //   373: astore 17
    //   375: aload_0
    //   376: iconst_0
    //   377: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   380: goto -41 -> 339
    //   383: astore 16
    //   385: aload_0
    //   386: iconst_0
    //   387: invokespecial 315	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   390: aload 16
    //   392: athrow
    //   393: aload_0
    //   394: getfield 319	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   397: new 649	com/sun/mail/imap/IMAPMessage
    //   400: dup
    //   401: aload_0
    //   402: iload 13
    //   404: iconst_1
    //   405: iadd
    //   406: iload 13
    //   408: iconst_1
    //   409: iadd
    //   410: invokespecial 884	com/sun/mail/imap/IMAPMessage:<init>	(Lcom/sun/mail/imap/IMAPFolder;II)V
    //   413: invokevirtual 656	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   416: iinc 13 1
    //   419: goto -220 -> 199
    //   422: new 245	javax/mail/MessagingException
    //   425: dup
    //   426: aload_3
    //   427: invokevirtual 540	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   430: aload_3
    //   431: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   434: athrow
    //   435: aload_0
    //   436: iconst_1
    //   437: putfield 132	com/sun/mail/imap/IMAPFolder:exists	Z
    //   440: aload_0
    //   441: aconst_null
    //   442: putfield 137	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   445: aload_0
    //   446: iconst_1
    //   447: putfield 127	com/sun/mail/imap/IMAPFolder:type	I
    //   450: aload_0
    //   451: iconst_1
    //   452: invokevirtual 324	com/sun/mail/imap/IMAPFolder:notifyConnectionListeners	(I)V
    //   455: aload_0
    //   456: monitorexit
    //   457: return
    //   458: astore 8
    //   460: goto -158 -> 302
    //   463: astore 7
    //   465: goto -163 -> 302
    //   468: astore 14
    //   470: goto -131 -> 339
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	473	0	this	IMAPFolder
    //   0	473	1	paramInt	int
    //   239	4	2	localObject1	Object
    //   22	409	3	localObject2	Object
    //   27	261	4	localObject3	Object
    //   285	6	5	localObject4	Object
    //   293	29	6	localProtocolException1	ProtocolException
    //   463	1	7	localProtocolException2	ProtocolException
    //   458	1	8	localObject5	Object
    //   264	13	9	localCommandFailedException	CommandFailedException
    //   255	3	10	localMailboxInfo1	com.sun.mail.imap.protocol.MailboxInfo
    //   60	200	11	localObject6	Object
    //   140	10	12	i	int
    //   197	220	13	j	int
    //   468	1	14	localObject7	Object
    //   356	1	15	localProtocolException3	ProtocolException
    //   383	8	16	localObject8	Object
    //   373	1	17	localProtocolException4	ProtocolException
    //   56	3	18	localMailboxInfo2	com.sun.mail.imap.protocol.MailboxInfo
    // Exception table:
    //   from	to	target	type
    //   2	32	239	finally
    //   215	239	239	finally
    //   290	293	239	finally
    //   422	455	239	finally
    //   45	58	264	com/sun/mail/iap/CommandFailedException
    //   244	257	264	com/sun/mail/iap/CommandFailedException
    //   32	40	285	finally
    //   45	58	285	finally
    //   62	211	285	finally
    //   244	257	285	finally
    //   266	290	285	finally
    //   302	327	285	finally
    //   339	356	285	finally
    //   393	416	285	finally
    //   45	58	293	com/sun/mail/iap/ProtocolException
    //   244	257	293	com/sun/mail/iap/ProtocolException
    //   327	339	356	com/sun/mail/iap/ProtocolException
    //   358	365	373	com/sun/mail/iap/ProtocolException
    //   358	365	383	finally
    //   295	302	458	finally
    //   295	302	463	com/sun/mail/iap/ProtocolException
    //   327	339	468	finally
    //   365	393	468	finally
  }
  
  protected void releaseStoreProtocol(IMAPProtocol paramIMAPProtocol)
  {
    try
    {
      if (paramIMAPProtocol != this.protocol) {
        ((IMAPStore)this.store).releaseStoreProtocol(paramIMAPProtocol);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeACL(final String paramString)
    throws MessagingException
  {
    doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.deleteACL(IMAPFolder.this.fullName, paramString);
        return null;
      }
    });
  }
  
  public void removeRights(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '-');
  }
  
  public boolean renameTo(final Folder paramFolder)
    throws MessagingException
  {
    boolean bool = false;
    try
    {
      checkClosed();
      checkExists();
      if (paramFolder.getStore() != this.store) {
        throw new MessagingException("Can't rename across Stores");
      }
    }
    finally {}
    Object localObject2 = doCommandIgnoreFailure(new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.rename(IMAPFolder.this.fullName, paramFolder.getFullName());
        return Boolean.TRUE;
      }
    });
    if (localObject2 == null) {}
    for (;;)
    {
      return bool;
      this.exists = false;
      this.attributes = null;
      notifyFolderRenamedListeners(paramFolder);
      bool = true;
    }
  }
  
  /* Error */
  public Message[] search(javax.mail.search.SearchTerm paramSearchTerm)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aconst_null
    //   7: checkcast 1016	[Ljavax/mail/Message;
    //   10: astore 6
    //   12: aload_0
    //   13: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   16: astore 8
    //   18: aload 8
    //   20: monitorenter
    //   21: aload_0
    //   22: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   25: aload_1
    //   26: invokevirtual 717	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   29: astore 10
    //   31: aload 10
    //   33: ifnull +22 -> 55
    //   36: aload 10
    //   38: arraylength
    //   39: anewarray 649	com/sun/mail/imap/IMAPMessage
    //   42: astore 6
    //   44: iconst_0
    //   45: istore 11
    //   47: iload 11
    //   49: aload 10
    //   51: arraylength
    //   52: if_icmplt +11 -> 63
    //   55: aload 8
    //   57: monitorexit
    //   58: aload_0
    //   59: monitorexit
    //   60: aload 6
    //   62: areturn
    //   63: aload 6
    //   65: iload 11
    //   67: aload_0
    //   68: aload 10
    //   70: iload 11
    //   72: iaload
    //   73: invokevirtual 742	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   76: aastore
    //   77: iinc 11 1
    //   80: goto -33 -> 47
    //   83: astore 9
    //   85: aload 8
    //   87: monitorexit
    //   88: aload 9
    //   90: athrow
    //   91: astore 7
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial 1018	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;)[Ljavax/mail/Message;
    //   98: astore 6
    //   100: goto -42 -> 58
    //   103: astore 5
    //   105: aload_0
    //   106: aload_1
    //   107: invokespecial 1018	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;)[Ljavax/mail/Message;
    //   110: astore 6
    //   112: goto -54 -> 58
    //   115: astore 4
    //   117: new 288	javax/mail/FolderClosedException
    //   120: dup
    //   121: aload_0
    //   122: aload 4
    //   124: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   127: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   130: athrow
    //   131: astore_2
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_2
    //   135: athrow
    //   136: astore_3
    //   137: new 245	javax/mail/MessagingException
    //   140: dup
    //   141: aload_3
    //   142: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   145: aload_3
    //   146: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   149: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	150	0	this	IMAPFolder
    //   0	150	1	paramSearchTerm	javax.mail.search.SearchTerm
    //   131	4	2	localObject1	Object
    //   136	10	3	localProtocolException	ProtocolException
    //   115	8	4	localConnectionException	ConnectionException
    //   103	1	5	localSearchException	javax.mail.search.SearchException
    //   10	101	6	localObject2	Object
    //   91	1	7	localCommandFailedException	CommandFailedException
    //   83	6	9	localObject4	Object
    //   29	40	10	arrayOfInt	int[]
    //   45	33	11	i	int
    // Exception table:
    //   from	to	target	type
    //   21	58	83	finally
    //   63	88	83	finally
    //   6	21	91	com/sun/mail/iap/CommandFailedException
    //   88	91	91	com/sun/mail/iap/CommandFailedException
    //   6	21	103	javax/mail/search/SearchException
    //   88	91	103	javax/mail/search/SearchException
    //   6	21	115	com/sun/mail/iap/ConnectionException
    //   88	91	115	com/sun/mail/iap/ConnectionException
    //   2	6	131	finally
    //   6	21	131	finally
    //   88	91	131	finally
    //   93	131	131	finally
    //   137	150	131	finally
    //   6	21	136	com/sun/mail/iap/ProtocolException
    //   88	91	136	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] search(javax.mail.search.SearchTerm paramSearchTerm, Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_2
    //   7: arraylength
    //   8: istore 4
    //   10: iload 4
    //   12: ifne +7 -> 19
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: areturn
    //   19: aconst_null
    //   20: checkcast 1016	[Ljavax/mail/Message;
    //   23: astore 10
    //   25: aload_0
    //   26: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   29: astore 11
    //   31: aload 11
    //   33: monitorenter
    //   34: aload_0
    //   35: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   38: astore 13
    //   40: aload_2
    //   41: aconst_null
    //   42: invokestatic 536	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   45: astore 14
    //   47: aload 14
    //   49: ifnonnull +38 -> 87
    //   52: new 485	javax/mail/MessageRemovedException
    //   55: dup
    //   56: ldc_w 538
    //   59: invokespecial 539	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   62: athrow
    //   63: astore 12
    //   65: aload 11
    //   67: monitorexit
    //   68: aload 12
    //   70: athrow
    //   71: astore 8
    //   73: aload_0
    //   74: aload_1
    //   75: aload_2
    //   76: invokespecial 1021	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;[Ljavax/mail/Message;)[Ljavax/mail/Message;
    //   79: astore 9
    //   81: aload 9
    //   83: astore_2
    //   84: goto -69 -> 15
    //   87: aload 13
    //   89: aload 14
    //   91: aload_1
    //   92: invokevirtual 1024	com/sun/mail/imap/protocol/IMAPProtocol:search	([Lcom/sun/mail/imap/protocol/MessageSet;Ljavax/mail/search/SearchTerm;)[I
    //   95: astore 15
    //   97: aload 15
    //   99: ifnull +22 -> 121
    //   102: aload 15
    //   104: arraylength
    //   105: anewarray 649	com/sun/mail/imap/IMAPMessage
    //   108: astore 10
    //   110: iconst_0
    //   111: istore 16
    //   113: iload 16
    //   115: aload 15
    //   117: arraylength
    //   118: if_icmplt +12 -> 130
    //   121: aload 11
    //   123: monitorexit
    //   124: aload 10
    //   126: astore_2
    //   127: goto -112 -> 15
    //   130: aload 10
    //   132: iload 16
    //   134: aload_0
    //   135: aload 15
    //   137: iload 16
    //   139: iaload
    //   140: invokevirtual 742	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   143: aastore
    //   144: iinc 16 1
    //   147: goto -34 -> 113
    //   150: astore 7
    //   152: aload_0
    //   153: aload_1
    //   154: aload_2
    //   155: invokespecial 1021	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;[Ljavax/mail/Message;)[Ljavax/mail/Message;
    //   158: astore_2
    //   159: goto -144 -> 15
    //   162: astore 6
    //   164: new 288	javax/mail/FolderClosedException
    //   167: dup
    //   168: aload_0
    //   169: aload 6
    //   171: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   174: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   177: athrow
    //   178: astore_3
    //   179: aload_0
    //   180: monitorexit
    //   181: aload_3
    //   182: athrow
    //   183: astore 5
    //   185: new 245	javax/mail/MessagingException
    //   188: dup
    //   189: aload 5
    //   191: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   194: aload 5
    //   196: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   199: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	200	0	this	IMAPFolder
    //   0	200	1	paramSearchTerm	javax.mail.search.SearchTerm
    //   0	200	2	paramArrayOfMessage	Message[]
    //   178	4	3	localObject1	Object
    //   8	3	4	i	int
    //   183	12	5	localProtocolException	ProtocolException
    //   162	8	6	localConnectionException	ConnectionException
    //   150	1	7	localSearchException	javax.mail.search.SearchException
    //   71	1	8	localCommandFailedException	CommandFailedException
    //   79	3	9	arrayOfMessage	Message[]
    //   23	108	10	localObject2	Object
    //   29	93	11	localObject3	Object
    //   63	6	12	localObject4	Object
    //   38	50	13	localIMAPProtocol	IMAPProtocol
    //   45	45	14	arrayOfMessageSet	com.sun.mail.imap.protocol.MessageSet[]
    //   95	41	15	arrayOfInt	int[]
    //   111	34	16	j	int
    // Exception table:
    //   from	to	target	type
    //   34	68	63	finally
    //   87	144	63	finally
    //   19	34	71	com/sun/mail/iap/CommandFailedException
    //   68	71	71	com/sun/mail/iap/CommandFailedException
    //   19	34	150	javax/mail/search/SearchException
    //   68	71	150	javax/mail/search/SearchException
    //   19	34	162	com/sun/mail/iap/ConnectionException
    //   68	71	162	com/sun/mail/iap/ConnectionException
    //   2	10	178	finally
    //   19	34	178	finally
    //   68	71	178	finally
    //   73	81	178	finally
    //   152	178	178	finally
    //   185	200	178	finally
    //   19	34	183	com/sun/mail/iap/ProtocolException
    //   68	71	183	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 462	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: aload_2
    //   8: invokespecial 1028	com/sun/mail/imap/IMAPFolder:checkFlags	(Ljavax/mail/Flags;)V
    //   11: aload_1
    //   12: arraylength
    //   13: istore 5
    //   15: iload 5
    //   17: ifne +6 -> 23
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: getfield 184	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   27: astore 6
    //   29: aload 6
    //   31: monitorenter
    //   32: aload_0
    //   33: invokespecial 530	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 10
    //   38: aload_1
    //   39: aconst_null
    //   40: invokestatic 536	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   43: astore 11
    //   45: aload 11
    //   47: ifnonnull +45 -> 92
    //   50: new 485	javax/mail/MessageRemovedException
    //   53: dup
    //   54: ldc_w 538
    //   57: invokespecial 539	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   60: athrow
    //   61: astore 9
    //   63: new 288	javax/mail/FolderClosedException
    //   66: dup
    //   67: aload_0
    //   68: aload 9
    //   70: invokevirtual 307	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   73: invokespecial 293	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   76: athrow
    //   77: astore 8
    //   79: aload 6
    //   81: monitorexit
    //   82: aload 8
    //   84: athrow
    //   85: astore 4
    //   87: aload_0
    //   88: monitorexit
    //   89: aload 4
    //   91: athrow
    //   92: aload 10
    //   94: aload 11
    //   96: aload_2
    //   97: iload_3
    //   98: invokevirtual 1032	com/sun/mail/imap/protocol/IMAPProtocol:storeFlags	([Lcom/sun/mail/imap/protocol/MessageSet;Ljavax/mail/Flags;Z)V
    //   101: aload 6
    //   103: monitorexit
    //   104: goto -84 -> 20
    //   107: astore 7
    //   109: new 245	javax/mail/MessagingException
    //   112: dup
    //   113: aload 7
    //   115: invokevirtual 308	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   118: aload 7
    //   120: invokespecial 311	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   123: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	124	0	this	IMAPFolder
    //   0	124	1	paramArrayOfMessage	Message[]
    //   0	124	2	paramFlags	Flags
    //   0	124	3	paramBoolean	boolean
    //   85	5	4	localObject1	Object
    //   13	3	5	i	int
    //   107	12	7	localProtocolException	ProtocolException
    //   77	6	8	localObject3	Object
    //   61	8	9	localConnectionException	ConnectionException
    //   36	57	10	localIMAPProtocol	IMAPProtocol
    //   43	52	11	arrayOfMessageSet	com.sun.mail.imap.protocol.MessageSet[]
    // Exception table:
    //   from	to	target	type
    //   32	61	61	com/sun/mail/iap/ConnectionException
    //   92	101	61	com/sun/mail/iap/ConnectionException
    //   32	61	77	finally
    //   63	82	77	finally
    //   92	101	77	finally
    //   101	124	77	finally
    //   2	15	85	finally
    //   23	32	85	finally
    //   82	85	85	finally
    //   32	61	107	com/sun/mail/iap/ProtocolException
    //   92	101	107	com/sun/mail/iap/ProtocolException
  }
  
  public void setQuota(final Quota paramQuota)
    throws MessagingException
  {
    doOptionalCommand("QUOTA not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.setQuota(paramQuota);
        return null;
      }
    });
  }
  
  public void setSubscribed(final boolean paramBoolean)
    throws MessagingException
  {
    try
    {
      doCommandIgnoreFailure(new ProtocolCommand()
      {
        public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
          throws ProtocolException
        {
          if (paramBoolean) {
            paramAnonymousIMAPProtocol.subscribe(IMAPFolder.this.fullName);
          }
          for (;;)
          {
            return null;
            paramAnonymousIMAPProtocol.unsubscribe(IMAPFolder.this.fullName);
          }
        }
      });
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  void waitIfIdle()
    throws ProtocolException
  {
    if ((!$assertionsDisabled) && (!Thread.holdsLock(this.messageCacheLock))) {
      throw new AssertionError();
    }
    for (;;)
    {
      if (this.idleState == 1)
      {
        this.protocol.idleAbort();
        this.idleState = 2;
      }
      try
      {
        this.messageCacheLock.wait();
        label51:
        if (this.idleState != 0) {
          continue;
        }
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        break label51;
      }
    }
  }
  
  public static class FetchProfileItem
    extends FetchProfile.Item
  {
    public static final FetchProfileItem HEADERS = new FetchProfileItem("HEADERS");
    public static final FetchProfileItem SIZE = new FetchProfileItem("SIZE");
    
    protected FetchProfileItem(String paramString)
    {
      super();
    }
  }
  
  public static abstract interface ProtocolCommand
  {
    public abstract Object doCommand(IMAPProtocol paramIMAPProtocol)
      throws ProtocolException;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.IMAPFolder
 * JD-Core Version:    0.7.0.1
 */