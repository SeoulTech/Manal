package com.sun.mail.imap;

public abstract interface Utility$Condition
{
  public abstract boolean test(IMAPMessage paramIMAPMessage);
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.Utility.Condition
 * JD-Core Version:    0.7.0.1
 */