package com.sun.mail.imap;

import com.sun.mail.imap.protocol.ListInfo;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.MethodNotSupportedException;

public class DefaultFolder
  extends IMAPFolder
{
  protected DefaultFolder(IMAPStore paramIMAPStore)
  {
    super("", 65535, paramIMAPStore);
    this.exists = true;
    this.type = 2;
  }
  
  public void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot append to Default Folder");
  }
  
  public boolean delete(boolean paramBoolean)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot delete Default Folder");
  }
  
  public Message[] expunge()
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot expunge Default Folder");
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    return new IMAPFolder(paramString, 65535, (IMAPStore)this.store);
  }
  
  public String getName()
  {
    return this.fullName;
  }
  
  public Folder getParent()
  {
    return null;
  }
  
  public boolean hasNewMessages()
    throws MessagingException
  {
    return false;
  }
  
  public Folder[] list(String paramString)
    throws MessagingException
  {
    ((ListInfo[])null);
    ListInfo[] arrayOfListInfo = (ListInfo[])doCommand(new DefaultFolder.1(this, paramString));
    Object localObject;
    if (arrayOfListInfo == null) {
      localObject = new Folder[0];
    }
    for (;;)
    {
      return localObject;
      localObject = new IMAPFolder[arrayOfListInfo.length];
      for (int i = 0; i < localObject.length; i++) {
        localObject[i] = new IMAPFolder(arrayOfListInfo[i], (IMAPStore)this.store);
      }
    }
  }
  
  public Folder[] listSubscribed(String paramString)
    throws MessagingException
  {
    ((ListInfo[])null);
    ListInfo[] arrayOfListInfo = (ListInfo[])doCommand(new DefaultFolder.2(this, paramString));
    Object localObject;
    if (arrayOfListInfo == null) {
      localObject = new Folder[0];
    }
    for (;;)
    {
      return localObject;
      localObject = new IMAPFolder[arrayOfListInfo.length];
      for (int i = 0; i < localObject.length; i++) {
        localObject[i] = new IMAPFolder(arrayOfListInfo[i], (IMAPStore)this.store);
      }
    }
  }
  
  public boolean renameTo(Folder paramFolder)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot rename Default Folder");
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.DefaultFolder
 * JD-Core Version:    0.7.0.1
 */