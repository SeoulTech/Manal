package com.sun.mail.iap;

public class BadCommandException
  extends ProtocolException
{
  private static final long serialVersionUID = 5769722539397237515L;
  
  public BadCommandException() {}
  
  public BadCommandException(Response paramResponse)
  {
    super(paramResponse);
  }
  
  public BadCommandException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.BadCommandException
 * JD-Core Version:    0.7.0.1
 */