package com.sun.mail.iap;

public class CommandFailedException
  extends ProtocolException
{
  private static final long serialVersionUID = 793932807880443631L;
  
  public CommandFailedException() {}
  
  public CommandFailedException(Response paramResponse)
  {
    super(paramResponse);
  }
  
  public CommandFailedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.CommandFailedException
 * JD-Core Version:    0.7.0.1
 */