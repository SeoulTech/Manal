package com.sun.mail.imap;

import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.IMAPProtocol;

class DefaultFolder$1
  implements IMAPFolder.ProtocolCommand
{
  DefaultFolder$1(DefaultFolder paramDefaultFolder, String paramString) {}
  
  public Object doCommand(IMAPProtocol paramIMAPProtocol)
    throws ProtocolException
  {
    return paramIMAPProtocol.list("", this.val$pattern);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.imap.DefaultFolder.1
 * JD-Core Version:    0.7.0.1
 */