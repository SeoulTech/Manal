package com.sun.mail.iap;

class Atom
{
  String string;
  
  Atom(String paramString)
  {
    this.string = paramString;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.Atom
 * JD-Core Version:    0.7.0.1
 */