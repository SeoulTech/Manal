package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import myjava.awt.datatransfer.DataFlavor;

public class message_rfc822
  implements DataContentHandler
{
  ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(Message.class, "message/rfc822", "Message");
  
  /* Error */
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: instanceof 33
    //   4: ifeq +33 -> 37
    //   7: aload_1
    //   8: checkcast 33	javax/mail/MessageAware
    //   11: invokeinterface 37 1 0
    //   16: invokevirtual 43	javax/mail/MessageContext:getSession	()Ljavax/mail/Session;
    //   19: astore 4
    //   21: new 45	javax/mail/internet/MimeMessage
    //   24: dup
    //   25: aload 4
    //   27: aload_1
    //   28: invokeinterface 51 1 0
    //   33: invokespecial 54	javax/mail/internet/MimeMessage:<init>	(Ljavax/mail/Session;Ljava/io/InputStream;)V
    //   36: areturn
    //   37: new 56	java/util/Properties
    //   40: dup
    //   41: invokespecial 57	java/util/Properties:<init>	()V
    //   44: aconst_null
    //   45: invokestatic 63	javax/mail/Session:getDefaultInstance	(Ljava/util/Properties;Ljavax/mail/Authenticator;)Ljavax/mail/Session;
    //   48: astore_3
    //   49: aload_3
    //   50: astore 4
    //   52: goto -31 -> 21
    //   55: astore_2
    //   56: new 29	java/io/IOException
    //   59: dup
    //   60: new 65	java/lang/StringBuilder
    //   63: dup
    //   64: ldc 67
    //   66: invokespecial 70	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   69: aload_2
    //   70: invokevirtual 74	javax/mail/MessagingException:toString	()Ljava/lang/String;
    //   73: invokevirtual 78	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokevirtual 79	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   79: invokespecial 80	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   82: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	83	0	this	message_rfc822
    //   0	83	1	paramDataSource	DataSource
    //   55	15	2	localMessagingException	MessagingException
    //   48	2	3	localSession	javax.mail.Session
    //   19	32	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	49	55	javax/mail/MessagingException
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.ourDataFlavor.equals(paramDataFlavor)) {}
    for (Object localObject = getContent(paramDataSource);; localObject = null) {
      return localObject;
    }
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    DataFlavor[] arrayOfDataFlavor = new DataFlavor[1];
    arrayOfDataFlavor[0] = this.ourDataFlavor;
    return arrayOfDataFlavor;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof Message))
    {
      Message localMessage = (Message)paramObject;
      try
      {
        localMessage.writeTo(paramOutputStream);
        return;
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.toString());
      }
    }
    throw new IOException("unsupported object");
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.handlers.message_rfc822
 * JD-Core Version:    0.7.0.1
 */