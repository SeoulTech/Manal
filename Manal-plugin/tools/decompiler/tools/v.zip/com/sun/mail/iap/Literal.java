package com.sun.mail.iap;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface Literal
{
  public abstract int size();
  
  public abstract void writeTo(OutputStream paramOutputStream)
    throws IOException;
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.Literal
 * JD-Core Version:    0.7.0.1
 */