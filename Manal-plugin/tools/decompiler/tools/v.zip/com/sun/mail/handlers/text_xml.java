package com.sun.mail.handlers;

import javax.activation.ActivationDataFlavor;

public class text_xml
  extends text_plain
{
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/xml", "XML String");
  
  protected ActivationDataFlavor getDF()
  {
    return myDF;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.handlers.text_xml
 * JD-Core Version:    0.7.0.1
 */