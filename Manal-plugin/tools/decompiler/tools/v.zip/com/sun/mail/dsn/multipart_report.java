package com.sun.mail.dsn;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import myjava.awt.datatransfer.DataFlavor;

public class multipart_report
  implements DataContentHandler
{
  private ActivationDataFlavor myDF = new ActivationDataFlavor(MultipartReport.class, "multipart/report", "Multipart Report");
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      MultipartReport localMultipartReport = new MultipartReport(paramDataSource);
      return localMultipartReport;
    }
    catch (MessagingException localMessagingException)
    {
      IOException localIOException = new IOException("Exception while constructing MultipartReport");
      localIOException.initCause(localMessagingException);
      throw localIOException;
    }
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.myDF.equals(paramDataFlavor)) {}
    for (Object localObject = getContent(paramDataSource);; localObject = null) {
      return localObject;
    }
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    DataFlavor[] arrayOfDataFlavor = new DataFlavor[1];
    arrayOfDataFlavor[0] = this.myDF;
    return arrayOfDataFlavor;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MultipartReport)) {}
    try
    {
      ((MultipartReport)paramObject).writeTo(paramOutputStream);
      return;
    }
    catch (MessagingException localMessagingException)
    {
      throw new IOException(localMessagingException.toString());
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.dsn.multipart_report
 * JD-Core Version:    0.7.0.1
 */