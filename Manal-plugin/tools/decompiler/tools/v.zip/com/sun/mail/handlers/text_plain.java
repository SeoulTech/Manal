package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;
import myjava.awt.datatransfer.DataFlavor;

public class text_plain
  implements DataContentHandler
{
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/plain", "Text String");
  
  private String getCharset(String paramString)
  {
    try
    {
      String str2 = new ContentType(paramString).getParameter("charset");
      if (str2 == null) {
        str2 = "us-ascii";
      }
      String str3 = MimeUtility.javaCharset(str2);
      str1 = str3;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        String str1 = null;
      }
    }
    return str1;
  }
  
  /* Error */
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: aload_1
    //   4: invokeinterface 59 1 0
    //   9: invokespecial 61	com/sun/mail/handlers/text_plain:getCharset	(Ljava/lang/String;)Ljava/lang/String;
    //   12: astore_2
    //   13: new 63	java/io/InputStreamReader
    //   16: dup
    //   17: aload_1
    //   18: invokeinterface 67 1 0
    //   23: aload_2
    //   24: invokespecial 70	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   27: astore 4
    //   29: iconst_0
    //   30: istore 5
    //   32: sipush 1024
    //   35: newarray char
    //   37: astore 8
    //   39: aload 4
    //   41: aload 8
    //   43: iload 5
    //   45: aload 8
    //   47: arraylength
    //   48: iload 5
    //   50: isub
    //   51: invokevirtual 74	java/io/InputStreamReader:read	([CII)I
    //   54: istore 9
    //   56: iload 9
    //   58: bipush 255
    //   60: if_icmpne +35 -> 95
    //   63: new 14	java/lang/String
    //   66: dup
    //   67: aload 8
    //   69: iconst_0
    //   70: iload 5
    //   72: invokespecial 77	java/lang/String:<init>	([CII)V
    //   75: astore 10
    //   77: aload 4
    //   79: invokevirtual 80	java/io/InputStreamReader:close	()V
    //   82: aload 10
    //   84: areturn
    //   85: astore_3
    //   86: new 82	java/io/UnsupportedEncodingException
    //   89: dup
    //   90: aload_2
    //   91: invokespecial 83	java/io/UnsupportedEncodingException:<init>	(Ljava/lang/String;)V
    //   94: athrow
    //   95: iload 5
    //   97: iload 9
    //   99: iadd
    //   100: istore 5
    //   102: iload 5
    //   104: aload 8
    //   106: arraylength
    //   107: if_icmplt -68 -> 39
    //   110: aload 8
    //   112: arraylength
    //   113: istore 12
    //   115: iload 12
    //   117: ldc 84
    //   119: if_icmpge +34 -> 153
    //   122: iload 12
    //   124: iload 12
    //   126: iadd
    //   127: istore 13
    //   129: iload 13
    //   131: newarray char
    //   133: astore 14
    //   135: aload 8
    //   137: iconst_0
    //   138: aload 14
    //   140: iconst_0
    //   141: iload 5
    //   143: invokestatic 90	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   146: aload 14
    //   148: astore 8
    //   150: goto -111 -> 39
    //   153: iload 12
    //   155: ldc 84
    //   157: iadd
    //   158: istore 13
    //   160: goto -31 -> 129
    //   163: astore 6
    //   165: aload 4
    //   167: invokevirtual 80	java/io/InputStreamReader:close	()V
    //   170: aload 6
    //   172: athrow
    //   173: astore 11
    //   175: goto -93 -> 82
    //   178: astore 7
    //   180: goto -10 -> 170
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	183	0	this	text_plain
    //   0	183	1	paramDataSource	DataSource
    //   1	90	2	str1	String
    //   85	1	3	localIllegalArgumentException	IllegalArgumentException
    //   27	139	4	localInputStreamReader	java.io.InputStreamReader
    //   30	112	5	i	int
    //   163	8	6	localObject1	Object
    //   178	1	7	localIOException1	IOException
    //   37	112	8	localObject2	Object
    //   54	46	9	j	int
    //   75	8	10	str2	String
    //   173	1	11	localIOException2	IOException
    //   113	45	12	k	int
    //   127	32	13	m	int
    //   133	14	14	arrayOfChar	char[]
    // Exception table:
    //   from	to	target	type
    //   2	29	85	java/lang/IllegalArgumentException
    //   32	77	163	finally
    //   102	146	163	finally
    //   77	82	173	java/io/IOException
    //   165	170	178	java/io/IOException
  }
  
  protected ActivationDataFlavor getDF()
  {
    return myDF;
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (getDF().equals(paramDataFlavor)) {}
    for (Object localObject = getContent(paramDataSource);; localObject = null) {
      return localObject;
    }
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    DataFlavor[] arrayOfDataFlavor = new DataFlavor[1];
    arrayOfDataFlavor[0] = getDF();
    return arrayOfDataFlavor;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if (!(paramObject instanceof String)) {
      throw new IOException("\"" + getDF().getMimeType() + "\" DataContentHandler requires String object, " + "was given object of type " + paramObject.getClass().toString());
    }
    String str1 = null;
    try
    {
      str1 = getCharset(paramString);
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(paramOutputStream, str1);
      String str2 = (String)paramObject;
      localOutputStreamWriter.write(str2, 0, str2.length());
      localOutputStreamWriter.flush();
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new UnsupportedEncodingException(str1);
    }
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.handlers.text_plain
 * JD-Core Version:    0.7.0.1
 */