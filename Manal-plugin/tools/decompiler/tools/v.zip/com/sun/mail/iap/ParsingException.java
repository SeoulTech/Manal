package com.sun.mail.iap;

public class ParsingException
  extends ProtocolException
{
  private static final long serialVersionUID = 7756119840142724839L;
  
  public ParsingException() {}
  
  public ParsingException(Response paramResponse)
  {
    super(paramResponse);
  }
  
  public ParsingException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     com.sun.mail.iap.ParsingException
 * JD-Core Version:    0.7.0.1
 */