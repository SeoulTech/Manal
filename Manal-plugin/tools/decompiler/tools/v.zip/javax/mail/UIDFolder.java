package javax.mail;

public abstract interface UIDFolder
{
  public static final long LASTUID = -1L;
  
  public abstract Message getMessageByUID(long paramLong)
    throws MessagingException;
  
  public abstract Message[] getMessagesByUID(long paramLong1, long paramLong2)
    throws MessagingException;
  
  public abstract Message[] getMessagesByUID(long[] paramArrayOfLong)
    throws MessagingException;
  
  public abstract long getUID(Message paramMessage)
    throws MessagingException;
  
  public abstract long getUIDValidity()
    throws MessagingException;
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.UIDFolder
 * JD-Core Version:    0.7.0.1
 */