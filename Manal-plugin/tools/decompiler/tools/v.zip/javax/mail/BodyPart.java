package javax.mail;

public abstract class BodyPart
  implements Part
{
  protected Multipart parent;
  
  public Multipart getParent()
  {
    return this.parent;
  }
  
  void setParent(Multipart paramMultipart)
  {
    this.parent = paramMultipart;
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.BodyPart
 * JD-Core Version:    0.7.0.1
 */