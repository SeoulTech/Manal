package javax.mail;

import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.MessageChangedEvent;
import javax.mail.event.MessageChangedListener;
import javax.mail.event.MessageCountEvent;
import javax.mail.event.MessageCountListener;
import javax.mail.search.SearchTerm;

public abstract class Folder
{
  public static final int HOLDS_FOLDERS = 2;
  public static final int HOLDS_MESSAGES = 1;
  public static final int READ_ONLY = 1;
  public static final int READ_WRITE = 2;
  private volatile Vector connectionListeners = null;
  private volatile Vector folderListeners = null;
  private volatile Vector messageChangedListeners = null;
  private volatile Vector messageCountListeners = null;
  protected int mode = -1;
  private EventQueue q;
  private Object qLock = new Object();
  protected Store store;
  
  protected Folder(Store paramStore)
  {
    this.store = paramStore;
  }
  
  private void queueEvent(MailEvent paramMailEvent, Vector paramVector)
  {
    synchronized (this.qLock)
    {
      if (this.q == null) {
        this.q = new EventQueue();
      }
      Vector localVector = (Vector)paramVector.clone();
      this.q.enqueue(paramMailEvent, localVector);
      return;
    }
  }
  
  private void terminateQueue()
  {
    synchronized (this.qLock)
    {
      if (this.q != null)
      {
        Vector localVector = new Vector();
        localVector.setSize(1);
        this.q.enqueue(new Folder.TerminatorEvent(), localVector);
        this.q = null;
      }
      return;
    }
  }
  
  public void addConnectionListener(ConnectionListener paramConnectionListener)
  {
    try
    {
      if (this.connectionListeners == null) {
        this.connectionListeners = new Vector();
      }
      this.connectionListeners.addElement(paramConnectionListener);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addFolderListener(FolderListener paramFolderListener)
  {
    try
    {
      if (this.folderListeners == null) {
        this.folderListeners = new Vector();
      }
      this.folderListeners.addElement(paramFolderListener);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addMessageChangedListener(MessageChangedListener paramMessageChangedListener)
  {
    try
    {
      if (this.messageChangedListeners == null) {
        this.messageChangedListeners = new Vector();
      }
      this.messageChangedListeners.addElement(paramMessageChangedListener);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addMessageCountListener(MessageCountListener paramMessageCountListener)
  {
    try
    {
      if (this.messageCountListeners == null) {
        this.messageCountListeners = new Vector();
      }
      this.messageCountListeners.addElement(paramMessageCountListener);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public abstract void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException;
  
  public abstract void close(boolean paramBoolean)
    throws MessagingException;
  
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder)
    throws MessagingException
  {
    if (!paramFolder.exists()) {
      throw new FolderNotFoundException(paramFolder.getFullName() + " does not exist", paramFolder);
    }
    paramFolder.appendMessages(paramArrayOfMessage);
  }
  
  public abstract boolean create(int paramInt)
    throws MessagingException;
  
  public abstract boolean delete(boolean paramBoolean)
    throws MessagingException;
  
  public abstract boolean exists()
    throws MessagingException;
  
  public abstract Message[] expunge()
    throws MessagingException;
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile)
    throws MessagingException
  {}
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    terminateQueue();
  }
  
  public int getDeletedMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      int i;
      int k;
      boolean bool2;
      try
      {
        boolean bool1 = isOpen();
        if (!bool1)
        {
          i = -1;
          return i;
        }
        i = 0;
        int j = getMessageCount();
        k = 1;
        if (k > j) {
          continue;
        }
      }
      finally {}
      try
      {
        bool2 = getMessage(k).isSet(Flags.Flag.DELETED);
        if (bool2) {
          i++;
        }
        k++;
      }
      catch (MessageRemovedException localMessageRemovedException) {}
    }
  }
  
  public abstract Folder getFolder(String paramString)
    throws MessagingException;
  
  public abstract String getFullName();
  
  public abstract Message getMessage(int paramInt)
    throws MessagingException;
  
  public abstract int getMessageCount()
    throws MessagingException;
  
  public Message[] getMessages()
    throws MessagingException
  {
    try
    {
      if (!isOpen()) {
        throw new IllegalStateException("Folder not open");
      }
    }
    finally {}
    int i = getMessageCount();
    Message[] arrayOfMessage = new Message[i];
    for (int j = 1;; j++)
    {
      if (j > i) {
        return arrayOfMessage;
      }
      int k = j - 1;
      arrayOfMessage[k] = getMessage(j);
    }
  }
  
  /* Error */
  public Message[] getMessages(int paramInt1, int paramInt2)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_1
    //   3: iload_2
    //   4: iload_1
    //   5: isub
    //   6: iadd
    //   7: istore_3
    //   8: iload_3
    //   9: anewarray 160	javax/mail/Message
    //   12: astore 5
    //   14: iload_1
    //   15: istore 6
    //   17: iload 6
    //   19: iload_2
    //   20: if_icmple +8 -> 28
    //   23: aload_0
    //   24: monitorexit
    //   25: aload 5
    //   27: areturn
    //   28: iload 6
    //   30: iload_1
    //   31: isub
    //   32: istore 7
    //   34: aload 5
    //   36: iload 7
    //   38: aload_0
    //   39: iload 6
    //   41: invokevirtual 152	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   44: aastore
    //   45: iinc 6 1
    //   48: goto -31 -> 17
    //   51: astore 4
    //   53: aload_0
    //   54: monitorexit
    //   55: aload 4
    //   57: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	58	0	this	Folder
    //   0	58	1	paramInt1	int
    //   0	58	2	paramInt2	int
    //   7	2	3	i	int
    //   51	5	4	localObject	Object
    //   12	23	5	arrayOfMessage	Message[]
    //   15	31	6	j	int
    //   32	5	7	k	int
    // Exception table:
    //   from	to	target	type
    //   8	14	51	finally
    //   34	45	51	finally
  }
  
  /* Error */
  public Message[] getMessages(int[] paramArrayOfInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: arraylength
    //   4: istore_3
    //   5: iload_3
    //   6: anewarray 160	javax/mail/Message
    //   9: astore 4
    //   11: iconst_0
    //   12: istore 5
    //   14: iload 5
    //   16: iload_3
    //   17: if_icmplt +8 -> 25
    //   20: aload_0
    //   21: monitorexit
    //   22: aload 4
    //   24: areturn
    //   25: aload 4
    //   27: iload 5
    //   29: aload_0
    //   30: aload_1
    //   31: iload 5
    //   33: iaload
    //   34: invokevirtual 152	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   37: aastore
    //   38: iinc 5 1
    //   41: goto -27 -> 14
    //   44: astore_2
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_2
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	Folder
    //   0	49	1	paramArrayOfInt	int[]
    //   44	4	2	localObject	Object
    //   4	14	3	i	int
    //   9	17	4	arrayOfMessage	Message[]
    //   12	27	5	j	int
    // Exception table:
    //   from	to	target	type
    //   2	11	44	finally
    //   25	38	44	finally
  }
  
  public int getMode()
  {
    if (!isOpen()) {
      throw new IllegalStateException("Folder not open");
    }
    return this.mode;
  }
  
  public abstract String getName();
  
  public int getNewMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      int i;
      int k;
      boolean bool2;
      try
      {
        boolean bool1 = isOpen();
        if (!bool1)
        {
          i = -1;
          return i;
        }
        i = 0;
        int j = getMessageCount();
        k = 1;
        if (k > j) {
          continue;
        }
      }
      finally {}
      try
      {
        bool2 = getMessage(k).isSet(Flags.Flag.RECENT);
        if (bool2) {
          i++;
        }
        k++;
      }
      catch (MessageRemovedException localMessageRemovedException) {}
    }
  }
  
  public abstract Folder getParent()
    throws MessagingException;
  
  public abstract Flags getPermanentFlags();
  
  public abstract char getSeparator()
    throws MessagingException;
  
  public Store getStore()
  {
    return this.store;
  }
  
  public abstract int getType()
    throws MessagingException;
  
  public URLName getURLName()
    throws MessagingException
  {
    URLName localURLName = getStore().getURLName();
    String str = getFullName();
    StringBuffer localStringBuffer = new StringBuffer();
    getSeparator();
    if (str != null) {
      localStringBuffer.append(str);
    }
    return new URLName(localURLName.getProtocol(), localURLName.getHost(), localURLName.getPort(), localStringBuffer.toString(), localURLName.getUsername(), null);
  }
  
  public int getUnreadMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      int i;
      int k;
      boolean bool2;
      try
      {
        boolean bool1 = isOpen();
        if (!bool1)
        {
          i = -1;
          return i;
        }
        i = 0;
        int j = getMessageCount();
        k = 1;
        if (k > j) {
          continue;
        }
      }
      finally {}
      try
      {
        bool2 = getMessage(k).isSet(Flags.Flag.SEEN);
        if (!bool2) {
          i++;
        }
        k++;
      }
      catch (MessageRemovedException localMessageRemovedException) {}
    }
  }
  
  public abstract boolean hasNewMessages()
    throws MessagingException;
  
  public abstract boolean isOpen();
  
  public boolean isSubscribed()
  {
    return true;
  }
  
  public Folder[] list()
    throws MessagingException
  {
    return list("%");
  }
  
  public abstract Folder[] list(String paramString)
    throws MessagingException;
  
  public Folder[] listSubscribed()
    throws MessagingException
  {
    return listSubscribed("%");
  }
  
  public Folder[] listSubscribed(String paramString)
    throws MessagingException
  {
    return list(paramString);
  }
  
  protected void notifyConnectionListeners(int paramInt)
  {
    if (this.connectionListeners != null) {
      queueEvent(new ConnectionEvent(this, paramInt), this.connectionListeners);
    }
    if (paramInt == 3) {
      terminateQueue();
    }
  }
  
  protected void notifyFolderListeners(int paramInt)
  {
    if (this.folderListeners != null) {
      queueEvent(new FolderEvent(this, this, paramInt), this.folderListeners);
    }
    this.store.notifyFolderListeners(paramInt, this);
  }
  
  protected void notifyFolderRenamedListeners(Folder paramFolder)
  {
    if (this.folderListeners != null) {
      queueEvent(new FolderEvent(this, this, paramFolder, 3), this.folderListeners);
    }
    this.store.notifyFolderRenamedListeners(this, paramFolder);
  }
  
  protected void notifyMessageAddedListeners(Message[] paramArrayOfMessage)
  {
    if (this.messageCountListeners == null) {}
    for (;;)
    {
      return;
      queueEvent(new MessageCountEvent(this, 1, false, paramArrayOfMessage), this.messageCountListeners);
    }
  }
  
  protected void notifyMessageChangedListeners(int paramInt, Message paramMessage)
  {
    if (this.messageChangedListeners == null) {}
    for (;;)
    {
      return;
      queueEvent(new MessageChangedEvent(this, paramInt, paramMessage), this.messageChangedListeners);
    }
  }
  
  protected void notifyMessageRemovedListeners(boolean paramBoolean, Message[] paramArrayOfMessage)
  {
    if (this.messageCountListeners == null) {}
    for (;;)
    {
      return;
      queueEvent(new MessageCountEvent(this, 2, paramBoolean, paramArrayOfMessage), this.messageCountListeners);
    }
  }
  
  public abstract void open(int paramInt)
    throws MessagingException;
  
  public void removeConnectionListener(ConnectionListener paramConnectionListener)
  {
    try
    {
      if (this.connectionListeners != null) {
        this.connectionListeners.removeElement(paramConnectionListener);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeFolderListener(FolderListener paramFolderListener)
  {
    try
    {
      if (this.folderListeners != null) {
        this.folderListeners.removeElement(paramFolderListener);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeMessageChangedListener(MessageChangedListener paramMessageChangedListener)
  {
    try
    {
      if (this.messageChangedListeners != null) {
        this.messageChangedListeners.removeElement(paramMessageChangedListener);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeMessageCountListener(MessageCountListener paramMessageCountListener)
  {
    try
    {
      if (this.messageCountListeners != null) {
        this.messageCountListeners.removeElement(paramMessageCountListener);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public abstract boolean renameTo(Folder paramFolder)
    throws MessagingException;
  
  public Message[] search(SearchTerm paramSearchTerm)
    throws MessagingException
  {
    return search(paramSearchTerm, getMessages());
  }
  
  public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage)
    throws MessagingException
  {
    Vector localVector = new Vector();
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfMessage.length)
      {
        Message[] arrayOfMessage = new Message[localVector.size()];
        localVector.copyInto(arrayOfMessage);
        return arrayOfMessage;
      }
      try
      {
        if (paramArrayOfMessage[i].match(paramSearchTerm)) {
          localVector.addElement(paramArrayOfMessage[i]);
        }
        label55:
        i++;
      }
      catch (MessageRemovedException localMessageRemovedException)
      {
        break label55;
      }
    }
  }
  
  /* Error */
  public void setFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: istore 5
    //   5: iload 5
    //   7: iload_2
    //   8: if_icmple +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: iload 5
    //   17: invokevirtual 152	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   20: aload_3
    //   21: iload 4
    //   23: invokevirtual 313	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   26: iinc 5 1
    //   29: goto -24 -> 5
    //   32: astore 7
    //   34: aload_0
    //   35: monitorexit
    //   36: aload 7
    //   38: athrow
    //   39: astore 6
    //   41: goto -15 -> 26
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	44	0	this	Folder
    //   0	44	1	paramInt1	int
    //   0	44	2	paramInt2	int
    //   0	44	3	paramFlags	Flags
    //   0	44	4	paramBoolean	boolean
    //   3	24	5	i	int
    //   39	1	6	localMessageRemovedException	MessageRemovedException
    //   32	5	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   14	26	32	finally
    //   14	26	39	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public void setFlags(int[] paramArrayOfInt, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore 4
    //   5: aload_1
    //   6: arraylength
    //   7: istore 6
    //   9: iload 4
    //   11: iload 6
    //   13: if_icmplt +6 -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: aload_1
    //   21: iload 4
    //   23: iaload
    //   24: invokevirtual 152	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   27: aload_2
    //   28: iload_3
    //   29: invokevirtual 313	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   32: iinc 4 1
    //   35: goto -30 -> 5
    //   38: astore 5
    //   40: aload_0
    //   41: monitorexit
    //   42: aload 5
    //   44: athrow
    //   45: astore 7
    //   47: goto -15 -> 32
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	50	0	this	Folder
    //   0	50	1	paramArrayOfInt	int[]
    //   0	50	2	paramFlags	Flags
    //   0	50	3	paramBoolean	boolean
    //   3	30	4	i	int
    //   38	5	5	localObject	Object
    //   7	7	6	j	int
    //   45	1	7	localMessageRemovedException	MessageRemovedException
    // Exception table:
    //   from	to	target	type
    //   5	9	38	finally
    //   19	32	38	finally
    //   19	32	45	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore 4
    //   5: aload_1
    //   6: arraylength
    //   7: istore 6
    //   9: iload 4
    //   11: iload 6
    //   13: if_icmplt +6 -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_1
    //   20: iload 4
    //   22: aaload
    //   23: aload_2
    //   24: iload_3
    //   25: invokevirtual 313	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   28: iinc 4 1
    //   31: goto -26 -> 5
    //   34: astore 5
    //   36: aload_0
    //   37: monitorexit
    //   38: aload 5
    //   40: athrow
    //   41: astore 7
    //   43: goto -15 -> 28
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	46	0	this	Folder
    //   0	46	1	paramArrayOfMessage	Message[]
    //   0	46	2	paramFlags	Flags
    //   0	46	3	paramBoolean	boolean
    //   3	26	4	i	int
    //   34	5	5	localObject	Object
    //   7	7	6	j	int
    //   41	1	7	localMessageRemovedException	MessageRemovedException
    // Exception table:
    //   from	to	target	type
    //   5	9	34	finally
    //   19	28	34	finally
    //   19	28	41	javax/mail/MessageRemovedException
  }
  
  public void setSubscribed(boolean paramBoolean)
    throws MessagingException
  {
    throw new MethodNotSupportedException();
  }
  
  public String toString()
  {
    String str = getFullName();
    if (str != null) {}
    for (;;)
    {
      return str;
      str = super.toString();
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.Folder
 * JD-Core Version:    0.7.0.1
 */