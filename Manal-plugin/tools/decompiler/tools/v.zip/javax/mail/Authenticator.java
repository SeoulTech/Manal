package javax.mail;

import java.net.InetAddress;

public abstract class Authenticator
{
  private int requestingPort;
  private String requestingPrompt;
  private String requestingProtocol;
  private InetAddress requestingSite;
  private String requestingUserName;
  
  private void reset()
  {
    this.requestingSite = null;
    this.requestingPort = -1;
    this.requestingProtocol = null;
    this.requestingPrompt = null;
    this.requestingUserName = null;
  }
  
  protected final String getDefaultUserName()
  {
    return this.requestingUserName;
  }
  
  protected PasswordAuthentication getPasswordAuthentication()
  {
    return null;
  }
  
  protected final int getRequestingPort()
  {
    return this.requestingPort;
  }
  
  protected final String getRequestingPrompt()
  {
    return this.requestingPrompt;
  }
  
  protected final String getRequestingProtocol()
  {
    return this.requestingProtocol;
  }
  
  protected final InetAddress getRequestingSite()
  {
    return this.requestingSite;
  }
  
  final PasswordAuthentication requestPasswordAuthentication(InetAddress paramInetAddress, int paramInt, String paramString1, String paramString2, String paramString3)
  {
    reset();
    this.requestingSite = paramInetAddress;
    this.requestingPort = paramInt;
    this.requestingProtocol = paramString1;
    this.requestingPrompt = paramString2;
    this.requestingUserName = paramString3;
    return getPasswordAuthentication();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.Authenticator
 * JD-Core Version:    0.7.0.1
 */