package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.FolderClosedIOException;
import com.sun.mail.util.LineOutputStream;
import com.sun.mail.util.MessageRemovedIOException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.FolderClosedException;
import javax.mail.Message;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Multipart;

public class MimeBodyPart
  extends BodyPart
  implements MimePart
{
  static boolean cacheMultipart = true;
  private static boolean decodeFileName;
  private static boolean encodeFileName;
  private static boolean setContentTypeFileName;
  private static boolean setDefaultTextCharset;
  private Object cachedContent;
  protected byte[] content;
  protected InputStream contentStream;
  protected DataHandler dh;
  protected InternetHeaders headers;
  
  static
  {
    boolean bool1 = false;
    setDefaultTextCharset = true;
    setContentTypeFileName = true;
    encodeFileName = false;
    decodeFileName = false;
    try
    {
      String str1 = System.getProperty("mail.mime.setdefaulttextcharset");
      boolean bool2;
      boolean bool3;
      label72:
      boolean bool4;
      label102:
      boolean bool5;
      if ((str1 != null) && (str1.equalsIgnoreCase("false")))
      {
        bool2 = false;
        setDefaultTextCharset = bool2;
        String str2 = System.getProperty("mail.mime.setcontenttypefilename");
        if ((str2 == null) || (!str2.equalsIgnoreCase("false"))) {
          break label169;
        }
        bool3 = false;
        setContentTypeFileName = bool3;
        String str3 = System.getProperty("mail.mime.encodefilename");
        if ((str3 == null) || (str3.equalsIgnoreCase("false"))) {
          break label175;
        }
        bool4 = true;
        encodeFileName = bool4;
        String str4 = System.getProperty("mail.mime.decodefilename");
        if ((str4 == null) || (str4.equalsIgnoreCase("false"))) {
          break label181;
        }
        bool5 = true;
        label132:
        decodeFileName = bool5;
        String str5 = System.getProperty("mail.mime.cachemultipart");
        if ((str5 == null) || (!str5.equalsIgnoreCase("false"))) {
          break label187;
        }
      }
      for (;;)
      {
        cacheMultipart = bool1;
        label163:
        return;
        bool2 = true;
        break;
        label169:
        bool3 = true;
        break label72;
        label175:
        bool4 = false;
        break label102;
        label181:
        bool5 = false;
        break label132;
        label187:
        bool1 = true;
      }
    }
    catch (SecurityException localSecurityException)
    {
      break label163;
    }
  }
  
  public MimeBodyPart()
  {
    this.headers = new InternetHeaders();
  }
  
  public MimeBodyPart(InputStream paramInputStream)
    throws MessagingException
  {
    if ((!(paramInputStream instanceof ByteArrayInputStream)) && (!(paramInputStream instanceof BufferedInputStream)) && (!(paramInputStream instanceof SharedInputStream))) {
      paramInputStream = new BufferedInputStream(paramInputStream);
    }
    this.headers = new InternetHeaders(paramInputStream);
    if ((paramInputStream instanceof SharedInputStream))
    {
      SharedInputStream localSharedInputStream = (SharedInputStream)paramInputStream;
      this.contentStream = localSharedInputStream.newStream(localSharedInputStream.getPosition(), -1L);
    }
    for (;;)
    {
      return;
      try
      {
        this.content = ASCIIUtility.getBytes(paramInputStream);
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("Error reading input stream", localIOException);
      }
    }
  }
  
  public MimeBodyPart(InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte)
    throws MessagingException
  {
    this.headers = paramInternetHeaders;
    this.content = paramArrayOfByte;
  }
  
  static String[] getContentLanguage(MimePart paramMimePart)
    throws MessagingException
  {
    String[] arrayOfString = null;
    String str = paramMimePart.getHeader("Content-Language", null);
    if (str == null) {
      return arrayOfString;
    }
    HeaderTokenizer localHeaderTokenizer = new HeaderTokenizer(str, "()<>@,;:\\\"\t []/?=");
    Vector localVector = new Vector();
    for (;;)
    {
      HeaderTokenizer.Token localToken = localHeaderTokenizer.next();
      int i = localToken.getType();
      if (i == -4)
      {
        if (localVector.size() == 0) {
          break;
        }
        arrayOfString = new String[localVector.size()];
        localVector.copyInto(arrayOfString);
        break;
      }
      if (i == -1) {
        localVector.addElement(localToken.getValue());
      }
    }
  }
  
  static String getDescription(MimePart paramMimePart)
    throws MessagingException
  {
    Object localObject = paramMimePart.getHeader("Content-Description", null);
    if (localObject == null) {
      localObject = null;
    }
    for (;;)
    {
      return localObject;
      try
      {
        String str = MimeUtility.decodeText(MimeUtility.unfold((String)localObject));
        localObject = str;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
    }
  }
  
  static String getDisposition(MimePart paramMimePart)
    throws MessagingException
  {
    String str1 = null;
    String str2 = paramMimePart.getHeader("Content-Disposition", null);
    if (str2 == null) {}
    for (;;)
    {
      return str1;
      str1 = new ContentDisposition(str2).getDisposition();
    }
  }
  
  static String getEncoding(MimePart paramMimePart)
    throws MessagingException
  {
    Object localObject = null;
    String str1 = paramMimePart.getHeader("Content-Transfer-Encoding", null);
    if (str1 == null) {}
    for (;;)
    {
      return localObject;
      String str2 = str1.trim();
      if ((str2.equalsIgnoreCase("7bit")) || (str2.equalsIgnoreCase("8bit")) || (str2.equalsIgnoreCase("quoted-printable")) || (str2.equalsIgnoreCase("binary")) || (str2.equalsIgnoreCase("base64")))
      {
        localObject = str2;
      }
      else
      {
        HeaderTokenizer localHeaderTokenizer = new HeaderTokenizer(str2, "()<>@,;:\\\"\t []/?=");
        HeaderTokenizer.Token localToken;
        int i;
        do
        {
          localToken = localHeaderTokenizer.next();
          i = localToken.getType();
          if (i == -4)
          {
            localObject = str2;
            break;
          }
        } while (i != -1);
        localObject = localToken.getValue();
      }
    }
  }
  
  static String getFileName(MimePart paramMimePart)
    throws MessagingException
  {
    Object localObject = null;
    String str1 = paramMimePart.getHeader("Content-Disposition", null);
    if (str1 != null) {
      localObject = new ContentDisposition(str1).getParameter("filename");
    }
    String str3;
    if (localObject == null)
    {
      str3 = paramMimePart.getHeader("Content-Type", null);
      if (str3 == null) {}
    }
    try
    {
      String str4 = new ContentType(str3).getParameter("name");
      localObject = str4;
    }
    catch (ParseException localParseException)
    {
      label69:
      break label69;
    }
    if ((decodeFileName) && (localObject != null)) {}
    try
    {
      String str2 = MimeUtility.decodeText((String)localObject);
      localObject = str2;
      return localObject;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new MessagingException("Can't decode filename", localUnsupportedEncodingException);
    }
  }
  
  static void invalidateContentHeaders(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart.removeHeader("Content-Type");
    paramMimePart.removeHeader("Content-Transfer-Encoding");
  }
  
  static boolean isMimeType(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    try
    {
      boolean bool2 = new ContentType(paramMimePart.getContentType()).match(paramString);
      bool1 = bool2;
    }
    catch (ParseException localParseException)
    {
      for (;;)
      {
        boolean bool1 = paramMimePart.getContentType().equalsIgnoreCase(paramString);
      }
    }
    return bool1;
  }
  
  static void setContentLanguage(MimePart paramMimePart, String[] paramArrayOfString)
    throws MessagingException
  {
    StringBuffer localStringBuffer = new StringBuffer(paramArrayOfString[0]);
    for (int i = 1;; i++)
    {
      if (i >= paramArrayOfString.length)
      {
        paramMimePart.setHeader("Content-Language", localStringBuffer.toString());
        return;
      }
      localStringBuffer.append(',').append(paramArrayOfString[i]);
    }
  }
  
  static void setDescription(MimePart paramMimePart, String paramString1, String paramString2)
    throws MessagingException
  {
    if (paramString1 == null) {
      paramMimePart.removeHeader("Content-Description");
    }
    for (;;)
    {
      return;
      try
      {
        paramMimePart.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(paramString1, paramString2, null)));
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        throw new MessagingException("Encoding error", localUnsupportedEncodingException);
      }
    }
  }
  
  static void setDisposition(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    if (paramString == null) {
      paramMimePart.removeHeader("Content-Disposition");
    }
    for (;;)
    {
      return;
      String str = paramMimePart.getHeader("Content-Disposition", null);
      if (str != null)
      {
        ContentDisposition localContentDisposition = new ContentDisposition(str);
        localContentDisposition.setDisposition(paramString);
        paramString = localContentDisposition.toString();
      }
      paramMimePart.setHeader("Content-Disposition", paramString);
    }
  }
  
  static void setEncoding(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    paramMimePart.setHeader("Content-Transfer-Encoding", paramString);
  }
  
  /* Error */
  static void setFileName(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: getstatic 32	javax/mail/internet/MimeBodyPart:encodeFileName	Z
    //   3: ifeq +16 -> 19
    //   6: aload_1
    //   7: ifnull +12 -> 19
    //   10: aload_1
    //   11: invokestatic 261	javax/mail/internet/MimeUtility:encodeText	(Ljava/lang/String;)Ljava/lang/String;
    //   14: astore 9
    //   16: aload 9
    //   18: astore_1
    //   19: aload_0
    //   20: ldc 168
    //   22: aconst_null
    //   23: invokeinterface 116 3 0
    //   28: astore_2
    //   29: aload_2
    //   30: ifnonnull +108 -> 138
    //   33: ldc_w 263
    //   36: astore_3
    //   37: new 170	javax/mail/internet/ContentDisposition
    //   40: dup
    //   41: aload_3
    //   42: invokespecial 173	javax/mail/internet/ContentDisposition:<init>	(Ljava/lang/String;)V
    //   45: astore 4
    //   47: aload 4
    //   49: ldc 196
    //   51: aload_1
    //   52: invokevirtual 266	javax/mail/internet/ContentDisposition:setParameter	(Ljava/lang/String;Ljava/lang/String;)V
    //   55: aload_0
    //   56: ldc 168
    //   58: aload 4
    //   60: invokevirtual 257	javax/mail/internet/ContentDisposition:toString	()Ljava/lang/String;
    //   63: invokeinterface 233 3 0
    //   68: getstatic 30	javax/mail/internet/MimeBodyPart:setContentTypeFileName	Z
    //   71: ifeq +51 -> 122
    //   74: aload_0
    //   75: ldc 201
    //   77: aconst_null
    //   78: invokeinterface 116 3 0
    //   83: astore 5
    //   85: aload 5
    //   87: ifnull +35 -> 122
    //   90: new 203	javax/mail/internet/ContentType
    //   93: dup
    //   94: aload 5
    //   96: invokespecial 204	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   99: astore 6
    //   101: aload 6
    //   103: ldc 206
    //   105: aload_1
    //   106: invokevirtual 267	javax/mail/internet/ContentType:setParameter	(Ljava/lang/String;Ljava/lang/String;)V
    //   109: aload_0
    //   110: ldc 201
    //   112: aload 6
    //   114: invokevirtual 268	javax/mail/internet/ContentType:toString	()Ljava/lang/String;
    //   117: invokeinterface 233 3 0
    //   122: return
    //   123: astore 8
    //   125: new 71	javax/mail/MessagingException
    //   128: dup
    //   129: ldc_w 270
    //   132: aload 8
    //   134: invokespecial 107	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   137: athrow
    //   138: aload_2
    //   139: astore_3
    //   140: goto -103 -> 37
    //   143: astore 7
    //   145: goto -23 -> 122
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	148	0	paramMimePart	MimePart
    //   0	148	1	paramString	String
    //   28	111	2	str1	String
    //   36	104	3	str2	String
    //   45	14	4	localContentDisposition	ContentDisposition
    //   83	12	5	str3	String
    //   99	14	6	localContentType	ContentType
    //   143	1	7	localParseException	ParseException
    //   123	10	8	localUnsupportedEncodingException	UnsupportedEncodingException
    //   14	3	9	str4	String
    // Exception table:
    //   from	to	target	type
    //   10	16	123	java/io/UnsupportedEncodingException
    //   90	122	143	javax/mail/internet/ParseException
  }
  
  static void setText(MimePart paramMimePart, String paramString1, String paramString2, String paramString3)
    throws MessagingException
  {
    if (paramString2 == null) {
      if (MimeUtility.checkAscii(paramString1) == 1) {
        break label56;
      }
    }
    label56:
    for (paramString2 = MimeUtility.getDefaultMIMECharset();; paramString2 = "us-ascii")
    {
      paramMimePart.setContent(paramString1, "text/" + paramString3 + "; charset=" + MimeUtility.quote(paramString2, "()<>@,;:\\\"\t []/?="));
      return;
    }
  }
  
  static void updateHeaders(MimePart paramMimePart)
    throws MessagingException
  {
    DataHandler localDataHandler = paramMimePart.getDataHandler();
    if (localDataHandler == null) {
      return;
    }
    label405:
    label422:
    for (;;)
    {
      String str1;
      int i;
      ContentType localContentType;
      Object localObject1;
      try
      {
        str1 = localDataHandler.getContentType();
        i = 0;
        if (paramMimePart.getHeader("Content-Type") == null)
        {
          j = 1;
          localContentType = new ContentType(str1);
          if (!localContentType.match("multipart/*")) {
            break label405;
          }
          i = 1;
          if (!(paramMimePart instanceof MimeBodyPart)) {
            break label307;
          }
          MimeBodyPart localMimeBodyPart = (MimeBodyPart)paramMimePart;
          if (localMimeBodyPart.cachedContent == null) {
            break label298;
          }
          localObject2 = localMimeBodyPart.cachedContent;
          if (!(localObject2 instanceof MimeMultipart)) {
            break label356;
          }
          ((MimeMultipart)localObject2).updateHeaders();
          if (i == 0)
          {
            if (paramMimePart.getHeader("Content-Transfer-Encoding") == null) {
              setEncoding(paramMimePart, MimeUtility.getEncoding(localDataHandler));
            }
            if ((j != 0) && (setDefaultTextCharset) && (localContentType.match("text/*")) && (localContentType.getParameter("charset") == null))
            {
              String str4 = paramMimePart.getEncoding();
              if ((str4 == null) || (!str4.equalsIgnoreCase("7bit"))) {
                break label422;
              }
              localObject1 = "us-ascii";
              localContentType.setParameter("charset", (String)localObject1);
              str1 = localContentType.toString();
            }
          }
          if (j == 0) {
            break;
          }
          String str2 = paramMimePart.getHeader("Content-Disposition", null);
          if (str2 != null)
          {
            String str3 = new ContentDisposition(str2).getParameter("filename");
            if (str3 != null)
            {
              localContentType.setParameter("name", str3);
              str1 = localContentType.toString();
            }
          }
          paramMimePart.setHeader("Content-Type", str1);
        }
      }
      catch (IOException localIOException)
      {
        MessagingException localMessagingException = new MessagingException("IOException updating headers", localIOException);
        throw localMessagingException;
      }
      int j = 0;
      continue;
      label298:
      Object localObject2 = localDataHandler.getContent();
      continue;
      label307:
      if ((paramMimePart instanceof MimeMessage))
      {
        MimeMessage localMimeMessage = (MimeMessage)paramMimePart;
        if (localMimeMessage.cachedContent != null) {
          localObject2 = localMimeMessage.cachedContent;
        } else {
          localObject2 = localDataHandler.getContent();
        }
      }
      else
      {
        localObject2 = localDataHandler.getContent();
        continue;
        label356:
        throw new MessagingException("MIME part of type \"" + str1 + "\" contains object of type " + localObject2.getClass().getName() + " instead of MimeMultipart");
        if (localContentType.match("message/rfc822"))
        {
          i = 1;
          continue;
          String str5 = MimeUtility.getDefaultMIMECharset();
          localObject1 = str5;
        }
      }
    }
  }
  
  static void writeTo(MimePart paramMimePart, OutputStream paramOutputStream, String[] paramArrayOfString)
    throws IOException, MessagingException
  {
    LineOutputStream localLineOutputStream;
    Enumeration localEnumeration;
    if ((paramOutputStream instanceof LineOutputStream))
    {
      localLineOutputStream = (LineOutputStream)paramOutputStream;
      localEnumeration = paramMimePart.getNonMatchingHeaderLines(paramArrayOfString);
    }
    for (;;)
    {
      if (!localEnumeration.hasMoreElements())
      {
        localLineOutputStream.writeln();
        OutputStream localOutputStream = MimeUtility.encode(paramOutputStream, paramMimePart.getEncoding());
        paramMimePart.getDataHandler().writeTo(localOutputStream);
        localOutputStream.flush();
        return;
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        break;
      }
      localLineOutputStream.writeln((String)localEnumeration.nextElement());
    }
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.addHeader(paramString1, paramString2);
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    this.headers.addHeaderLine(paramString);
  }
  
  public void attachFile(File paramFile)
    throws IOException, MessagingException
  {
    FileDataSource localFileDataSource = new FileDataSource(paramFile);
    setDataHandler(new DataHandler(localFileDataSource));
    setFileName(localFileDataSource.getName());
  }
  
  public void attachFile(String paramString)
    throws IOException, MessagingException
  {
    attachFile(new File(paramString));
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    return this.headers.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    return this.headers.getAllHeaders();
  }
  
  public Object getContent()
    throws IOException, MessagingException
  {
    Object localObject2;
    if (this.cachedContent != null) {
      localObject2 = this.cachedContent;
    }
    for (;;)
    {
      return localObject2;
      try
      {
        Object localObject1 = getDataHandler().getContent();
        localObject2 = localObject1;
        if ((!cacheMultipart) || ((!(localObject2 instanceof Multipart)) && (!(localObject2 instanceof Message))) || ((this.content == null) && (this.contentStream == null))) {
          continue;
        }
        this.cachedContent = localObject2;
      }
      catch (FolderClosedIOException localFolderClosedIOException)
      {
        throw new FolderClosedException(localFolderClosedIOException.getFolder(), localFolderClosedIOException.getMessage());
      }
      catch (MessageRemovedIOException localMessageRemovedIOException)
      {
        throw new MessageRemovedException(localMessageRemovedIOException.getMessage());
      }
    }
  }
  
  public String getContentID()
    throws MessagingException
  {
    return getHeader("Content-Id", null);
  }
  
  public String[] getContentLanguage()
    throws MessagingException
  {
    return getContentLanguage(this);
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    return getHeader("Content-MD5", null);
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    if (this.contentStream != null) {}
    for (Object localObject = ((SharedInputStream)this.contentStream).newStream(0L, -1L);; localObject = new ByteArrayInputStream(this.content))
    {
      return localObject;
      if (this.content == null) {
        break;
      }
    }
    throw new MessagingException("No content");
  }
  
  public String getContentType()
    throws MessagingException
  {
    String str = getHeader("Content-Type", null);
    if (str == null) {
      str = "text/plain";
    }
    return str;
  }
  
  public DataHandler getDataHandler()
    throws MessagingException
  {
    if (this.dh == null) {
      this.dh = new DataHandler(new MimePartDataSource(this));
    }
    return this.dh;
  }
  
  public String getDescription()
    throws MessagingException
  {
    return getDescription(this);
  }
  
  public String getDisposition()
    throws MessagingException
  {
    return getDisposition(this);
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return getEncoding(this);
  }
  
  public String getFileName()
    throws MessagingException
  {
    return getFileName(this);
  }
  
  public String getHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    return this.headers.getHeader(paramString);
  }
  
  public InputStream getInputStream()
    throws IOException, MessagingException
  {
    return getDataHandler().getInputStream();
  }
  
  public int getLineCount()
    throws MessagingException
  {
    return -1;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public InputStream getRawInputStream()
    throws MessagingException
  {
    return getContentStream();
  }
  
  public int getSize()
    throws MessagingException
  {
    if (this.content != null) {}
    for (int i = this.content.length;; i = -1) {
      for (;;)
      {
        return i;
        if (this.contentStream != null) {}
        try
        {
          int j = this.contentStream.available();
          i = j;
          if (i > 0) {}
        }
        catch (IOException localIOException)
        {
          label36:
          break label36;
        }
      }
    }
  }
  
  public boolean isMimeType(String paramString)
    throws MessagingException
  {
    return isMimeType(this, paramString);
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    this.headers.removeHeader(paramString);
  }
  
  /* Error */
  public void saveFile(File paramFile)
    throws IOException, MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: new 517	java/io/BufferedOutputStream
    //   7: dup
    //   8: new 519	java/io/FileOutputStream
    //   11: dup
    //   12: aload_1
    //   13: invokespecial 520	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   16: invokespecial 521	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   19: astore 4
    //   21: aload_0
    //   22: invokevirtual 522	javax/mail/internet/MimeBodyPart:getInputStream	()Ljava/io/InputStream;
    //   25: astore_3
    //   26: sipush 8192
    //   29: newarray byte
    //   31: astore 8
    //   33: aload_3
    //   34: aload 8
    //   36: invokevirtual 526	java/io/InputStream:read	([B)I
    //   39: istore 9
    //   41: iload 9
    //   43: ifgt +22 -> 65
    //   46: aload_3
    //   47: ifnull +7 -> 54
    //   50: aload_3
    //   51: invokevirtual 529	java/io/InputStream:close	()V
    //   54: aload 4
    //   56: ifnull +8 -> 64
    //   59: aload 4
    //   61: invokevirtual 530	java/io/OutputStream:close	()V
    //   64: return
    //   65: aload 4
    //   67: aload 8
    //   69: iconst_0
    //   70: iload 9
    //   72: invokevirtual 534	java/io/OutputStream:write	([BII)V
    //   75: goto -42 -> 33
    //   78: astore 5
    //   80: aload 4
    //   82: astore_2
    //   83: aload_3
    //   84: ifnull +7 -> 91
    //   87: aload_3
    //   88: invokevirtual 529	java/io/InputStream:close	()V
    //   91: aload_2
    //   92: ifnull +7 -> 99
    //   95: aload_2
    //   96: invokevirtual 530	java/io/OutputStream:close	()V
    //   99: aload 5
    //   101: athrow
    //   102: astore 7
    //   104: goto -13 -> 91
    //   107: astore 6
    //   109: goto -10 -> 99
    //   112: astore 11
    //   114: goto -60 -> 54
    //   117: astore 10
    //   119: goto -55 -> 64
    //   122: astore 5
    //   124: goto -41 -> 83
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	127	0	this	MimeBodyPart
    //   0	127	1	paramFile	File
    //   1	95	2	localObject1	Object
    //   3	85	3	localInputStream	InputStream
    //   19	62	4	localBufferedOutputStream	java.io.BufferedOutputStream
    //   78	22	5	localObject2	Object
    //   122	1	5	localObject3	Object
    //   107	1	6	localIOException1	IOException
    //   102	1	7	localIOException2	IOException
    //   31	37	8	arrayOfByte	byte[]
    //   39	32	9	i	int
    //   117	1	10	localIOException3	IOException
    //   112	1	11	localIOException4	IOException
    // Exception table:
    //   from	to	target	type
    //   21	41	78	finally
    //   65	75	78	finally
    //   87	91	102	java/io/IOException
    //   95	99	107	java/io/IOException
    //   50	54	112	java/io/IOException
    //   59	64	117	java/io/IOException
    //   4	21	122	finally
  }
  
  public void saveFile(String paramString)
    throws IOException, MessagingException
  {
    saveFile(new File(paramString));
  }
  
  public void setContent(Object paramObject, String paramString)
    throws MessagingException
  {
    if ((paramObject instanceof Multipart)) {
      setContent((Multipart)paramObject);
    }
    for (;;)
    {
      return;
      setDataHandler(new DataHandler(paramObject, paramString));
    }
  }
  
  public void setContent(Multipart paramMultipart)
    throws MessagingException
  {
    setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
    paramMultipart.setParent(this);
  }
  
  public void setContentID(String paramString)
    throws MessagingException
  {
    if (paramString == null) {
      removeHeader("Content-ID");
    }
    for (;;)
    {
      return;
      setHeader("Content-ID", paramString);
    }
  }
  
  public void setContentLanguage(String[] paramArrayOfString)
    throws MessagingException
  {
    setContentLanguage(this, paramArrayOfString);
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    setHeader("Content-MD5", paramString);
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    this.dh = paramDataHandler;
    this.cachedContent = null;
    invalidateContentHeaders(this);
  }
  
  public void setDescription(String paramString)
    throws MessagingException
  {
    setDescription(paramString, null);
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    setDescription(this, paramString1, paramString2);
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    setDisposition(this, paramString);
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    setFileName(this, paramString);
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.setHeader(paramString1, paramString2);
  }
  
  public void setText(String paramString)
    throws MessagingException
  {
    setText(paramString, null);
  }
  
  public void setText(String paramString1, String paramString2)
    throws MessagingException
  {
    setText(this, paramString1, paramString2, "plain");
  }
  
  public void setText(String paramString1, String paramString2, String paramString3)
    throws MessagingException
  {
    setText(this, paramString1, paramString2, paramString3);
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    updateHeaders(this);
    if (this.cachedContent != null)
    {
      this.dh = new DataHandler(this.cachedContent, getContentType());
      this.cachedContent = null;
      this.content = null;
      if (this.contentStream == null) {}
    }
    try
    {
      this.contentStream.close();
      label54:
      this.contentStream = null;
      return;
    }
    catch (IOException localIOException)
    {
      break label54;
    }
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    writeTo(this, paramOutputStream, null);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.internet.MimeBodyPart
 * JD-Core Version:    0.7.0.1
 */