package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;

public class MimeMultipart
  extends Multipart
{
  private static boolean bmparse = true;
  private static boolean ignoreMissingBoundaryParameter;
  private static boolean ignoreMissingEndBoundary;
  private boolean complete = true;
  protected DataSource ds = null;
  protected boolean parsed = true;
  private String preamble = null;
  
  static
  {
    boolean bool1 = false;
    ignoreMissingEndBoundary = true;
    ignoreMissingBoundaryParameter = true;
    try
    {
      String str1 = System.getProperty("mail.mime.multipart.ignoremissingendboundary");
      boolean bool2;
      boolean bool3;
      if ((str1 != null) && (str1.equalsIgnoreCase("false")))
      {
        bool2 = false;
        ignoreMissingEndBoundary = bool2;
        String str2 = System.getProperty("mail.mime.multipart.ignoremissingboundaryparameter");
        if ((str2 == null) || (!str2.equalsIgnoreCase("false"))) {
          break label101;
        }
        bool3 = false;
        label64:
        ignoreMissingBoundaryParameter = bool3;
        String str3 = System.getProperty("mail.mime.multipart.bmparse");
        if ((str3 == null) || (!str3.equalsIgnoreCase("false"))) {
          break label107;
        }
      }
      for (;;)
      {
        bmparse = bool1;
        label95:
        return;
        bool2 = true;
        break;
        label101:
        bool3 = true;
        break label64;
        label107:
        bool1 = true;
      }
    }
    catch (SecurityException localSecurityException)
    {
      break label95;
    }
  }
  
  public MimeMultipart()
  {
    this("mixed");
  }
  
  public MimeMultipart(String paramString)
  {
    String str = UniqueValue.getUniqueBoundaryValue();
    ContentType localContentType = new ContentType("multipart", paramString, null);
    localContentType.setParameter("boundary", str);
    this.contentType = localContentType.toString();
  }
  
  public MimeMultipart(DataSource paramDataSource)
    throws MessagingException
  {
    if ((paramDataSource instanceof MessageAware)) {
      setParent(((MessageAware)paramDataSource).getMessageContext().getPart());
    }
    if ((paramDataSource instanceof MultipartDataSource)) {
      setMultipartDataSource((MultipartDataSource)paramDataSource);
    }
    for (;;)
    {
      return;
      this.parsed = false;
      this.ds = paramDataSource;
      this.contentType = paramDataSource.getContentType();
    }
  }
  
  /* Error */
  private void parsebm()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 56	javax/mail/internet/MimeMultipart:parsed	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aconst_null
    //   15: astore_3
    //   16: lconst_0
    //   17: lstore 4
    //   19: lconst_0
    //   20: lstore 6
    //   22: aload_0
    //   23: getfield 54	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   26: invokeinterface 124 1 0
    //   31: astore 10
    //   33: aload 10
    //   35: instanceof 126
    //   38: ifne +34 -> 72
    //   41: aload 10
    //   43: instanceof 128
    //   46: ifne +26 -> 72
    //   49: aload 10
    //   51: instanceof 130
    //   54: ifne +18 -> 72
    //   57: new 128	java/io/BufferedInputStream
    //   60: dup
    //   61: aload 10
    //   63: invokespecial 133	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   66: astore 62
    //   68: aload 62
    //   70: astore 10
    //   72: aload 10
    //   74: instanceof 130
    //   77: ifeq +9 -> 86
    //   80: aload 10
    //   82: checkcast 130	javax/mail/internet/SharedInputStream
    //   85: astore_3
    //   86: new 68	javax/mail/internet/ContentType
    //   89: dup
    //   90: aload_0
    //   91: getfield 85	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   94: invokespecial 134	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   97: astore 11
    //   99: aconst_null
    //   100: astore 12
    //   102: aload 11
    //   104: ldc 75
    //   106: invokevirtual 137	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   109: astore 13
    //   111: aload 13
    //   113: ifnull +121 -> 234
    //   116: new 139	java/lang/StringBuilder
    //   119: dup
    //   120: ldc 141
    //   122: invokespecial 142	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   125: aload 13
    //   127: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   133: astore 61
    //   135: aload 61
    //   137: astore 12
    //   139: new 149	com/sun/mail/util/LineInputStream
    //   142: dup
    //   143: aload 10
    //   145: invokespecial 150	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   148: astore 14
    //   150: aconst_null
    //   151: astore 15
    //   153: aconst_null
    //   154: astore 16
    //   156: aload 14
    //   158: invokevirtual 153	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   161: astore 21
    //   163: aload 21
    //   165: ifnonnull +85 -> 250
    //   168: aload 21
    //   170: ifnonnull +238 -> 408
    //   173: new 88	javax/mail/MessagingException
    //   176: dup
    //   177: ldc 155
    //   179: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   182: athrow
    //   183: astore 19
    //   185: new 88	javax/mail/MessagingException
    //   188: dup
    //   189: ldc 158
    //   191: aload 19
    //   193: invokespecial 161	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   196: astore 20
    //   198: aload 20
    //   200: athrow
    //   201: astore 17
    //   203: aload 10
    //   205: invokevirtual 166	java/io/InputStream:close	()V
    //   208: aload 17
    //   210: athrow
    //   211: astore_1
    //   212: aload_0
    //   213: monitorexit
    //   214: aload_1
    //   215: athrow
    //   216: astore 8
    //   218: new 88	javax/mail/MessagingException
    //   221: dup
    //   222: ldc 168
    //   224: aload 8
    //   226: invokespecial 161	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   229: astore 9
    //   231: aload 9
    //   233: athrow
    //   234: getstatic 22	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   237: ifne -98 -> 139
    //   240: new 88	javax/mail/MessagingException
    //   243: dup
    //   244: ldc 170
    //   246: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   249: athrow
    //   250: bipush 255
    //   252: aload 21
    //   254: invokevirtual 174	java/lang/String:length	()I
    //   257: iadd
    //   258: istore 22
    //   260: goto +991 -> 1251
    //   263: iload 22
    //   265: iconst_1
    //   266: iadd
    //   267: istore 23
    //   269: aload 21
    //   271: iconst_0
    //   272: iload 23
    //   274: invokevirtual 178	java/lang/String:substring	(II)Ljava/lang/String;
    //   277: astore 21
    //   279: aload 12
    //   281: ifnull +110 -> 391
    //   284: aload 21
    //   286: aload 12
    //   288: invokevirtual 182	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   291: ifne -123 -> 168
    //   294: aload 21
    //   296: invokevirtual 174	java/lang/String:length	()I
    //   299: istore 55
    //   301: iload 55
    //   303: ifle -147 -> 156
    //   306: aload 16
    //   308: ifnonnull +16 -> 324
    //   311: ldc 184
    //   313: ldc 186
    //   315: invokestatic 189	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   318: astore 59
    //   320: aload 59
    //   322: astore 16
    //   324: aload 15
    //   326: ifnonnull +23 -> 349
    //   329: iconst_2
    //   330: aload 21
    //   332: invokevirtual 174	java/lang/String:length	()I
    //   335: iadd
    //   336: istore 57
    //   338: new 191	java/lang/StringBuffer
    //   341: dup
    //   342: iload 57
    //   344: invokespecial 194	java/lang/StringBuffer:<init>	(I)V
    //   347: astore 15
    //   349: aload 15
    //   351: aload 21
    //   353: invokevirtual 197	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   356: aload 16
    //   358: invokevirtual 197	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   361: pop
    //   362: goto -206 -> 156
    //   365: aload 21
    //   367: iload 22
    //   369: invokevirtual 201	java/lang/String:charAt	(I)C
    //   372: istore 60
    //   374: iload 60
    //   376: bipush 32
    //   378: if_icmpeq +881 -> 1259
    //   381: iload 60
    //   383: bipush 9
    //   385: if_icmpne -122 -> 263
    //   388: goto +871 -> 1259
    //   391: aload 21
    //   393: ldc 141
    //   395: invokevirtual 204	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   398: ifeq -104 -> 294
    //   401: aload 21
    //   403: astore 12
    //   405: goto -237 -> 168
    //   408: aload 15
    //   410: ifnull +12 -> 422
    //   413: aload_0
    //   414: aload 15
    //   416: invokevirtual 205	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   419: putfield 60	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   422: aload 12
    //   424: invokestatic 211	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   427: astore 24
    //   429: aload 24
    //   431: arraylength
    //   432: istore 25
    //   434: sipush 256
    //   437: newarray int
    //   439: astore 26
    //   441: iconst_0
    //   442: istore 27
    //   444: iload 27
    //   446: iload 25
    //   448: if_icmplt +47 -> 495
    //   451: iload 25
    //   453: newarray int
    //   455: astore 28
    //   457: iload 25
    //   459: istore 29
    //   461: iload 29
    //   463: ifgt +811 -> 1274
    //   466: aload 28
    //   468: iload 25
    //   470: iconst_1
    //   471: isub
    //   472: iconst_1
    //   473: iastore
    //   474: iconst_0
    //   475: istore 31
    //   477: iload 31
    //   479: ifeq +78 -> 557
    //   482: aload 10
    //   484: invokevirtual 166	java/io/InputStream:close	()V
    //   487: aload_0
    //   488: iconst_1
    //   489: putfield 56	javax/mail/internet/MimeMultipart:parsed	Z
    //   492: goto -481 -> 11
    //   495: aload 26
    //   497: aload 24
    //   499: iload 27
    //   501: baload
    //   502: iload 27
    //   504: iconst_1
    //   505: iadd
    //   506: iastore
    //   507: iinc 27 1
    //   510: goto -66 -> 444
    //   513: aload 24
    //   515: iload 30
    //   517: baload
    //   518: aload 24
    //   520: iload 30
    //   522: iload 29
    //   524: isub
    //   525: baload
    //   526: if_icmpne +766 -> 1292
    //   529: aload 28
    //   531: iload 30
    //   533: iconst_1
    //   534: isub
    //   535: iload 29
    //   537: iastore
    //   538: iinc 30 255
    //   541: goto +739 -> 1280
    //   544: iinc 30 255
    //   547: aload 28
    //   549: iload 30
    //   551: iload 29
    //   553: iastore
    //   554: goto +733 -> 1287
    //   557: aconst_null
    //   558: astore 32
    //   560: aload_3
    //   561: ifnull +60 -> 621
    //   564: aload_3
    //   565: invokeinterface 215 1 0
    //   570: lstore 4
    //   572: aload 14
    //   574: invokevirtual 153	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   577: astore 53
    //   579: aload 53
    //   581: ifnull +11 -> 592
    //   584: aload 53
    //   586: invokevirtual 174	java/lang/String:length	()I
    //   589: ifgt -17 -> 572
    //   592: aload 53
    //   594: ifnonnull +35 -> 629
    //   597: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   600: ifne +13 -> 613
    //   603: new 88	javax/mail/MessagingException
    //   606: dup
    //   607: ldc 217
    //   609: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   612: athrow
    //   613: aload_0
    //   614: iconst_0
    //   615: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   618: goto -136 -> 482
    //   621: aload_0
    //   622: aload 10
    //   624: invokevirtual 221	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   627: astore 32
    //   629: aload 10
    //   631: invokevirtual 225	java/io/InputStream:markSupported	()Z
    //   634: ifne +13 -> 647
    //   637: new 88	javax/mail/MessagingException
    //   640: dup
    //   641: ldc 227
    //   643: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   646: athrow
    //   647: aconst_null
    //   648: astore 33
    //   650: aload_3
    //   651: ifnonnull +85 -> 736
    //   654: new 229	java/io/ByteArrayOutputStream
    //   657: dup
    //   658: invokespecial 230	java/io/ByteArrayOutputStream:<init>	()V
    //   661: astore 33
    //   663: iload 25
    //   665: newarray byte
    //   667: astore 34
    //   669: iload 25
    //   671: newarray byte
    //   673: astore 35
    //   675: iconst_0
    //   676: istore 36
    //   678: iconst_1
    //   679: istore 37
    //   681: sipush 1000
    //   684: iload 25
    //   686: iconst_4
    //   687: iadd
    //   688: iadd
    //   689: istore 38
    //   691: aload 10
    //   693: iload 38
    //   695: invokevirtual 233	java/io/InputStream:mark	(I)V
    //   698: iconst_0
    //   699: istore 39
    //   701: aload 10
    //   703: aload 34
    //   705: iconst_0
    //   706: iload 25
    //   708: invokestatic 237	javax/mail/internet/MimeMultipart:readFully	(Ljava/io/InputStream;[BII)I
    //   711: istore 40
    //   713: iload 40
    //   715: iload 25
    //   717: if_icmpge +581 -> 1298
    //   720: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   723: ifne +24 -> 747
    //   726: new 88	javax/mail/MessagingException
    //   729: dup
    //   730: ldc 217
    //   732: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   735: athrow
    //   736: aload_3
    //   737: invokeinterface 215 1 0
    //   742: lstore 6
    //   744: goto -81 -> 663
    //   747: aload_3
    //   748: ifnull +11 -> 759
    //   751: aload_3
    //   752: invokeinterface 215 1 0
    //   757: lstore 6
    //   759: aload_0
    //   760: iconst_0
    //   761: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   764: iconst_1
    //   765: istore 31
    //   767: aload_3
    //   768: ifnull +402 -> 1170
    //   771: aload_0
    //   772: aload_3
    //   773: lload 4
    //   775: lload 6
    //   777: invokeinterface 241 5 0
    //   782: invokevirtual 245	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   785: astore 50
    //   787: aload_0
    //   788: aload 50
    //   790: invokespecial 249	javax/mail/Multipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   793: goto -316 -> 477
    //   796: iload 41
    //   798: ifge +201 -> 999
    //   801: iconst_0
    //   802: istore 39
    //   804: iload 37
    //   806: ifne +506 -> 1312
    //   809: aload 35
    //   811: iload 36
    //   813: iconst_1
    //   814: isub
    //   815: baload
    //   816: istore 52
    //   818: iload 52
    //   820: bipush 13
    //   822: if_icmpeq +10 -> 832
    //   825: iload 52
    //   827: bipush 10
    //   829: if_icmpne +483 -> 1312
    //   832: iconst_1
    //   833: istore 39
    //   835: iload 52
    //   837: bipush 10
    //   839: if_icmpne +473 -> 1312
    //   842: iload 36
    //   844: iconst_2
    //   845: if_icmplt +467 -> 1312
    //   848: aload 35
    //   850: iload 36
    //   852: iconst_2
    //   853: isub
    //   854: baload
    //   855: bipush 13
    //   857: if_icmpne +455 -> 1312
    //   860: iconst_2
    //   861: istore 39
    //   863: goto +449 -> 1312
    //   866: aload_3
    //   867: ifnull +19 -> 886
    //   870: aload_3
    //   871: invokeinterface 215 1 0
    //   876: iload 25
    //   878: i2l
    //   879: lsub
    //   880: iload 39
    //   882: i2l
    //   883: lsub
    //   884: lstore 6
    //   886: aload 10
    //   888: invokevirtual 252	java/io/InputStream:read	()I
    //   891: istore 47
    //   893: iload 47
    //   895: bipush 45
    //   897: if_icmpne +50 -> 947
    //   900: aload 10
    //   902: invokevirtual 252	java/io/InputStream:read	()I
    //   905: bipush 45
    //   907: if_icmpne +40 -> 947
    //   910: aload_0
    //   911: iconst_1
    //   912: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   915: iconst_1
    //   916: istore 31
    //   918: goto -151 -> 767
    //   921: aload 34
    //   923: iload 41
    //   925: baload
    //   926: aload 24
    //   928: iload 41
    //   930: baload
    //   931: if_icmpne -135 -> 796
    //   934: iinc 41 255
    //   937: goto +367 -> 1304
    //   940: aload 10
    //   942: invokevirtual 252	java/io/InputStream:read	()I
    //   945: istore 47
    //   947: iload 47
    //   949: bipush 32
    //   951: if_icmpeq -11 -> 940
    //   954: iload 47
    //   956: bipush 9
    //   958: if_icmpeq -18 -> 940
    //   961: iload 47
    //   963: bipush 10
    //   965: if_icmpeq -198 -> 767
    //   968: iload 47
    //   970: bipush 13
    //   972: if_icmpne +353 -> 1325
    //   975: aload 10
    //   977: iconst_1
    //   978: invokevirtual 233	java/io/InputStream:mark	(I)V
    //   981: aload 10
    //   983: invokevirtual 252	java/io/InputStream:read	()I
    //   986: bipush 10
    //   988: if_icmpeq -221 -> 767
    //   991: aload 10
    //   993: invokevirtual 255	java/io/InputStream:reset	()V
    //   996: goto -229 -> 767
    //   999: iload 41
    //   1001: iconst_1
    //   1002: iadd
    //   1003: aload 26
    //   1005: bipush 127
    //   1007: aload 34
    //   1009: iload 41
    //   1011: baload
    //   1012: iand
    //   1013: iaload
    //   1014: isub
    //   1015: aload 28
    //   1017: iload 41
    //   1019: iaload
    //   1020: invokestatic 261	java/lang/Math:max	(II)I
    //   1023: istore 42
    //   1025: iload 42
    //   1027: iconst_2
    //   1028: if_icmpge +86 -> 1114
    //   1031: aload_3
    //   1032: ifnonnull +25 -> 1057
    //   1035: iload 36
    //   1037: iconst_1
    //   1038: if_icmple +19 -> 1057
    //   1041: iload 36
    //   1043: iconst_1
    //   1044: isub
    //   1045: istore 46
    //   1047: aload 33
    //   1049: aload 35
    //   1051: iconst_0
    //   1052: iload 46
    //   1054: invokevirtual 265	java/io/ByteArrayOutputStream:write	([BII)V
    //   1057: aload 10
    //   1059: invokevirtual 255	java/io/InputStream:reset	()V
    //   1062: aload_0
    //   1063: aload 10
    //   1065: lconst_1
    //   1066: invokespecial 269	javax/mail/internet/MimeMultipart:skipFully	(Ljava/io/InputStream;J)V
    //   1069: iload 36
    //   1071: iconst_1
    //   1072: if_icmplt +28 -> 1100
    //   1075: aload 35
    //   1077: iconst_0
    //   1078: aload 35
    //   1080: iload 36
    //   1082: iconst_1
    //   1083: isub
    //   1084: baload
    //   1085: bastore
    //   1086: aload 35
    //   1088: iconst_1
    //   1089: aload 34
    //   1091: iconst_0
    //   1092: baload
    //   1093: bastore
    //   1094: iconst_2
    //   1095: istore 36
    //   1097: goto +234 -> 1331
    //   1100: aload 35
    //   1102: iconst_0
    //   1103: aload 34
    //   1105: iconst_0
    //   1106: baload
    //   1107: bastore
    //   1108: iconst_1
    //   1109: istore 36
    //   1111: goto +220 -> 1331
    //   1114: iload 36
    //   1116: ifle +17 -> 1133
    //   1119: aload_3
    //   1120: ifnonnull +13 -> 1133
    //   1123: aload 33
    //   1125: aload 35
    //   1127: iconst_0
    //   1128: iload 36
    //   1130: invokevirtual 265	java/io/ByteArrayOutputStream:write	([BII)V
    //   1133: iload 42
    //   1135: istore 36
    //   1137: aload 10
    //   1139: invokevirtual 255	java/io/InputStream:reset	()V
    //   1142: iload 36
    //   1144: i2l
    //   1145: lstore 43
    //   1147: aload_0
    //   1148: aload 10
    //   1150: lload 43
    //   1152: invokespecial 269	javax/mail/internet/MimeMultipart:skipFully	(Ljava/io/InputStream;J)V
    //   1155: aload 34
    //   1157: astore 45
    //   1159: aload 35
    //   1161: astore 34
    //   1163: aload 45
    //   1165: astore 35
    //   1167: goto +164 -> 1331
    //   1170: iload 36
    //   1172: iload 39
    //   1174: isub
    //   1175: ifle +20 -> 1195
    //   1178: iload 36
    //   1180: iload 39
    //   1182: isub
    //   1183: istore 51
    //   1185: aload 33
    //   1187: aload 35
    //   1189: iconst_0
    //   1190: iload 51
    //   1192: invokevirtual 265	java/io/ByteArrayOutputStream:write	([BII)V
    //   1195: aload_0
    //   1196: getfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   1199: ifne +18 -> 1217
    //   1202: iload 40
    //   1204: ifle +13 -> 1217
    //   1207: aload 33
    //   1209: aload 34
    //   1211: iconst_0
    //   1212: iload 40
    //   1214: invokevirtual 265	java/io/ByteArrayOutputStream:write	([BII)V
    //   1217: aload 33
    //   1219: invokevirtual 273	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   1222: astore 48
    //   1224: aload_0
    //   1225: aload 32
    //   1227: aload 48
    //   1229: invokevirtual 276	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   1232: astore 49
    //   1234: aload 49
    //   1236: astore 50
    //   1238: goto -451 -> 787
    //   1241: astore 18
    //   1243: goto -1035 -> 208
    //   1246: astore 54
    //   1248: goto -761 -> 487
    //   1251: iload 22
    //   1253: ifge -888 -> 365
    //   1256: goto -993 -> 263
    //   1259: iinc 22 255
    //   1262: goto -11 -> 1251
    //   1265: astore 58
    //   1267: ldc 186
    //   1269: astore 16
    //   1271: goto -947 -> 324
    //   1274: iload 25
    //   1276: iconst_1
    //   1277: isub
    //   1278: istore 30
    //   1280: iload 30
    //   1282: iload 29
    //   1284: if_icmpge -771 -> 513
    //   1287: iload 30
    //   1289: ifgt -745 -> 544
    //   1292: iinc 29 255
    //   1295: goto -834 -> 461
    //   1298: iload 25
    //   1300: iconst_1
    //   1301: isub
    //   1302: istore 41
    //   1304: iload 41
    //   1306: ifge -385 -> 921
    //   1309: goto -513 -> 796
    //   1312: iload 37
    //   1314: ifne -448 -> 866
    //   1317: iload 39
    //   1319: ifle +6 -> 1325
    //   1322: goto -456 -> 866
    //   1325: iconst_0
    //   1326: istore 41
    //   1328: goto -329 -> 999
    //   1331: iconst_0
    //   1332: istore 37
    //   1334: goto -653 -> 681
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1337	0	this	MimeMultipart
    //   211	4	1	localObject1	Object
    //   6	2	2	bool	boolean
    //   15	1105	3	localSharedInputStream	SharedInputStream
    //   17	757	4	l1	long
    //   20	865	6	l2	long
    //   216	9	8	localException	java.lang.Exception
    //   229	3	9	localMessagingException1	MessagingException
    //   31	1118	10	localObject2	Object
    //   97	6	11	localContentType	ContentType
    //   100	323	12	localObject3	Object
    //   109	17	13	str1	String
    //   148	425	14	localLineInputStream	com.sun.mail.util.LineInputStream
    //   151	264	15	localStringBuffer	java.lang.StringBuffer
    //   154	1116	16	localObject4	Object
    //   201	8	17	localObject5	Object
    //   1241	1	18	localIOException1	IOException
    //   183	9	19	localIOException2	IOException
    //   196	3	20	localMessagingException2	MessagingException
    //   161	241	21	str2	String
    //   258	1002	22	i	int
    //   267	6	23	j	int
    //   427	500	24	arrayOfByte1	byte[]
    //   432	870	25	k	int
    //   439	565	26	arrayOfInt1	int[]
    //   442	66	27	m	int
    //   455	561	28	arrayOfInt2	int[]
    //   459	834	29	n	int
    //   515	773	30	i1	int
    //   475	442	31	i2	int
    //   558	668	32	localInternetHeaders	InternetHeaders
    //   648	570	33	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    //   667	543	34	localObject6	Object
    //   673	515	35	localObject7	Object
    //   676	507	36	i3	int
    //   679	654	37	i4	int
    //   689	5	38	i5	int
    //   699	619	39	i6	int
    //   711	502	40	i7	int
    //   796	531	41	i8	int
    //   1023	111	42	i9	int
    //   1145	6	43	l3	long
    //   1157	7	45	localObject8	Object
    //   1045	8	46	i10	int
    //   891	82	47	i11	int
    //   1222	6	48	arrayOfByte2	byte[]
    //   1232	3	49	localMimeBodyPart	MimeBodyPart
    //   785	452	50	localObject9	Object
    //   1183	8	51	i12	int
    //   816	24	52	i13	int
    //   577	16	53	str3	String
    //   1246	1	54	localIOException3	IOException
    //   299	3	55	i14	int
    //   336	7	57	i15	int
    //   1265	1	58	localSecurityException	SecurityException
    //   318	3	59	str4	String
    //   372	14	60	i16	int
    //   133	3	61	str5	String
    //   66	3	62	localBufferedInputStream	java.io.BufferedInputStream
    // Exception table:
    //   from	to	target	type
    //   139	183	183	java/io/IOException
    //   250	301	183	java/io/IOException
    //   311	320	183	java/io/IOException
    //   329	474	183	java/io/IOException
    //   495	1234	183	java/io/IOException
    //   139	183	201	finally
    //   185	201	201	finally
    //   250	301	201	finally
    //   311	320	201	finally
    //   329	474	201	finally
    //   495	1234	201	finally
    //   2	7	211	finally
    //   22	68	211	finally
    //   72	135	211	finally
    //   203	208	211	finally
    //   208	211	211	finally
    //   218	250	211	finally
    //   482	487	211	finally
    //   487	492	211	finally
    //   22	68	216	java/lang/Exception
    //   203	208	1241	java/io/IOException
    //   482	487	1246	java/io/IOException
    //   311	320	1265	java/lang/SecurityException
  }
  
  private static int readFully(InputStream paramInputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    if (paramInt2 == 0)
    {
      i = 0;
      break label17;
      label7:
      return i;
    }
    else
    {
      i = 0;
    }
    for (;;)
    {
      if (paramInt2 <= 0)
      {
        label17:
        if (i > 0) {
          break label7;
        }
        i = -1;
        break label7;
      }
      int j = paramInputStream.read(paramArrayOfByte, paramInt1, paramInt2);
      if (j <= 0) {
        break;
      }
      paramInt1 += j;
      i += j;
      paramInt2 -= j;
    }
  }
  
  private void skipFully(InputStream paramInputStream, long paramLong)
    throws IOException
  {
    for (;;)
    {
      if (paramLong <= 0L) {
        return;
      }
      long l = paramInputStream.skip(paramLong);
      if (l <= 0L) {
        throw new EOFException("can't skip");
      }
      paramLong -= l;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      parse();
      super.addBodyPart(paramBodyPart);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      parse();
      super.addBodyPart(paramBodyPart, paramInt);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  protected InternetHeaders createInternetHeaders(InputStream paramInputStream)
    throws MessagingException
  {
    return new InternetHeaders(paramInputStream);
  }
  
  protected MimeBodyPart createMimeBodyPart(InputStream paramInputStream)
    throws MessagingException
  {
    return new MimeBodyPart(paramInputStream);
  }
  
  protected MimeBodyPart createMimeBodyPart(InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte)
    throws MessagingException
  {
    return new MimeBodyPart(paramInternetHeaders, paramArrayOfByte);
  }
  
  public BodyPart getBodyPart(int paramInt)
    throws MessagingException
  {
    try
    {
      parse();
      BodyPart localBodyPart = super.getBodyPart(paramInt);
      return localBodyPart;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public BodyPart getBodyPart(String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 291	javax/mail/internet/MimeMultipart:parse	()V
    //   6: aload_0
    //   7: invokevirtual 311	javax/mail/internet/MimeMultipart:getCount	()I
    //   10: istore_3
    //   11: iconst_0
    //   12: istore 4
    //   14: iload 4
    //   16: iload_3
    //   17: if_icmplt +11 -> 28
    //   20: aconst_null
    //   21: astore 5
    //   23: aload_0
    //   24: monitorexit
    //   25: aload 5
    //   27: areturn
    //   28: aload_0
    //   29: iload 4
    //   31: invokevirtual 312	javax/mail/internet/MimeMultipart:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   34: checkcast 299	javax/mail/internet/MimeBodyPart
    //   37: astore 5
    //   39: aload 5
    //   41: invokevirtual 315	javax/mail/internet/MimeBodyPart:getContentID	()Ljava/lang/String;
    //   44: astore 6
    //   46: aload 6
    //   48: ifnull +16 -> 64
    //   51: aload 6
    //   53: aload_1
    //   54: invokevirtual 182	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   57: istore 7
    //   59: iload 7
    //   61: ifne -38 -> 23
    //   64: iinc 4 1
    //   67: goto -53 -> 14
    //   70: astore_2
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_2
    //   74: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	75	0	this	MimeMultipart
    //   0	75	1	paramString	String
    //   70	4	2	localObject1	Object
    //   10	8	3	i	int
    //   12	53	4	j	int
    //   21	19	5	localObject2	Object
    //   44	8	6	str	String
    //   57	3	7	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   2	11	70	finally
    //   28	59	70	finally
  }
  
  public int getCount()
    throws MessagingException
  {
    try
    {
      parse();
      int i = super.getCount();
      return i;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public String getPreamble()
    throws MessagingException
  {
    try
    {
      parse();
      String str = this.preamble;
      return str;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public boolean isComplete()
    throws MessagingException
  {
    try
    {
      parse();
      boolean bool = this.complete;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  protected void parse()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 56	javax/mail/internet/MimeMultipart:parsed	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: getstatic 24	javax/mail/internet/MimeMultipart:bmparse	Z
    //   17: ifeq +15 -> 32
    //   20: aload_0
    //   21: invokespecial 320	javax/mail/internet/MimeMultipart:parsebm	()V
    //   24: goto -13 -> 11
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: athrow
    //   32: aconst_null
    //   33: astore_3
    //   34: lconst_0
    //   35: lstore 4
    //   37: lconst_0
    //   38: lstore 6
    //   40: aload_0
    //   41: getfield 54	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   44: invokeinterface 124 1 0
    //   49: astore 10
    //   51: aload 10
    //   53: instanceof 126
    //   56: ifne +34 -> 90
    //   59: aload 10
    //   61: instanceof 128
    //   64: ifne +26 -> 90
    //   67: aload 10
    //   69: instanceof 130
    //   72: ifne +18 -> 90
    //   75: new 128	java/io/BufferedInputStream
    //   78: dup
    //   79: aload 10
    //   81: invokespecial 133	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   84: astore 49
    //   86: aload 49
    //   88: astore 10
    //   90: aload 10
    //   92: instanceof 130
    //   95: ifeq +9 -> 104
    //   98: aload 10
    //   100: checkcast 130	javax/mail/internet/SharedInputStream
    //   103: astore_3
    //   104: new 68	javax/mail/internet/ContentType
    //   107: dup
    //   108: aload_0
    //   109: getfield 85	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   112: invokespecial 134	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   115: astore 11
    //   117: aconst_null
    //   118: astore 12
    //   120: aload 11
    //   122: ldc 75
    //   124: invokevirtual 137	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   127: astore 13
    //   129: aload 13
    //   131: ifnull +116 -> 247
    //   134: new 139	java/lang/StringBuilder
    //   137: dup
    //   138: ldc 141
    //   140: invokespecial 142	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   143: aload 13
    //   145: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   151: astore 48
    //   153: aload 48
    //   155: astore 12
    //   157: new 149	com/sun/mail/util/LineInputStream
    //   160: dup
    //   161: aload 10
    //   163: invokespecial 150	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   166: astore 14
    //   168: aconst_null
    //   169: astore 15
    //   171: aconst_null
    //   172: astore 16
    //   174: aload 14
    //   176: invokevirtual 153	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   179: astore 21
    //   181: aload 21
    //   183: ifnonnull +80 -> 263
    //   186: aload 21
    //   188: ifnonnull +233 -> 421
    //   191: new 88	javax/mail/MessagingException
    //   194: dup
    //   195: ldc 155
    //   197: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   200: athrow
    //   201: astore 19
    //   203: new 88	javax/mail/MessagingException
    //   206: dup
    //   207: ldc 158
    //   209: aload 19
    //   211: invokespecial 161	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   214: astore 20
    //   216: aload 20
    //   218: athrow
    //   219: astore 17
    //   221: aload 10
    //   223: invokevirtual 166	java/io/InputStream:close	()V
    //   226: aload 17
    //   228: athrow
    //   229: astore 8
    //   231: new 88	javax/mail/MessagingException
    //   234: dup
    //   235: ldc 168
    //   237: aload 8
    //   239: invokespecial 161	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   242: astore 9
    //   244: aload 9
    //   246: athrow
    //   247: getstatic 22	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   250: ifne -93 -> 157
    //   253: new 88	javax/mail/MessagingException
    //   256: dup
    //   257: ldc 170
    //   259: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   262: athrow
    //   263: bipush 255
    //   265: aload 21
    //   267: invokevirtual 174	java/lang/String:length	()I
    //   270: iadd
    //   271: istore 22
    //   273: goto +688 -> 961
    //   276: iload 22
    //   278: iconst_1
    //   279: iadd
    //   280: istore 23
    //   282: aload 21
    //   284: iconst_0
    //   285: iload 23
    //   287: invokevirtual 178	java/lang/String:substring	(II)Ljava/lang/String;
    //   290: astore 21
    //   292: aload 12
    //   294: ifnull +110 -> 404
    //   297: aload 21
    //   299: aload 12
    //   301: invokevirtual 182	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   304: ifne -118 -> 186
    //   307: aload 21
    //   309: invokevirtual 174	java/lang/String:length	()I
    //   312: istore 42
    //   314: iload 42
    //   316: ifle -142 -> 174
    //   319: aload 16
    //   321: ifnonnull +16 -> 337
    //   324: ldc 184
    //   326: ldc 186
    //   328: invokestatic 189	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   331: astore 46
    //   333: aload 46
    //   335: astore 16
    //   337: aload 15
    //   339: ifnonnull +23 -> 362
    //   342: iconst_2
    //   343: aload 21
    //   345: invokevirtual 174	java/lang/String:length	()I
    //   348: iadd
    //   349: istore 44
    //   351: new 191	java/lang/StringBuffer
    //   354: dup
    //   355: iload 44
    //   357: invokespecial 194	java/lang/StringBuffer:<init>	(I)V
    //   360: astore 15
    //   362: aload 15
    //   364: aload 21
    //   366: invokevirtual 197	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   369: aload 16
    //   371: invokevirtual 197	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   374: pop
    //   375: goto -201 -> 174
    //   378: aload 21
    //   380: iload 22
    //   382: invokevirtual 201	java/lang/String:charAt	(I)C
    //   385: istore 47
    //   387: iload 47
    //   389: bipush 32
    //   391: if_icmpeq +578 -> 969
    //   394: iload 47
    //   396: bipush 9
    //   398: if_icmpne -122 -> 276
    //   401: goto +568 -> 969
    //   404: aload 21
    //   406: ldc 141
    //   408: invokevirtual 204	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   411: ifeq -104 -> 307
    //   414: aload 21
    //   416: astore 12
    //   418: goto -232 -> 186
    //   421: aload 15
    //   423: ifnull +12 -> 435
    //   426: aload_0
    //   427: aload 15
    //   429: invokevirtual 205	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   432: putfield 60	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   435: aload 12
    //   437: invokestatic 211	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   440: astore 24
    //   442: aload 24
    //   444: arraylength
    //   445: istore 25
    //   447: iconst_0
    //   448: istore 26
    //   450: iload 26
    //   452: ifeq +16 -> 468
    //   455: aload 10
    //   457: invokevirtual 166	java/io/InputStream:close	()V
    //   460: aload_0
    //   461: iconst_1
    //   462: putfield 56	javax/mail/internet/MimeMultipart:parsed	Z
    //   465: goto -454 -> 11
    //   468: aconst_null
    //   469: astore 27
    //   471: aload_3
    //   472: ifnull +60 -> 532
    //   475: aload_3
    //   476: invokeinterface 215 1 0
    //   481: lstore 4
    //   483: aload 14
    //   485: invokevirtual 153	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   488: astore 40
    //   490: aload 40
    //   492: ifnull +11 -> 503
    //   495: aload 40
    //   497: invokevirtual 174	java/lang/String:length	()I
    //   500: ifgt -17 -> 483
    //   503: aload 40
    //   505: ifnonnull +35 -> 540
    //   508: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   511: ifne +13 -> 524
    //   514: new 88	javax/mail/MessagingException
    //   517: dup
    //   518: ldc 217
    //   520: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   523: athrow
    //   524: aload_0
    //   525: iconst_0
    //   526: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   529: goto -74 -> 455
    //   532: aload_0
    //   533: aload 10
    //   535: invokevirtual 221	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   538: astore 27
    //   540: aload 10
    //   542: invokevirtual 225	java/io/InputStream:markSupported	()Z
    //   545: ifne +13 -> 558
    //   548: new 88	javax/mail/MessagingException
    //   551: dup
    //   552: ldc 227
    //   554: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   557: athrow
    //   558: aconst_null
    //   559: astore 28
    //   561: aload_3
    //   562: ifnonnull +111 -> 673
    //   565: new 229	java/io/ByteArrayOutputStream
    //   568: dup
    //   569: invokespecial 230	java/io/ByteArrayOutputStream:<init>	()V
    //   572: astore 28
    //   574: goto +410 -> 984
    //   577: iload 29
    //   579: ifeq +228 -> 807
    //   582: sipush 1000
    //   585: iload 25
    //   587: iconst_4
    //   588: iadd
    //   589: iadd
    //   590: istore 37
    //   592: aload 10
    //   594: iload 37
    //   596: invokevirtual 233	java/io/InputStream:mark	(I)V
    //   599: iconst_0
    //   600: istore 38
    //   602: goto +396 -> 998
    //   605: iload 38
    //   607: iload 25
    //   609: if_icmpne +157 -> 766
    //   612: aload 10
    //   614: invokevirtual 252	java/io/InputStream:read	()I
    //   617: istore 39
    //   619: iload 39
    //   621: bipush 45
    //   623: if_icmpne +91 -> 714
    //   626: aload 10
    //   628: invokevirtual 252	java/io/InputStream:read	()I
    //   631: bipush 45
    //   633: if_icmpne +81 -> 714
    //   636: aload_0
    //   637: iconst_1
    //   638: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   641: iconst_1
    //   642: istore 26
    //   644: aload_3
    //   645: ifnull +282 -> 927
    //   648: aload_0
    //   649: aload_3
    //   650: lload 4
    //   652: lload 6
    //   654: invokeinterface 241 5 0
    //   659: invokevirtual 245	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   662: astore 36
    //   664: aload_0
    //   665: aload 36
    //   667: invokespecial 249	javax/mail/Multipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   670: goto -220 -> 450
    //   673: aload_3
    //   674: invokeinterface 215 1 0
    //   679: lstore 6
    //   681: goto +303 -> 984
    //   684: aload 10
    //   686: invokevirtual 252	java/io/InputStream:read	()I
    //   689: sipush 255
    //   692: aload 24
    //   694: iload 38
    //   696: baload
    //   697: iand
    //   698: if_icmpne -93 -> 605
    //   701: iinc 38 1
    //   704: goto +294 -> 998
    //   707: aload 10
    //   709: invokevirtual 252	java/io/InputStream:read	()I
    //   712: istore 39
    //   714: iload 39
    //   716: bipush 32
    //   718: if_icmpeq -11 -> 707
    //   721: iload 39
    //   723: bipush 9
    //   725: if_icmpeq -18 -> 707
    //   728: iload 39
    //   730: bipush 10
    //   732: if_icmpeq -88 -> 644
    //   735: iload 39
    //   737: bipush 13
    //   739: if_icmpne +27 -> 766
    //   742: aload 10
    //   744: iconst_1
    //   745: invokevirtual 233	java/io/InputStream:mark	(I)V
    //   748: aload 10
    //   750: invokevirtual 252	java/io/InputStream:read	()I
    //   753: bipush 10
    //   755: if_icmpeq -111 -> 644
    //   758: aload 10
    //   760: invokevirtual 255	java/io/InputStream:reset	()V
    //   763: goto -119 -> 644
    //   766: aload 10
    //   768: invokevirtual 255	java/io/InputStream:reset	()V
    //   771: aload 28
    //   773: ifnull +34 -> 807
    //   776: iload 30
    //   778: bipush 255
    //   780: if_icmpeq +27 -> 807
    //   783: aload 28
    //   785: iload 30
    //   787: invokevirtual 322	java/io/ByteArrayOutputStream:write	(I)V
    //   790: iload 31
    //   792: bipush 255
    //   794: if_icmpeq +214 -> 1008
    //   797: aload 28
    //   799: iload 31
    //   801: invokevirtual 322	java/io/ByteArrayOutputStream:write	(I)V
    //   804: goto +204 -> 1008
    //   807: aload 10
    //   809: invokevirtual 252	java/io/InputStream:read	()I
    //   812: istore 32
    //   814: iload 32
    //   816: ifge +203 -> 1019
    //   819: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   822: ifne +13 -> 835
    //   825: new 88	javax/mail/MessagingException
    //   828: dup
    //   829: ldc 217
    //   831: invokespecial 156	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   834: athrow
    //   835: aload_0
    //   836: iconst_0
    //   837: putfield 58	javax/mail/internet/MimeMultipart:complete	Z
    //   840: iconst_1
    //   841: istore 26
    //   843: goto -199 -> 644
    //   846: iconst_1
    //   847: istore 29
    //   849: aload_3
    //   850: ifnull +13 -> 863
    //   853: aload_3
    //   854: invokeinterface 215 1 0
    //   859: lconst_1
    //   860: lsub
    //   861: lstore 6
    //   863: iload 32
    //   865: istore 30
    //   867: iload 32
    //   869: bipush 13
    //   871: if_icmpne -294 -> 577
    //   874: aload 10
    //   876: iconst_1
    //   877: invokevirtual 233	java/io/InputStream:mark	(I)V
    //   880: aload 10
    //   882: invokevirtual 252	java/io/InputStream:read	()I
    //   885: istore 33
    //   887: iload 33
    //   889: bipush 10
    //   891: if_icmpne +10 -> 901
    //   894: iload 33
    //   896: istore 31
    //   898: goto -321 -> 577
    //   901: aload 10
    //   903: invokevirtual 255	java/io/InputStream:reset	()V
    //   906: goto -329 -> 577
    //   909: iconst_0
    //   910: istore 29
    //   912: aload 28
    //   914: ifnull -337 -> 577
    //   917: aload 28
    //   919: iload 32
    //   921: invokevirtual 322	java/io/ByteArrayOutputStream:write	(I)V
    //   924: goto -347 -> 577
    //   927: aload 28
    //   929: invokevirtual 273	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   932: astore 34
    //   934: aload_0
    //   935: aload 27
    //   937: aload 34
    //   939: invokevirtual 276	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   942: astore 35
    //   944: aload 35
    //   946: astore 36
    //   948: goto -284 -> 664
    //   951: astore 18
    //   953: goto -727 -> 226
    //   956: astore 41
    //   958: goto -498 -> 460
    //   961: iload 22
    //   963: ifge -585 -> 378
    //   966: goto -690 -> 276
    //   969: iinc 22 255
    //   972: goto -11 -> 961
    //   975: astore 45
    //   977: ldc 186
    //   979: astore 16
    //   981: goto -644 -> 337
    //   984: iconst_1
    //   985: istore 29
    //   987: bipush 255
    //   989: istore 30
    //   991: bipush 255
    //   993: istore 31
    //   995: goto -418 -> 577
    //   998: iload 38
    //   1000: iload 25
    //   1002: if_icmplt -318 -> 684
    //   1005: goto -400 -> 605
    //   1008: bipush 255
    //   1010: istore 31
    //   1012: iload 31
    //   1014: istore 30
    //   1016: goto -209 -> 807
    //   1019: iload 32
    //   1021: bipush 13
    //   1023: if_icmpeq -177 -> 846
    //   1026: iload 32
    //   1028: bipush 10
    //   1030: if_icmpne -121 -> 909
    //   1033: goto -187 -> 846
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1036	0	this	MimeMultipart
    //   27	4	1	localObject1	Object
    //   6	2	2	bool	boolean
    //   33	821	3	localSharedInputStream	SharedInputStream
    //   35	616	4	l1	long
    //   38	824	6	l2	long
    //   229	9	8	localException	java.lang.Exception
    //   242	3	9	localMessagingException1	MessagingException
    //   49	853	10	localObject2	Object
    //   115	6	11	localContentType	ContentType
    //   118	318	12	localObject3	Object
    //   127	17	13	str1	String
    //   166	318	14	localLineInputStream	com.sun.mail.util.LineInputStream
    //   169	259	15	localStringBuffer	java.lang.StringBuffer
    //   172	808	16	localObject4	Object
    //   219	8	17	localObject5	Object
    //   951	1	18	localIOException1	IOException
    //   201	9	19	localIOException2	IOException
    //   214	3	20	localMessagingException2	MessagingException
    //   179	236	21	str2	String
    //   271	699	22	i	int
    //   280	6	23	j	int
    //   440	253	24	arrayOfByte1	byte[]
    //   445	558	25	k	int
    //   448	394	26	m	int
    //   469	467	27	localInternetHeaders	InternetHeaders
    //   559	369	28	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    //   577	409	29	n	int
    //   776	239	30	i1	int
    //   790	223	31	i2	int
    //   812	219	32	i3	int
    //   885	10	33	i4	int
    //   932	6	34	arrayOfByte2	byte[]
    //   942	3	35	localMimeBodyPart	MimeBodyPart
    //   662	285	36	localObject6	Object
    //   590	5	37	i5	int
    //   600	403	38	i6	int
    //   617	123	39	i7	int
    //   488	16	40	str3	String
    //   956	1	41	localIOException3	IOException
    //   312	3	42	i8	int
    //   349	7	44	i9	int
    //   975	1	45	localSecurityException	SecurityException
    //   331	3	46	str4	String
    //   385	14	47	i10	int
    //   151	3	48	str5	String
    //   84	3	49	localBufferedInputStream	java.io.BufferedInputStream
    // Exception table:
    //   from	to	target	type
    //   2	7	27	finally
    //   14	24	27	finally
    //   40	86	27	finally
    //   90	153	27	finally
    //   221	226	27	finally
    //   226	263	27	finally
    //   455	460	27	finally
    //   460	465	27	finally
    //   157	201	201	java/io/IOException
    //   263	314	201	java/io/IOException
    //   324	333	201	java/io/IOException
    //   342	447	201	java/io/IOException
    //   475	944	201	java/io/IOException
    //   157	201	219	finally
    //   203	219	219	finally
    //   263	314	219	finally
    //   324	333	219	finally
    //   342	447	219	finally
    //   475	944	219	finally
    //   40	86	229	java/lang/Exception
    //   221	226	951	java/io/IOException
    //   455	460	956	java/io/IOException
    //   324	333	975	java/lang/SecurityException
  }
  
  public void removeBodyPart(int paramInt)
    throws MessagingException
  {
    parse();
    super.removeBodyPart(paramInt);
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    parse();
    return super.removeBodyPart(paramBodyPart);
  }
  
  public void setPreamble(String paramString)
    throws MessagingException
  {
    try
    {
      this.preamble = paramString;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void setSubType(String paramString)
    throws MessagingException
  {
    try
    {
      ContentType localContentType = new ContentType(this.contentType);
      localContentType.setSubType(paramString);
      this.contentType = localContentType.toString();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    for (int i = 0;; i++)
    {
      if (i >= this.parts.size()) {
        return;
      }
      ((MimeBodyPart)this.parts.elementAt(i)).updateHeaders();
    }
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    for (;;)
    {
      String str;
      LineOutputStream localLineOutputStream;
      try
      {
        parse();
        str = "--" + new ContentType(this.contentType).getParameter("boundary");
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        if (this.preamble == null) {
          break label190;
        }
        byte[] arrayOfByte = ASCIIUtility.getBytes(this.preamble);
        localLineOutputStream.write(arrayOfByte);
        if ((arrayOfByte.length <= 0) || (arrayOfByte[(-1 + arrayOfByte.length)] == 13) || (arrayOfByte[(-1 + arrayOfByte.length)] == 10)) {
          break label190;
        }
        localLineOutputStream.writeln();
      }
      finally {}
      if (i >= this.parts.size())
      {
        localLineOutputStream.writeln(str + "--");
        return;
      }
      localLineOutputStream.writeln(str);
      ((MimeBodyPart)this.parts.elementAt(i)).writeTo(paramOutputStream);
      localLineOutputStream.writeln();
      i++;
      continue;
      label190:
      int i = 0;
    }
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.internet.MimeMultipart
 * JD-Core Version:    0.7.0.1
 */