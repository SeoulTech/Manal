package javax.mail;

import java.util.Date;
import javax.mail.search.SearchTerm;

public abstract class Message
  implements Part
{
  protected boolean expunged = false;
  protected Folder folder = null;
  protected int msgnum = 0;
  protected Session session = null;
  
  protected Message() {}
  
  protected Message(Folder paramFolder, int paramInt)
  {
    this.folder = paramFolder;
    this.msgnum = paramInt;
    this.session = paramFolder.store.session;
  }
  
  protected Message(Session paramSession)
  {
    this.session = paramSession;
  }
  
  public abstract void addFrom(Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public void addRecipient(Message.RecipientType paramRecipientType, Address paramAddress)
    throws MessagingException
  {
    Address[] arrayOfAddress = new Address[1];
    arrayOfAddress[0] = paramAddress;
    addRecipients(paramRecipientType, arrayOfAddress);
  }
  
  public abstract void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public Address[] getAllRecipients()
    throws MessagingException
  {
    Object localObject = getRecipients(Message.RecipientType.TO);
    Address[] arrayOfAddress1 = getRecipients(Message.RecipientType.CC);
    Address[] arrayOfAddress2 = getRecipients(Message.RecipientType.BCC);
    if ((arrayOfAddress1 == null) && (arrayOfAddress2 == null)) {
      return localObject;
    }
    int i;
    label42:
    int j;
    label50:
    int k;
    if (localObject != null)
    {
      i = localObject.length;
      if (arrayOfAddress1 == null) {
        break label153;
      }
      j = arrayOfAddress1.length;
      k = i + j;
      if (arrayOfAddress2 == null) {
        break label159;
      }
    }
    label153:
    label159:
    for (int m = arrayOfAddress2.length;; m = 0)
    {
      Address[] arrayOfAddress3 = new Address[k + m];
      int n = 0;
      if (localObject != null)
      {
        System.arraycopy(localObject, 0, arrayOfAddress3, 0, localObject.length);
        n = 0 + localObject.length;
      }
      if (arrayOfAddress1 != null)
      {
        System.arraycopy(arrayOfAddress1, 0, arrayOfAddress3, n, arrayOfAddress1.length);
        n += arrayOfAddress1.length;
      }
      if (arrayOfAddress2 != null)
      {
        System.arraycopy(arrayOfAddress2, 0, arrayOfAddress3, n, arrayOfAddress2.length);
        (n + arrayOfAddress2.length);
      }
      localObject = arrayOfAddress3;
      break;
      i = 0;
      break label42;
      j = 0;
      break label50;
    }
  }
  
  public abstract Flags getFlags()
    throws MessagingException;
  
  public Folder getFolder()
  {
    return this.folder;
  }
  
  public abstract Address[] getFrom()
    throws MessagingException;
  
  public int getMessageNumber()
  {
    return this.msgnum;
  }
  
  public abstract Date getReceivedDate()
    throws MessagingException;
  
  public abstract Address[] getRecipients(Message.RecipientType paramRecipientType)
    throws MessagingException;
  
  public Address[] getReplyTo()
    throws MessagingException
  {
    return getFrom();
  }
  
  public abstract Date getSentDate()
    throws MessagingException;
  
  public abstract String getSubject()
    throws MessagingException;
  
  public boolean isExpunged()
  {
    return this.expunged;
  }
  
  public boolean isSet(Flags.Flag paramFlag)
    throws MessagingException
  {
    return getFlags().contains(paramFlag);
  }
  
  public boolean match(SearchTerm paramSearchTerm)
    throws MessagingException
  {
    return paramSearchTerm.match(this);
  }
  
  public abstract Message reply(boolean paramBoolean)
    throws MessagingException;
  
  public abstract void saveChanges()
    throws MessagingException;
  
  protected void setExpunged(boolean paramBoolean)
  {
    this.expunged = paramBoolean;
  }
  
  public void setFlag(Flags.Flag paramFlag, boolean paramBoolean)
    throws MessagingException
  {
    setFlags(new Flags(paramFlag), paramBoolean);
  }
  
  public abstract void setFlags(Flags paramFlags, boolean paramBoolean)
    throws MessagingException;
  
  public abstract void setFrom()
    throws MessagingException;
  
  public abstract void setFrom(Address paramAddress)
    throws MessagingException;
  
  protected void setMessageNumber(int paramInt)
  {
    this.msgnum = paramInt;
  }
  
  public void setRecipient(Message.RecipientType paramRecipientType, Address paramAddress)
    throws MessagingException
  {
    Address[] arrayOfAddress = new Address[1];
    arrayOfAddress[0] = paramAddress;
    setRecipients(paramRecipientType, arrayOfAddress);
  }
  
  public abstract void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public void setReplyTo(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new MethodNotSupportedException("setReplyTo not supported");
  }
  
  public abstract void setSentDate(Date paramDate)
    throws MessagingException;
  
  public abstract void setSubject(String paramString)
    throws MessagingException;
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.Message
 * JD-Core Version:    0.7.0.1
 */