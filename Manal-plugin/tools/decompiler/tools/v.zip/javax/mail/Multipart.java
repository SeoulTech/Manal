package javax.mail;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

public abstract class Multipart
{
  protected String contentType = "multipart/mixed";
  protected Part parent;
  protected Vector parts = new Vector();
  
  public void addBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        this.parts = new Vector();
      }
      this.parts.addElement(paramBodyPart);
      paramBodyPart.setParent(this);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        this.parts = new Vector();
      }
      this.parts.insertElementAt(paramBodyPart, paramInt);
      paramBodyPart.setParent(this);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public BodyPart getBodyPart(int paramInt)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        throw new IndexOutOfBoundsException("No such BodyPart");
      }
    }
    finally {}
    BodyPart localBodyPart = (BodyPart)this.parts.elementAt(paramInt);
    return localBodyPart;
  }
  
  public String getContentType()
  {
    return this.contentType;
  }
  
  /* Error */
  public int getCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	javax/mail/Multipart:parts	Ljava/util/Vector;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull +11 -> 19
    //   11: iconst_0
    //   12: istore 4
    //   14: aload_0
    //   15: monitorexit
    //   16: iload 4
    //   18: ireturn
    //   19: aload_0
    //   20: getfield 19	javax/mail/Multipart:parts	Ljava/util/Vector;
    //   23: invokevirtual 62	java/util/Vector:size	()I
    //   26: istore_3
    //   27: iload_3
    //   28: istore 4
    //   30: goto -16 -> 14
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	38	0	this	Multipart
    //   33	4	1	localObject	Object
    //   6	2	2	localVector	Vector
    //   26	2	3	i	int
    //   12	17	4	j	int
    // Exception table:
    //   from	to	target	type
    //   2	7	33	finally
    //   19	27	33	finally
  }
  
  public Part getParent()
  {
    try
    {
      Part localPart = this.parent;
      return localPart;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void removeBodyPart(int paramInt)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        throw new IndexOutOfBoundsException("No such BodyPart");
      }
    }
    finally {}
    BodyPart localBodyPart = (BodyPart)this.parts.elementAt(paramInt);
    this.parts.removeElementAt(paramInt);
    localBodyPart.setParent(null);
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        throw new MessagingException("No such body part");
      }
    }
    finally {}
    boolean bool = this.parts.removeElement(paramBodyPart);
    paramBodyPart.setParent(null);
    return bool;
  }
  
  /* Error */
  protected void setMultipartDataSource(MultipartDataSource paramMultipartDataSource)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokeinterface 85 1 0
    //   9: putfield 23	javax/mail/Multipart:contentType	Ljava/lang/String;
    //   12: aload_1
    //   13: invokeinterface 87 1 0
    //   18: istore_3
    //   19: iconst_0
    //   20: istore 4
    //   22: iload 4
    //   24: iload_3
    //   25: if_icmplt +6 -> 31
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: aload_0
    //   32: aload_1
    //   33: iload 4
    //   35: invokeinterface 89 2 0
    //   40: invokevirtual 91	javax/mail/Multipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   43: iinc 4 1
    //   46: goto -24 -> 22
    //   49: astore_2
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_2
    //   53: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	54	0	this	Multipart
    //   0	54	1	paramMultipartDataSource	MultipartDataSource
    //   49	4	2	localObject	Object
    //   18	8	3	i	int
    //   20	24	4	j	int
    // Exception table:
    //   from	to	target	type
    //   2	19	49	finally
    //   31	43	49	finally
  }
  
  public void setParent(Part paramPart)
  {
    try
    {
      this.parent = paramPart;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public abstract void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException;
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.Multipart
 * JD-Core Version:    0.7.0.1
 */