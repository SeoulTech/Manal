package javax.mail;

public class FetchProfile$Item
{
  public static final Item CONTENT_INFO = new Item("CONTENT_INFO");
  public static final Item ENVELOPE = new Item("ENVELOPE");
  public static final Item FLAGS = new Item("FLAGS");
  private String name;
  
  protected FetchProfile$Item(String paramString)
  {
    this.name = paramString;
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.mail.FetchProfile.Item
 * JD-Core Version:    0.7.0.1
 */