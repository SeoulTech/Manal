package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface DataSource
{
  public abstract String getContentType();
  
  public abstract InputStream getInputStream()
    throws IOException;
  
  public abstract String getName();
  
  public abstract OutputStream getOutputStream()
    throws IOException;
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     javax.activation.DataSource
 * JD-Core Version:    0.7.0.1
 */