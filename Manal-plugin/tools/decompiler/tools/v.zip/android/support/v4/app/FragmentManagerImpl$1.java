package android.support.v4.app;

class FragmentManagerImpl$1
  implements Runnable
{
  FragmentManagerImpl$1(FragmentManagerImpl paramFragmentManagerImpl) {}
  
  public void run()
  {
    this.this$0.execPendingActions();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManagerImpl.1
 * JD-Core Version:    0.7.0.1
 */