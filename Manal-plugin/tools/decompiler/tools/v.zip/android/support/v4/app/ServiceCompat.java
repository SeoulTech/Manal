package android.support.v4.app;

public class ServiceCompat
{
  public static final int START_STICKY = 1;
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ServiceCompat
 * JD-Core Version:    0.7.0.1
 */