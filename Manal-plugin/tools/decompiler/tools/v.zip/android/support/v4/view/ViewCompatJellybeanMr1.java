package android.support.v4.view;

import android.view.View;

public class ViewCompatJellybeanMr1
{
  public static int getLabelFor(View paramView)
  {
    return paramView.getLabelFor();
  }
  
  public static void setLabelFor(View paramView, int paramInt)
  {
    paramView.setLabelFor(paramInt);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatJellybeanMr1
 * JD-Core Version:    0.7.0.1
 */