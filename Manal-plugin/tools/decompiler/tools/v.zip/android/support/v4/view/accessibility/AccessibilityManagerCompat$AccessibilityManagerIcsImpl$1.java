package android.support.v4.view.accessibility;

class AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1
  implements AccessibilityManagerCompatIcs.AccessibilityStateChangeListenerBridge
{
  AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1(AccessibilityManagerCompat.AccessibilityManagerIcsImpl paramAccessibilityManagerIcsImpl, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat) {}
  
  public void onAccessibilityStateChanged(boolean paramBoolean)
  {
    this.val$listener.onAccessibilityStateChanged(paramBoolean);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityManagerCompat.AccessibilityManagerIcsImpl.1
 * JD-Core Version:    0.7.0.1
 */