package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

class FragmentTabHost$SavedState$1
  implements Parcelable.Creator<FragmentTabHost.SavedState>
{
  public FragmentTabHost.SavedState createFromParcel(Parcel paramParcel)
  {
    return new FragmentTabHost.SavedState(paramParcel, null);
  }
  
  public FragmentTabHost.SavedState[] newArray(int paramInt)
  {
    return new FragmentTabHost.SavedState[paramInt];
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost.SavedState.1
 * JD-Core Version:    0.7.0.1
 */