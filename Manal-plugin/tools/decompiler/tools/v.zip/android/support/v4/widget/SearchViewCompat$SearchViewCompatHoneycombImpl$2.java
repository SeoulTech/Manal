package android.support.v4.widget;

class SearchViewCompat$SearchViewCompatHoneycombImpl$2
  implements SearchViewCompatHoneycomb.OnCloseListenerCompatBridge
{
  SearchViewCompat$SearchViewCompatHoneycombImpl$2(SearchViewCompat.SearchViewCompatHoneycombImpl paramSearchViewCompatHoneycombImpl, SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat) {}
  
  public boolean onClose()
  {
    return this.val$listener.onClose();
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompat.SearchViewCompatHoneycombImpl.2
 * JD-Core Version:    0.7.0.1
 */