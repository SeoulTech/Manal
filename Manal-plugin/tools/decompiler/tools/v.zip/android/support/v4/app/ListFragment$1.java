package android.support.v4.app;

import android.widget.ListView;

class ListFragment$1
  implements Runnable
{
  ListFragment$1(ListFragment paramListFragment) {}
  
  public void run()
  {
    this.this$0.mList.focusableViewAvailable(this.this$0.mList);
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ListFragment.1
 * JD-Core Version:    0.7.0.1
 */