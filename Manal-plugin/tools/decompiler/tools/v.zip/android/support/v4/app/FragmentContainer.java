package android.support.v4.app;

import android.view.View;

abstract interface FragmentContainer
{
  public abstract View findViewById(int paramInt);
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentContainer
 * JD-Core Version:    0.7.0.1
 */