package android.support.v4.app;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

class ListFragment$2
  implements AdapterView.OnItemClickListener
{
  ListFragment$2(ListFragment paramListFragment) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.this$0.onListItemClick((ListView)paramAdapterView, paramView, paramInt, paramLong);
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ListFragment.2
 * JD-Core Version:    0.7.0.1
 */