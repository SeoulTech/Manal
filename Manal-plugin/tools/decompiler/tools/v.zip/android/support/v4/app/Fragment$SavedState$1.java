package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

class Fragment$SavedState$1
  implements Parcelable.Creator<Fragment.SavedState>
{
  public Fragment.SavedState createFromParcel(Parcel paramParcel)
  {
    return new Fragment.SavedState(paramParcel, null);
  }
  
  public Fragment.SavedState[] newArray(int paramInt)
  {
    return new Fragment.SavedState[paramInt];
  }
}


/* Location:           D:\ManalProject\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment.SavedState.1
 * JD-Core Version:    0.7.0.1
 */