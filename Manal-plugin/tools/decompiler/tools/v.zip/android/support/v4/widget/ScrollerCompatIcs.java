package android.support.v4.widget;

import android.widget.Scroller;

class ScrollerCompatIcs
{
  public static float getCurrVelocity(Scroller paramScroller)
  {
    return paramScroller.getCurrVelocity();
  }
}


/* Location:           D:\Workspaces\SsSDK\contest_dev\Manal\Manal-plugin\tools\decompiler\tools\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ScrollerCompatIcs
 * JD-Core Version:    0.7.0.1
 */